function getAppSafe() {
  try {
    return getApp()
  } catch (e) {
    return null
  }
}

function getOpenid() {
  const app = getAppSafe()

  if (app && app.globalData && app.globalData.openid) {
    return app.globalData.openid
  }

  return wx.getStorageSync('dh_openid') || ''
}

function getCurrentUser() {
  const app = getAppSafe()

  if (app && app.globalData && app.globalData.userProfile) {
    return app.globalData.userProfile
  }

  return wx.getStorageSync('dh_current_user') || null
}

function isLoggedIn() {
  return !!getOpenid()
}

function isProfileCompleted() {
  const user = getCurrentUser()
  return !!(user && user.profileCompleted)
}

function getCurrentRoute() {
  const pages = getCurrentPages()

  if (!pages || pages.length === 0) return ''

  return pages[pages.length - 1].route || ''
}

function redirectToLogin() {
  const currentRoute = getCurrentRoute()

  if (currentRoute === 'pages/login/login') return

  wx.reLaunch({
    url: '/pages/login/login'
  })
}

function goProfileSetup() {
  const currentRoute = getCurrentRoute()

  if (currentRoute === 'pages/profileSetup/profileSetup') return

  wx.navigateTo({
    url: '/pages/profileSetup/profileSetup'
  })
}

function requireLogin() {
  if (isLoggedIn()) {
    return true
  }

  redirectToLogin()
  return false
}

function requireProfileCompleted() {
  if (!requireLogin()) {
    return false
  }

  if (!isProfileCompleted()) {
    goProfileSetup()
    return false
  }

  return true
}

function setLogin(openid, user) {
  const app = getAppSafe()

  if (app && app.globalData) {
    app.globalData.openid = openid || ''
    app.globalData.userProfile = user || null
    app.globalData.loginReady = !!openid
  }

  wx.setStorageSync('dh_openid', openid || '')
  wx.setStorageSync('dh_current_user', user || null)
}

function updateUser(user) {
  const app = getAppSafe()

  if (app && app.globalData) {
    app.globalData.userProfile = user || null
  }

  wx.setStorageSync('dh_current_user', user || null)
}

function clearLogin() {
  const app = getAppSafe()

  if (app && app.clearLogin) {
    app.clearLogin()
    return
  }

  if (app && app.globalData) {
    app.globalData.openid = ''
    app.globalData.userProfile = null
    app.globalData.loginReady = false
  }

  wx.removeStorageSync('dh_openid')
  wx.removeStorageSync('dh_current_user')
}

function logoutToLogin() {
  clearLogin()

  wx.reLaunch({
    url: '/pages/login/login'
  })
}

module.exports = {
  getOpenid,
  getCurrentUser,
  isLoggedIn,
  isProfileCompleted,
  requireLogin,
  requireProfileCompleted,
  setLogin,
  updateUser,
  clearLogin,
  logoutToLogin
}