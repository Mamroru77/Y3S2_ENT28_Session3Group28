const defaultAnswers = {
  sleepTime: '23:30',
  wakeTime: '07:30',
  lightsOffTime: '23:45',
  noiseTolerance: 2,
  cleanliness: 4,
  acTemperature: '24°C',
  visitorAcceptance: 2,
  socialStyle: 2,
  spacePreference: 3,

  mbti: 'INTJ',
  dormVibe: '安静学习型',
  lifestyleTags: ['宿舍学习型', '噪音敏感'],
  redFlags: ['凌晨外放视频', '公共区域长期脏乱'],
  greenFlags: ['主动沟通', '尊重安静时间'],
  unacceptableBehavior: ''
}

function timeToMinutes(time) {
  if (!time) return 0
  const parts = String(time).split(':')
  return Number(parts[0]) * 60 + Number(parts[1])
}

function circularTimeDiff(timeA, timeB) {
  const a = timeToMinutes(timeA)
  const b = timeToMinutes(timeB)
  const diff = Math.abs(a - b)

  return Math.min(diff, 1440 - diff)
}

function scoreByTimeDiff(minutes) {
  if (minutes <= 30) return 100
  if (minutes <= 60) return 85
  if (minutes <= 90) return 70
  if (minutes <= 120) return 50
  return 20
}

function scaleScore(valueA, valueB) {
  const diff = Math.abs(Number(valueA) - Number(valueB))

  if (diff === 0) return 100
  if (diff === 1) return 80
  if (diff === 2) return 60
  if (diff === 3) return 35
  return 10
}

function acToNumber(value) {
  if (!value) return null

  if (String(value).includes('20')) return 20
  if (String(value).includes('22')) return 22
  if (String(value).includes('24')) return 24
  if (String(value).includes('26')) return 26

  return null
}

function acScore(valueA, valueB) {
  const a = acToNumber(valueA)
  const b = acToNumber(valueB)

  if (a === null && b === null) return 90
  if (a === null || b === null) return 45

  const diff = Math.abs(a - b)

  if (diff <= 1) return 100
  if (diff <= 2) return 85
  if (diff <= 3) return 65
  if (diff <= 4) return 40
  return 20
}

function average(numbers) {
  if (!numbers.length) return 0
  return Math.round(numbers.reduce((sum, value) => sum + value, 0) / numbers.length)
}

function getCandidateLifestyle(candidate, lang) {
  return lang === 'zh'
    ? candidate.profile.lifestyleTagsZh || []
    : candidate.profile.lifestyleTagsEn || []
}

function getCandidateRedFlags(candidate, lang) {
  return lang === 'zh'
    ? candidate.profile.redFlagsZh || []
    : candidate.profile.redFlagsEn || []
}

function getCandidateGreenFlags(candidate, lang) {
  return lang === 'zh'
    ? candidate.profile.greenFlagsZh || []
    : candidate.profile.greenFlagsEn || []
}

function getCandidatePotentialRedFlags(candidate, lang) {
  return lang === 'zh'
    ? candidate.profile.potentialRedFlagsZh || []
    : candidate.profile.potentialRedFlagsEn || []
}

function getCandidateDormVibe(candidate, lang) {
  return lang === 'zh'
    ? candidate.profile.dormVibeZh || ''
    : candidate.profile.dormVibeEn || ''
}

function intersection(listA, listB) {
  const a = listA || []
  const b = listB || []

  return a.filter((item) => b.includes(item))
}

function overlapScore(listA, listB) {
  const a = listA || []
  const b = listB || []

  if (!a.length || !b.length) return 70

  const shared = intersection(a, b).length
  const base = Math.max(a.length, b.length)

  const ratio = shared / base

  if (ratio >= 0.6) return 100
  if (ratio >= 0.4) return 85
  if (ratio >= 0.2) return 70
  return 55
}

function mbtiScore(userMbti, candidateMbti) {
  if (!userMbti || !candidateMbti) return 70
  if (userMbti === candidateMbti) return 100
  if (userMbti === '不确定' || userMbti === 'Not sure') return 70

  const userFirst = String(userMbti).slice(0, 1)
  const candidateFirst = String(candidateMbti).slice(0, 1)

  if (userFirst === candidateFirst) return 85

  return 70
}

function dormVibeScore(userVibe, candidateVibe) {
  if (!userVibe || !candidateVibe) return 70
  if (userVibe === candidateVibe) return 100

  const quietGroup = ['安静学习型', '整洁极简型', 'Quiet Study Dorm', 'Clean & Minimal Dorm']
  const socialGroup = ['社交活力型', '创作娱乐型', 'Social Dorm', 'Creative Dorm']
  const flexibleGroup = ['自由随和型', '自律规律型', 'Flexible Dorm', 'Gym & Routine Dorm']

  if (quietGroup.includes(userVibe) && quietGroup.includes(candidateVibe)) return 85
  if (socialGroup.includes(userVibe) && socialGroup.includes(candidateVibe)) return 80
  if (flexibleGroup.includes(userVibe) && flexibleGroup.includes(candidateVibe)) return 80

  return 60
}

function personalityScore(user, candidate, lang) {
  const candidateLifestyleTags = getCandidateLifestyle(candidate, lang)
  const candidateDormVibe = getCandidateDormVibe(candidate, lang)

  return average([
    mbtiScore(user.mbti, candidate.profile.mbti),
    dormVibeScore(user.dormVibe, candidateDormVibe),
    overlapScore(user.lifestyleTags || [], candidateLifestyleTags)
  ])
}

function detectHardConflicts(user, candidate, lang) {
  const conflicts = []

  const lightsOffDiff = circularTimeDiff(
    user.lightsOffTime,
    candidate.profile.lightsOffTime
  )

  if (lightsOffDiff > 120) {
    conflicts.push({
      typeZh: '熄灯时间冲突',
      typeEn: 'Lights-off conflict',
      messageZh: '你们希望熄灯的时间相差超过 2 小时。',
      messageEn: 'Your preferred lights-off times are more than 2 hours apart.',
      penalty: 15
    })
  }

  if (Math.abs(Number(user.cleanliness) - Number(candidate.profile.cleanliness)) >= 3) {
    conflicts.push({
      typeZh: '卫生标准冲突',
      typeEn: 'Cleanliness conflict',
      messageZh: '你们对宿舍整洁程度的要求差异较大。',
      messageEn: 'Your cleanliness expectations are very different.',
      penalty: 12
    })
  }

  if (Math.abs(Number(user.noiseTolerance) - Number(candidate.profile.noiseTolerance)) >= 3) {
    conflicts.push({
      typeZh: '噪音偏好冲突',
      typeEn: 'Noise conflict',
      messageZh: '一方很需要安静，另一方对噪音更不敏感。',
      messageEn: 'One user strongly prefers quiet, while the other is more tolerant of noise.',
      penalty: 10
    })
  }

  if (Math.abs(Number(user.visitorAcceptance) - Number(candidate.profile.visitorAcceptance)) >= 3) {
    conflicts.push({
      typeZh: '访客边界冲突',
      typeEn: 'Visitor boundary conflict',
      messageZh: '你们对访客进入宿舍的接受程度差异较大。',
      messageEn: 'Visitor acceptance is significantly different.',
      penalty: 10
    })
  }

  const userAc = acToNumber(user.acTemperature)
  const candidateAc = acToNumber(candidate.profile.acTemperature)

  if (userAc !== null && candidateAc !== null && Math.abs(userAc - candidateAc) >= 5) {
    conflicts.push({
      typeZh: '空调温度冲突',
      typeEn: 'AC temperature conflict',
      messageZh: '你们偏好的空调温度差异较大。',
      messageEn: 'Your preferred AC temperatures are far apart.',
      penalty: 8
    })
  }

  const totalPenalty = conflicts.reduce((sum, item) => sum + item.penalty, 0)

  return {
    conflicts,
    totalPenalty
  }
}

function getRiskLevel(score, lang) {
  if (score >= 80) {
    return {
      label: lang === 'zh' ? '低' : 'Low',
      className: 'low'
    }
  }

  if (score >= 60) {
    return {
      label: lang === 'zh' ? '中' : 'Medium',
      className: 'medium'
    }
  }

  return {
    label: lang === 'zh' ? '高' : 'High',
    className: 'high'
  }
}

function buildConflictRadar(scores, candidate, lang) {
  const labelsZh = {
    sleep: '作息风险',
    cleanliness: '卫生风险',
    noise: '噪音风险',
    visitor: '访客风险',
    ac: '空调风险',
    social: '社交边界风险',
    personality: '人格与生活方式风险',
    reputation: '信誉风险'
  }

  const labelsEn = {
    sleep: 'Sleep Risk',
    cleanliness: 'Cleanliness Risk',
    noise: 'Noise Risk',
    visitor: 'Visitor Risk',
    ac: 'AC Risk',
    social: 'Social Boundary Risk',
    personality: 'Personality & Lifestyle Risk',
    reputation: 'Reputation Risk'
  }

  const labelMap = lang === 'zh' ? labelsZh : labelsEn
  const reputationCompatibility = candidate.reputationScore >= 90
    ? 95
    : candidate.reputationScore >= 75
      ? 80
      : candidate.reputationScore >= 60
        ? 55
        : 35

  const radarItems = [
    { key: 'sleep', label: labelMap.sleep, compatibility: scores.sleep },
    { key: 'cleanliness', label: labelMap.cleanliness, compatibility: scores.cleanliness },
    { key: 'noise', label: labelMap.noise, compatibility: scores.noise },
    { key: 'visitor', label: labelMap.visitor, compatibility: scores.visitor },
    { key: 'ac', label: labelMap.ac, compatibility: scores.ac },
    { key: 'social', label: labelMap.social, compatibility: scores.social },
    { key: 'personality', label: labelMap.personality, compatibility: scores.personality },
    { key: 'reputation', label: labelMap.reputation, compatibility: reputationCompatibility }
  ]

  return radarItems.map((item) => {
    const risk = getRiskLevel(item.compatibility, lang)

    return {
      ...item,
      riskLabel: risk.label,
      riskClass: risk.className,
      widthStyle: `width: ${item.compatibility}%;`
    }
  })
}

function buildStrengths(scores, lang) {
  const strengths = []

  if (scores.sleep >= 80) {
    strengths.push(lang === 'zh' ? '作息时间比较接近。' : 'Sleep schedule is highly compatible.')
  }

  if (scores.cleanliness >= 80) {
    strengths.push(lang === 'zh' ? '卫生整洁要求比较一致。' : 'Cleanliness expectations are closely aligned.')
  }

  if (scores.noise >= 80) {
    strengths.push(lang === 'zh' ? '对噪音和安静程度的期待比较接近。' : 'Noise expectations are similar.')
  }

  if (scores.visitor >= 80) {
    strengths.push(lang === 'zh' ? '访客边界比较一致。' : 'Visitor boundaries are similar.')
  }

  if (scores.social >= 80) {
    strengths.push(lang === 'zh' ? '社交倾向比较接近。' : 'Social style is similar.')
  }

  if (scores.personality >= 80) {
    strengths.push(lang === 'zh' ? '人格与生活方式画像较匹配。' : 'Personality and lifestyle stack are compatible.')
  }

  if (!strengths.length) {
    strengths.push(lang === 'zh'
      ? '存在一些中等相似点，但需要先沟通关键生活习惯。'
      : 'There are moderate similarities, but key habits should be discussed first.')
  }

  return strengths
}

function buildRisks(dimensions, conflicts, candidate, redFlagConflicts, lang) {
  const risks = []

  dimensions.forEach((item) => {
    if (item.score < 60) {
      risks.push(
        lang === 'zh'
          ? `${item.label} 可能成为潜在冲突点。`
          : `${item.label} may become a potential conflict area.`
      )
    }
  })

  conflicts.forEach((conflict) => {
    risks.push(lang === 'zh' ? conflict.messageZh : conflict.messageEn)
  })

  if (candidate.reputationScore < 70) {
    risks.push(
      lang === 'zh'
        ? '该用户信誉分偏低，建议沟通前谨慎确认生活习惯真实性。'
        : 'This user has a relatively low reputation score. Verify lifestyle information carefully.'
    )
  }

  if (redFlagConflicts.length > 0) {
    risks.push(
      lang === 'zh'
        ? `你的 Red Flags 中有 ${redFlagConflicts.length} 项可能与对方行为风险重合。`
        : `${redFlagConflicts.length} of your Red Flags may overlap with this candidate’s risk signals.`
    )
  }

  if (!risks.length) {
    risks.push(lang === 'zh'
      ? '当前资料中没有发现明显高风险冲突。'
      : 'No major lifestyle conflict detected in the current profile.')
  }

  return risks
}

function buildSuggestedQuestions(lang) {
  if (lang === 'zh') {
    return [
      '你通常几点之后希望宿舍保持安静？',
      '公共区域应该如何分工打扫？',
      '朋友来宿舍是否需要提前说？',
      '空调温度能否提前约定一个双方都能接受的范围？'
    ]
  }

  return [
    'What time should quiet hours start?',
    'How should shared cleaning tasks be divided?',
    'Should visitors be discussed in advance?',
    'What AC temperature would be acceptable for both of you?'
  ]
}

function recommendation(score, reputationScore, lang) {
  if (reputationScore < 65) {
    return lang === 'zh'
      ? '匹配前需要谨慎核实对方资料。'
      : 'Verify this profile carefully before matching.'
  }

  if (score >= 85) {
    return lang === 'zh'
      ? '高度匹配，建议进一步沟通。'
      : 'Highly compatible. Recommended to chat.'
  }

  if (score >= 70) {
    return lang === 'zh'
      ? '整体匹配，但建议先确认风险点。'
      : 'Compatible, but discuss risk points first.'
  }

  if (score >= 55) {
    return lang === 'zh'
      ? '中等匹配，需要认真沟通生活边界。'
      : 'Moderate compatibility. Discuss boundaries carefully.'
  }

  return lang === 'zh'
    ? '风险较高，不建议直接合住。'
    : 'Risky match. Not recommended without further discussion.'
}

function buildPersonalityInsight(user, candidate, sharedLifestyle, sharedGreenFlags, redFlagConflicts, lang) {
  const candidateDormVibe = getCandidateDormVibe(candidate, lang)

  if (lang === 'zh') {
    if (redFlagConflicts.length > 0) {
      return `你和 ${candidate.name} 在部分生活方式上可能存在重合，但你的 Red Flags 中有项目与对方潜在风险接近，建议先明确边界。`
    }

    if (sharedGreenFlags.length > 0 || sharedLifestyle.length > 0) {
      return `你和 ${candidate.name} 在生活方式或 Green Flags 上存在共同点，适合进一步沟通合住规则。`
    }

    return `你偏向 ${user.dormVibe || '未填写'}，对方偏向 ${candidateDormVibe || '未填写'}。建议先确认作息、卫生和访客边界。`
  }

  if (redFlagConflicts.length > 0) {
    return `You and ${candidate.name} have some lifestyle overlap, but your Red Flags may overlap with this candidate’s potential risk signals. Clarify boundaries first.`
  }

  if (sharedGreenFlags.length > 0 || sharedLifestyle.length > 0) {
    return `You and ${candidate.name} share some lifestyle or Green Flag similarities. It is worth discussing shared-living rules further.`
  }

  return `Your preferred dorm vibe is ${user.dormVibe || 'not set'}, while this candidate prefers ${candidateDormVibe || 'not set'}. Discuss schedule, cleanliness and visitor boundaries first.`
}

function calculateMatch(userAnswers, candidate, lang) {
  const user = {
    ...defaultAnswers,
    ...userAnswers,
    lifestyleTags: userAnswers && userAnswers.lifestyleTags ? userAnswers.lifestyleTags : [],
    redFlags: userAnswers && userAnswers.redFlags ? userAnswers.redFlags : [],
    greenFlags: userAnswers && userAnswers.greenFlags ? userAnswers.greenFlags : []
  }

  const sleepScore = average([
    scoreByTimeDiff(circularTimeDiff(user.sleepTime, candidate.profile.sleepTime)),
    scoreByTimeDiff(circularTimeDiff(user.wakeTime, candidate.profile.wakeTime)),
    scoreByTimeDiff(circularTimeDiff(user.lightsOffTime, candidate.profile.lightsOffTime))
  ])

  const scores = {
    sleep: sleepScore,
    noise: scaleScore(user.noiseTolerance, candidate.profile.noiseTolerance),
    cleanliness: scaleScore(user.cleanliness, candidate.profile.cleanliness),
    ac: acScore(user.acTemperature, candidate.profile.acTemperature),
    visitor: scaleScore(user.visitorAcceptance, candidate.profile.visitorAcceptance),
    social: scaleScore(user.socialStyle, candidate.profile.socialStyle),
    space: scaleScore(user.spacePreference, candidate.profile.spacePreference),
    personality: personalityScore(user, candidate, lang)
  }

  const candidateLifestyleTags = getCandidateLifestyle(candidate, lang)
  const candidateRedFlags = getCandidateRedFlags(candidate, lang)
  const candidateGreenFlags = getCandidateGreenFlags(candidate, lang)
  const candidatePotentialRedFlags = getCandidatePotentialRedFlags(candidate, lang)
  const candidateDormVibe = getCandidateDormVibe(candidate, lang)

  const sharedLifestyle = intersection(user.lifestyleTags, candidateLifestyleTags)
  const sharedGreenFlags = intersection(user.greenFlags, candidateGreenFlags)
  const sharedRedFlags = intersection(user.redFlags, candidateRedFlags)
  const redFlagConflicts = intersection(user.redFlags, candidatePotentialRedFlags)

  const hardConflictResult = detectHardConflicts(user, candidate, lang)

  const weightedScore =
    scores.sleep * 0.2 +
    scores.cleanliness * 0.18 +
    scores.noise * 0.15 +
    scores.visitor * 0.12 +
    scores.ac * 0.1 +
    scores.social * 0.1 +
    scores.space * 0.08 +
    scores.personality * 0.07

  const redFlagPenalty = redFlagConflicts.length * 6

  const finalScore = Math.max(
    0,
    Math.min(100, Math.round(weightedScore - hardConflictResult.totalPenalty - redFlagPenalty))
  )

  const labelsZh = {
    sleep: '作息时间',
    noise: '噪音忍受度',
    cleanliness: '卫生整洁',
    ac: '空调偏好',
    visitor: '访客边界',
    social: '社交倾向',
    space: '空间使用',
    personality: '人格与生活方式'
  }

  const labelsEn = {
    sleep: 'Sleep Schedule',
    noise: 'Noise Tolerance',
    cleanliness: 'Cleanliness',
    ac: 'AC Preference',
    visitor: 'Visitor Boundary',
    social: 'Social Style',
    space: 'Space Preference',
    personality: 'Personality & Lifestyle'
  }

  const labelMap = lang === 'zh' ? labelsZh : labelsEn

  const dimensions = [
    { key: 'sleep', label: labelMap.sleep, score: scores.sleep },
    { key: 'cleanliness', label: labelMap.cleanliness, score: scores.cleanliness },
    { key: 'noise', label: labelMap.noise, score: scores.noise },
    { key: 'visitor', label: labelMap.visitor, score: scores.visitor },
    { key: 'ac', label: labelMap.ac, score: scores.ac },
    { key: 'social', label: labelMap.social, score: scores.social },
    { key: 'space', label: labelMap.space, score: scores.space },
    { key: 'personality', label: labelMap.personality, score: scores.personality }
  ].map((item) => ({
    ...item,
    widthStyle: `width: ${item.score}%;`
  }))

  const strengths = buildStrengths(scores, lang)
  const risks = buildRisks(
    dimensions,
    hardConflictResult.conflicts,
    candidate,
    redFlagConflicts,
    lang
  )

  const userStack = [
    user.mbti,
    user.dormVibe,
    ...(user.lifestyleTags || []).slice(0, 3)
  ].filter(Boolean)

  const candidateStack = [
    candidate.profile.mbti,
    candidateDormVibe,
    ...candidateLifestyleTags.slice(0, 3)
  ].filter(Boolean)

  const match = {
    ...candidate,
    displayCampus: lang === 'zh' ? candidate.campusZh : candidate.campusEn,
    displaySchool: lang === 'zh' ? candidate.schoolZh : candidate.schoolEn,
    displayTags: lang === 'zh' ? candidate.tagsZh : candidate.tagsEn,
    displayReputationLevel: lang === 'zh' ? candidate.reputationLevelZh : candidate.reputationLevelEn,
    displayReputationNotes: lang === 'zh' ? candidate.reputationNotesZh : candidate.reputationNotesEn,

    score: finalScore,
    scoreStyle: `width: ${finalScore}%;`,
    scoreLevel: getScoreLevel(finalScore, lang),
    scoreClass: getScoreClass(finalScore),

    dimensions,
    strengths,
    risks,
    suggestedQuestions: buildSuggestedQuestions(lang),
    recommendation: recommendation(finalScore, candidate.reputationScore, lang),

    conflicts: hardConflictResult.conflicts.map((item) => ({
      type: lang === 'zh' ? item.typeZh : item.typeEn,
      message: lang === 'zh' ? item.messageZh : item.messageEn,
      penalty: item.penalty
    })),

    conflictRadar: buildConflictRadar(scores, candidate, lang),

    personality: {
      userStack,
      candidateStack,
      userDormVibe: user.dormVibe || '',
      candidateDormVibe,
      sharedLifestyle,
      sharedGreenFlags,
      sharedRedFlags,
      redFlagConflicts,
      insight: buildPersonalityInsight(
        user,
        candidate,
        sharedLifestyle,
        sharedGreenFlags,
        redFlagConflicts,
        lang
      )
    }
  }

  return match
}

function getScoreLevel(score, lang) {
  if (score >= 85) return lang === 'zh' ? '高度匹配' : 'High'
  if (score >= 70) return lang === 'zh' ? '良好匹配' : 'Good'
  if (score >= 55) return lang === 'zh' ? '中等匹配' : 'Medium'
  return lang === 'zh' ? '高风险' : 'Risk'
}

function getScoreClass(score) {
  if (score >= 85) return 'high'
  if (score >= 70) return 'good'
  if (score >= 55) return 'medium'
  return 'risk'
}

function calculateAllMatches(userAnswers, candidates, lang) {
  return candidates
    .map((candidate) => calculateMatch(userAnswers, candidate, lang))
    .sort((a, b) => b.score - a.score)
}

module.exports = {
  defaultAnswers,
  calculateMatch,
  calculateAllMatches
}