const { saveReputation, getReputation } = require('./storage')

const DEFAULT_REPUTATION = {
  score: 85,
  level: 'Trusted',
  records: [
    {
      type: 'initial',
      change: 0,
      reasonEn: 'Initial DormHarmony trust score.',
      reasonZh: 'DormHarmony 初始信誉分。',
      createdAt: new Date().toISOString()
    }
  ]
}

function clampScore(score) {
  if (score > 100) return 100
  if (score < 0) return 0
  return score
}

function getLevel(score) {
  if (score >= 90) return 'Excellent'
  if (score >= 75) return 'Trusted'
  if (score >= 60) return 'Caution'
  return 'Restricted'
}

function initReputation() {
  const existing = getReputation()

  if (existing) {
    return existing
  }

  const initial = {
    ...DEFAULT_REPUTATION,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }

  saveReputation(initial)

  return initial
}

function updateReputation(change, reasonEn, reasonZh, type) {
  const current = initReputation()

  const nextScore = clampScore(current.score + change)

  const nextReputation = {
    score: nextScore,
    level: getLevel(nextScore),
    records: [
      {
        type: type || 'general',
        change,
        reasonEn,
        reasonZh,
        createdAt: new Date().toISOString()
      },
      ...(current.records || [])
    ],
    createdAt: current.createdAt || new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }

  saveReputation(nextReputation)

  return nextReputation
}

function evaluateStudentEmail(email) {
  const trimmedEmail = String(email || '').trim().toLowerCase()

  const isXjtluStudent =
    trimmedEmail.endsWith('@student.xjtlu.edu.cn') ||
    trimmedEmail.endsWith('@xjtlu.edu.cn')

  if (isXjtluStudent) {
    return {
      verified: true,
      change: 8,
      reasonEn: 'Student email verified.',
      reasonZh: '学生邮箱认证成功。',
      type: 'student_verification'
    }
  }

  return {
    verified: false,
    change: -5,
    reasonEn: 'Student email format is not verified.',
    reasonZh: '学生邮箱格式未通过认证。',
    type: 'student_verification_failed'
  }
}

function evaluateProfileCompletion(profile) {
  const requiredFields = ['nickname', 'campus', 'year', 'major', 'lookingFor']

  const completedCount = requiredFields.filter((field) => {
    return String(profile[field] || '').trim().length > 0
  }).length

  const completionRate = completedCount / requiredFields.length

  if (completionRate === 1) {
    return {
      complete: true,
      change: 4,
      reasonEn: 'Basic profile completed.',
      reasonZh: '基础资料填写完整。',
      type: 'profile_completed'
    }
  }

  return {
    complete: false,
    change: -3,
    reasonEn: 'Basic profile is incomplete.',
    reasonZh: '基础资料不完整。',
    type: 'profile_incomplete'
  }
}

function getReputationSummary(lang) {
  const reputation = initReputation()

  const levelTextMap = {
    en: {
      Excellent: 'Excellent',
      Trusted: 'Trusted',
      Caution: 'Caution',
      Restricted: 'Restricted'
    },
    zh: {
      Excellent: '优秀',
      Trusted: '可信',
      Caution: '需谨慎',
      Restricted: '受限'
    }
  }

  return {
    ...reputation,
    levelText: levelTextMap[lang || 'zh'][reputation.level] || reputation.level
  }
}

module.exports = {
  initReputation,
  updateReputation,
  evaluateStudentEmail,
  evaluateProfileCompletion,
  getReputationSummary
}