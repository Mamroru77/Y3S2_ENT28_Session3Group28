const STORAGE_KEYS = {
  USER: 'dh_user',
  PROFILE: 'dh_profile',
  QUESTIONNAIRE: 'dh_questionnaire',
  REPUTATION: 'dh_reputation',
  CHAT_REQUESTS: 'dh_chat_requests',
  REPORTS: 'dh_reports',
  BLOCKS: 'dh_blocks',
  SELECTED_CHAT_MATCH_ID: 'dh_selected_chat_match_id'
}

function saveUser(user) {
  wx.setStorageSync(STORAGE_KEYS.USER, user)
}

function getUser() {
  return wx.getStorageSync(STORAGE_KEYS.USER) || null
}

function clearUser() {
  wx.removeStorageSync(STORAGE_KEYS.USER)
}

function saveProfile(profile) {
  wx.setStorageSync(STORAGE_KEYS.PROFILE, profile)
}

function getProfile() {
  return wx.getStorageSync(STORAGE_KEYS.PROFILE) || null
}

function clearProfile() {
  wx.removeStorageSync(STORAGE_KEYS.PROFILE)
}

function saveQuestionnaire(questionnaire) {
  wx.setStorageSync(STORAGE_KEYS.QUESTIONNAIRE, questionnaire)
}

function getQuestionnaire() {
  return wx.getStorageSync(STORAGE_KEYS.QUESTIONNAIRE) || null
}

function saveReputation(reputation) {
  wx.setStorageSync(STORAGE_KEYS.REPUTATION, reputation)
}

function getReputation() {
  return wx.getStorageSync(STORAGE_KEYS.REPUTATION) || null
}

function saveSelectedChatMatchId(matchId) {
  wx.setStorageSync(STORAGE_KEYS.SELECTED_CHAT_MATCH_ID, matchId)
}

function getSelectedChatMatchId() {
  return wx.getStorageSync(STORAGE_KEYS.SELECTED_CHAT_MATCH_ID) || ''
}

function clearSelectedChatMatchId() {
  wx.removeStorageSync(STORAGE_KEYS.SELECTED_CHAT_MATCH_ID)
}

function getChatRequests() {
  return wx.getStorageSync(STORAGE_KEYS.CHAT_REQUESTS) || []
}

function saveChatRequests(requests) {
  wx.setStorageSync(STORAGE_KEYS.CHAT_REQUESTS, requests)
}

function addChatRequest(request) {
  const requests = getChatRequests()

  const existingIndex = requests.findIndex((item) => item.matchId === request.matchId)

  if (existingIndex >= 0) {
    requests[existingIndex] = {
      ...requests[existingIndex],
      ...request,
      updatedAt: new Date().toISOString()
    }
  } else {
    requests.unshift({
      ...request,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    })
  }

  saveChatRequests(requests)

  return requests
}

function getReports() {
  return wx.getStorageSync(STORAGE_KEYS.REPORTS) || []
}

function saveReports(reports) {
  wx.setStorageSync(STORAGE_KEYS.REPORTS, reports)
}

function addReport(report) {
  const reports = getReports()

  reports.unshift({
    ...report,
    createdAt: new Date().toISOString()
  })

  saveReports(reports)

  return reports
}

function getBlocks() {
  return wx.getStorageSync(STORAGE_KEYS.BLOCKS) || []
}

function saveBlocks(blocks) {
  wx.setStorageSync(STORAGE_KEYS.BLOCKS, blocks)
}

function addBlock(block) {
  const blocks = getBlocks()

  const exists = blocks.some((item) => item.matchId === block.matchId)

  if (!exists) {
    blocks.unshift({
      ...block,
      createdAt: new Date().toISOString()
    })
  }

  saveBlocks(blocks)

  return blocks
}

function isBlocked(matchId) {
  const blocks = getBlocks()
  return blocks.some((item) => item.matchId === matchId)
}

function clearAllDormHarmonyData() {
  Object.values(STORAGE_KEYS).forEach((key) => {
    wx.removeStorageSync(key)
  })
}

module.exports = {
  STORAGE_KEYS,
  saveUser,
  getUser,
  clearUser,
  saveProfile,
  getProfile,
  clearProfile,
  saveQuestionnaire,
  getQuestionnaire,
  saveReputation,
  getReputation,
  saveSelectedChatMatchId,
  getSelectedChatMatchId,
  clearSelectedChatMatchId,
  getChatRequests,
  saveChatRequests,
  addChatRequest,
  getReports,
  saveReports,
  addReport,
  getBlocks,
  saveBlocks,
  addBlock,
  isBlocked,
  clearAllDormHarmonyData
}