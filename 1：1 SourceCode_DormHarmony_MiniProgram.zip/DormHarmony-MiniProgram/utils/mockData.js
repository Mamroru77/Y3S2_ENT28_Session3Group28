const roommateCandidates = [
  {
    id: 'mia-chen',
    name: 'Mia Chen',
    year: 'Year 1',
    campusZh: '独墅湖校区',
    campusEn: 'SIP Campus',
    schoolZh: '商学院',
    schoolEn: 'Business School',
    tagsZh: ['整洁型', '安静型', '早睡型'],
    tagsEn: ['Clean', 'Quiet', 'Early Sleeper'],
    reputationScore: 94,
    reputationLevelZh: '优秀',
    reputationLevelEn: 'Excellent',
    reputationNotesZh: ['学生邮箱已认证', '资料完整', '暂无举报记录'],
    reputationNotesEn: ['Student email verified', 'Profile completed', 'No report record'],
    profile: {
      sleepTime: '00:00',
      wakeTime: '08:00',
      lightsOffTime: '00:10',
      noiseTolerance: 2,
      cleanliness: 5,
      acTemperature: '24°C',
      visitorAcceptance: 3,
      socialStyle: 3,
      spacePreference: 3,

      mbti: 'ISFJ',
      dormVibeZh: '整洁极简型',
      dormVibeEn: 'Clean & Minimal Dorm',

      lifestyleTagsZh: ['早睡党', '图书馆型', '收纳控', '噪音敏感'],
      lifestyleTagsEn: ['Early Sleeper', 'Library Type', 'Storage Lover', 'Noise Sensitive'],

      redFlagsZh: ['公共区域长期脏乱', '未经同意带访客', '凌晨外放视频'],
      redFlagsEn: ['Messy shared space', 'Visitors without notice', 'Loud videos after midnight'],

      greenFlagsZh: ['按时打扫', '尊重安静时间', '访客提前说明', '公共区域整洁'],
      greenFlagsEn: ['Cleans on time', 'Respects quiet hours', 'Visitor notice', 'Clean shared space'],

      potentialRedFlagsZh: [],
      potentialRedFlagsEn: []
    }
  },

  {
    id: 'alex-li',
    name: 'Alex Li',
    year: 'Year 2',
    campusZh: '太仓校区',
    campusEn: 'Taicang Campus',
    schoolZh: '设计学院',
    schoolEn: 'Design School',
    tagsZh: ['随和型', '社交型', '晚睡型'],
    tagsEn: ['Flexible', 'Social', 'Night Owl'],
    reputationScore: 82,
    reputationLevelZh: '可信',
    reputationLevelEn: 'Trusted',
    reputationNotesZh: ['资料完整', '问卷完成', '暂无严重负面记录'],
    reputationNotesEn: ['Profile completed', 'Questionnaire completed', 'No serious negative record'],
    profile: {
      sleepTime: '02:00',
      wakeTime: '10:30',
      lightsOffTime: '01:40',
      noiseTolerance: 4,
      cleanliness: 3,
      acTemperature: '22°C',
      visitorAcceptance: 5,
      socialStyle: 5,
      spacePreference: 4,

      mbti: 'ENFP',
      dormVibeZh: '社交活力型',
      dormVibeEn: 'Social Dorm',

      lifestyleTagsZh: ['夜猫子', '咖啡党', '游戏党', '追剧党'],
      lifestyleTagsEn: ['Night Owl', 'Coffee Person', 'Gamer', 'Drama Watcher'],

      redFlagsZh: ['冷暴力不沟通', '乱动他人物品'],
      redFlagsEn: ['Silent treatment', 'Touching others’ belongings'],

      greenFlagsZh: ['主动沟通', '费用分摊清楚', '边界感清晰'],
      greenFlagsEn: ['Active communication', 'Clear cost sharing', 'Clear boundaries'],

      potentialRedFlagsZh: ['未经同意带访客'],
      potentialRedFlagsEn: ['Visitors without notice']
    }
  },

  {
    id: 'sophia-wang',
    name: 'Sophia Wang',
    year: 'Year 1',
    campusZh: '独墅湖校区',
    campusEn: 'SIP Campus',
    schoolZh: '人文社科学院',
    schoolEn: 'Humanities',
    tagsZh: ['独立型', '非常整洁', '安静型'],
    tagsEn: ['Independent', 'Very Clean', 'Quiet'],
    reputationScore: 91,
    reputationLevelZh: '优秀',
    reputationLevelEn: 'Excellent',
    reputationNotesZh: ['学生邮箱已认证', '问卷稳定', '暂无举报记录'],
    reputationNotesEn: ['Student email verified', 'Stable questionnaire', 'No report record'],
    profile: {
      sleepTime: '23:00',
      wakeTime: '07:00',
      lightsOffTime: '23:00',
      noiseTolerance: 1,
      cleanliness: 5,
      acTemperature: '26°C',
      visitorAcceptance: 1,
      socialStyle: 2,
      spacePreference: 2,

      mbti: 'INTJ',
      dormVibeZh: '安静学习型',
      dormVibeEn: 'Quiet Study Dorm',

      lifestyleTagsZh: ['早睡党', '图书馆型', '宿舍学习型', '噪音敏感'],
      lifestyleTagsEn: ['Early Sleeper', 'Library Type', 'Dorm Study Type', 'Noise Sensitive'],

      redFlagsZh: ['凌晨外放视频', '未经同意带访客', '公共区域长期脏乱'],
      redFlagsEn: ['Loud videos after midnight', 'Visitors without notice', 'Messy shared space'],

      greenFlagsZh: ['尊重安静时间', '公共区域整洁', '边界感清晰'],
      greenFlagsEn: ['Respects quiet hours', 'Clean shared space', 'Clear boundaries'],

      potentialRedFlagsZh: [],
      potentialRedFlagsEn: []
    }
  },

  {
    id: 'ryan-zhou',
    name: 'Ryan Zhou',
    year: 'Year 3',
    campusZh: '独墅湖校区',
    campusEn: 'SIP Campus',
    schoolZh: '计算机学院',
    schoolEn: 'Computer Science',
    tagsZh: ['游戏型', '晚睡型', '随意型'],
    tagsEn: ['Gamer', 'Late Sleeper', 'Relaxed'],
    reputationScore: 63,
    reputationLevelZh: '需谨慎',
    reputationLevelEn: 'Caution',
    reputationNotesZh: ['曾被标记为作息信息不稳定', '有一次沟通投诉记录'],
    reputationNotesEn: ['Lifestyle answers were once flagged as unstable', 'One communication complaint record'],
    profile: {
      sleepTime: '03:00',
      wakeTime: '11:00',
      lightsOffTime: '02:30',
      noiseTolerance: 5,
      cleanliness: 2,
      acTemperature: '20°C',
      visitorAcceptance: 4,
      socialStyle: 4,
      spacePreference: 5,

      mbti: 'ENTP',
      dormVibeZh: '自由随和型',
      dormVibeEn: 'Flexible Dorm',

      lifestyleTagsZh: ['夜猫子', '游戏党', '外卖频繁', '追剧党'],
      lifestyleTagsEn: ['Night Owl', 'Gamer', 'Takeout Often', 'Drama Watcher'],

      redFlagsZh: ['冷暴力不沟通'],
      redFlagsEn: ['Silent treatment'],

      greenFlagsZh: ['主动沟通', '费用分摊清楚'],
      greenFlagsEn: ['Active communication', 'Clear cost sharing'],

      potentialRedFlagsZh: ['凌晨外放视频', '公共区域长期脏乱'],
      potentialRedFlagsEn: ['Loud videos after midnight', 'Messy shared space']
    }
  }
]

module.exports = {
  roommateCandidates
}