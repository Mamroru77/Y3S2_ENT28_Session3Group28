function getCommunityContent(lang) {
  const zh = {
    topics: [
      {
        id: 'topic-1',
        category: 'hot',
        tag: '热门',
        title: '宿舍几点后应进入安静时段？',
        summary: '很多同学对 23:30 之后的外放视频、电话和游戏声音比较敏感。',
        detail: '建议在入住前明确 quiet hours，例如工作日 23:30 后尽量使用耳机、避免外放和大声通话。这样能有效降低夜间冲突。',
        replies: 42,
        likes: 18
      },
      {
        id: 'topic-2',
        category: 'boundary',
        tag: '边界',
        title: '朋友来宿舍，是否一定要提前说？',
        summary: '访客问题是典型冲突点，尤其是临时带人来宿舍。',
        detail: 'DormHarmony 建议将访客规则做成明确约定：是否需要提前说明、能否过夜、频率如何控制、是否影响室友休息。',
        replies: 35,
        likes: 14
      },
      {
        id: 'topic-3',
        category: 'personality',
        tag: 'MBTI',
        title: 'MBTI 适合直接用来匹配舍友吗？',
        summary: 'MBTI 很有趣，但不应该直接决定匹配分。',
        detail: '更合理的方式是：生活习惯决定主匹配结果，MBTI / 性格标签用于解释沟通方式、相处风格和潜在表达风险。',
        replies: 27,
        likes: 21
      },
      {
        id: 'topic-4',
        category: 'housing',
        tag: '合租',
        title: '校外找舍友时最该先问什么？',
        summary: '预算、通勤、是否做饭、作息和访客边界都应该先问清。',
        detail: '建议优先确认预算上限、租期、通勤时间、卫生要求、是否常带朋友来住处，以及公共费用如何分摊。',
        replies: 19,
        likes: 9
      }
    ],

    polls: [
      {
        id: 'poll-1',
        question: '你能接受舍友最晚几点还开灯？',
        options: [
          { id: 'a', label: '23:00 前最好关灯' },
          { id: 'b', label: '00:00 还可以接受' },
          { id: 'c', label: '01:00 也可以' },
          { id: 'd', label: '无所谓' }
        ]
      },
      {
        id: 'poll-2',
        question: '你对舍友带朋友来宿舍的态度是？',
        options: [
          { id: 'a', label: '不能接受' },
          { id: 'b', label: '提前说可以' },
          { id: 'c', label: '偶尔可以' },
          { id: 'd', label: '比较自由' }
        ]
      }
    ],

    labs: [
      {
        id: 'lab-1',
        title: 'Quiet Study Dorm',
        subtitle: '安静学习型',
        description: '偏好安静、规律、边界清晰的宿舍氛围。适合重视作息、专注学习的学生。'
      },
      {
        id: 'lab-2',
        title: 'Social Dorm',
        subtitle: '社交活力型',
        description: '宿舍氛围更开放，喜欢聊天和互动，但需要提前明确安静时间与访客边界。'
      },
      {
        id: 'lab-3',
        title: 'Clean & Minimal',
        subtitle: '整洁极简型',
        description: '对公共区域整洁度要求较高，偏好明确的分工和可持续维护的清洁习惯。'
      },
      {
        id: 'lab-4',
        title: 'INTJ Style',
        subtitle: '独立规划型',
        description: '通常偏独立和结构化，适合与同样尊重边界、愿意提前约定规则的舍友相处。'
      },
      {
        id: 'lab-5',
        title: 'ENFP Style',
        subtitle: '热情社交型',
        description: '通常更有互动感和表达欲，适合作为宿舍氛围活跃者，但应控制噪音和深夜社交。'
      },
      {
        id: 'lab-6',
        title: 'Gym & Routine',
        subtitle: '规律自律型',
        description: '作息较规律，倾向稳定的生活节奏和清晰的个人目标，适合自律氛围宿舍。'
      }
    ],

    rules: [
      '社区鼓励讨论真实宿舍问题，不鼓励人身攻击。',
      '匿名发言也应遵守基本尊重和边界。',
      '话题内容可以帮助你更好理解自己的舍友偏好。'
    ]
  }

  const en = {
    topics: [
      {
        id: 'topic-1',
        category: 'hot',
        tag: 'Hot',
        title: 'When should a dorm enter quiet hours?',
        summary: 'Many students are sensitive to speaker audio, calls and gaming noise after 23:30.',
        detail: 'A practical solution is to define quiet hours before moving in. For example, after 23:30 on weekdays, use headphones and avoid loud calls or speaker audio.',
        replies: 42,
        likes: 18
      },
      {
        id: 'topic-2',
        category: 'boundary',
        tag: 'Boundary',
        title: 'Should visitors always be mentioned in advance?',
        summary: 'Visitor rules are one of the most common dorm conflict triggers.',
        detail: 'DormHarmony suggests a clear agreement: whether notice is required, whether overnight visits are acceptable, and how often visitors are allowed.',
        replies: 35,
        likes: 14
      },
      {
        id: 'topic-3',
        category: 'personality',
        tag: 'MBTI',
        title: 'Should MBTI directly determine roommate matching?',
        summary: 'MBTI is interesting, but it should not dominate the main score.',
        detail: 'A more rigorous design is to let lifestyle habits drive the main score, while MBTI and personality labels help explain communication style and possible risks.',
        replies: 27,
        likes: 21
      },
      {
        id: 'topic-4',
        category: 'housing',
        tag: 'Housing',
        title: 'What should you ask first when finding off-campus roommates?',
        summary: 'Budget, commute, cooking habits, schedule and visitor boundaries should be discussed first.',
        detail: 'Priority questions include budget cap, lease duration, commute time, cleaning expectations, visitor boundaries and how shared expenses will be split.',
        replies: 19,
        likes: 9
      }
    ],

    polls: [
      {
        id: 'poll-1',
        question: 'What is the latest lights-on time you can accept?',
        options: [
          { id: 'a', label: 'Prefer lights off before 23:00' },
          { id: 'b', label: '00:00 is acceptable' },
          { id: 'c', label: '01:00 is still okay' },
          { id: 'd', label: 'No strong preference' }
        ]
      },
      {
        id: 'poll-2',
        question: 'How do you feel about roommates bringing friends over?',
        options: [
          { id: 'a', label: 'Not acceptable' },
          { id: 'b', label: 'Okay if mentioned in advance' },
          { id: 'c', label: 'Occasionally is fine' },
          { id: 'd', label: 'Quite flexible' }
        ]
      }
    ],

    labs: [
      {
        id: 'lab-1',
        title: 'Quiet Study Dorm',
        subtitle: 'Quiet & Focused',
        description: 'A dorm vibe centered on quiet routines, clear boundaries and consistent study habits.'
      },
      {
        id: 'lab-2',
        title: 'Social Dorm',
        subtitle: 'Warm & Interactive',
        description: 'A more open and interactive dorm atmosphere, but still needs clear quiet-hour and visitor rules.'
      },
      {
        id: 'lab-3',
        title: 'Clean & Minimal',
        subtitle: 'Orderly & Neat',
        description: 'A dorm style with high expectations for shared-space cleanliness and defined responsibilities.'
      },
      {
        id: 'lab-4',
        title: 'INTJ Style',
        subtitle: 'Independent & Structured',
        description: 'Often values structure, autonomy and clear boundaries. Works well with roommates who respect rules and planning.'
      },
      {
        id: 'lab-5',
        title: 'ENFP Style',
        subtitle: 'Expressive & Social',
        description: 'Often brings energy and warmth, but needs clearer control over noise, late-night interaction and spontaneity.'
      },
      {
        id: 'lab-6',
        title: 'Gym & Routine',
        subtitle: 'Disciplined Lifestyle',
        description: 'Prefers routine, self-discipline and stable habits, making it suitable for a structured dorm environment.'
      }
    ],

    rules: [
      'The community encourages real dorm-life discussion, not personal attacks.',
      'Anonymous posts should still respect basic boundaries.',
      'Community content can help you better understand your roommate preferences.'
    ]
  }

  return lang === 'en' ? en : zh
}

module.exports = {
  getCommunityContent
}