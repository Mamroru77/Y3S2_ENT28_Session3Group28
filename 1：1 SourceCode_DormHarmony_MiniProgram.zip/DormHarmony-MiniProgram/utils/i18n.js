const dictionary = {
  en: {
    tabBar: {
      home: 'Home',
      matches: 'Matches',
      chat: 'Chat',
      profile: 'Profile'
    },

    index: {
      eyebrow: 'XJTLU Student Roommate Matching',
      title: 'DormHarmony',
      subtitle: 'Find the right roommate before conflicts happen.',
      description:
        'A warm mini program that helps students compare lifestyle habits, boundaries, and room preferences before living together.',
      startButton: 'Start Matching',
      demoButton: 'View Demo',
      languageButton: '中文',
      bearName: 'Harmony Bear',
      bearSpeech:
        'Hi, I am Harmony Bear. I will help you find a roommate who fits your lifestyle.',
      modulesTitle: 'Core Modules',
      previewTitle: 'Match Preview',
      sampleName: 'Mia Chen',
      sampleMeta: 'Year 1 · SIP Campus · Business School',
      sampleStrength: 'Similar sleep schedule and cleanliness expectations.',
      sampleRisk: 'Visitor boundary needs further discussion.',
      features: [
        {
          title: 'Lifestyle Questionnaire',
          subtitle: 'Quick lifestyle profile',
          desc: 'Collect sleep time, cleanliness, noise tolerance, AC preference and visitor boundaries.'
        },
        {
          title: 'Compatibility Matching',
          subtitle: 'Explainable score',
          desc: 'Calculate roommate compatibility with weighted lifestyle indicators and conflict rules.'
        },
        {
          title: 'Warm Guidance',
          subtitle: 'Harmony Bear assistant',
          desc: 'Use a friendly bear companion to explain results and suggest communication topics.'
        }
      ],
      dimensions: [
        { label: 'Sleep Schedule', score: 92 },
        { label: 'Cleanliness', score: 88 },
        { label: 'Noise Tolerance', score: 84 },
        { label: 'Visitor Boundary', score: 67 }
      ]
    },

    login: {
      eyebrow: 'Account Access',
      title: 'Login',
      desc: 'Use a student email to simulate verification. This MVP does not connect to the real university system yet.',
      bearName: 'Harmony Bear',
      bearSpeech:
        'A verified student profile helps improve trust and reduces fake roommate information.',
      nickname: 'Nickname',
      nicknamePlaceholder: 'Alex',
      email: 'Student Email',
      emailPlaceholder: 'example@student.xjtlu.edu.cn',
      loginButton: 'Verify and Continue',
      skipButton: 'Continue as Demo User',
      reputationTitle: 'Trust Rule',
      reputationDesc:
        'Verified student identity improves reputation. Fake or suspicious information may reduce reputation score.'
    },

    profileSetup: {
      eyebrow: 'Step 1 of 3',
      title: 'Basic Profile',
      desc: 'Tell us your campus, year, major and roommate preference. Complete information improves matching quality and reputation.',
      bearName: 'Harmony Bear',
      bearSpeech:
        'Clear basic information helps others understand who they may live with.',
      nickname: 'Nickname',
      university: 'University',
      campus: 'Campus',
      campusPlaceholder: 'Select campus',
      sipCampus: 'SIP Campus',
      taicangCampus: 'Taicang Campus',
      year: 'Year',
      yearPlaceholder: 'Select year',
      major: 'Major',
      majorPlaceholder: 'Supply Chain Management',
      lookingFor: 'Looking For',
      lookingForPlaceholder: 'Select option',
      dormRoommate: 'Dorm roommate',
      flatmate: 'Off-campus flatmate',
      both: 'Both',
      saveButton: 'Save and Continue',
      trustNoteTitle: 'Reputation Mechanism',
      trustNote:
        'Incomplete or misleading profile information may reduce the trust score.'
    },

    profile: {
      eyebrow: 'My Account',
      title: 'Profile',
      desc: 'Manage your profile, privacy settings and DormHarmony reputation.',
      verified: 'Verified Student',
      unverified: 'Unverified',
      reputation: 'Reputation Score',
      level: 'Level',
      records: 'Reputation Records',
      editProfile: 'Edit Basic Profile',
      updateQuestionnaire: 'Update Questionnaire',
      privacy: 'Privacy Settings',
      reset: 'Reset Local Data',
      noUser: 'No user profile yet.',
      noRecords: 'No reputation records yet.'
    },

    common: {
      languageButton: '中文',
      notSet: 'Not set'
    },

    placeholder: {
      questionnaireTitle: 'Questionnaire',
      questionnaireDesc: 'Lifestyle questions will be built here.',
      matchesTitle: 'Matches',
      matchesDesc: 'Recommended roommate matches will appear here.',
      matchDetailTitle: 'Match Detail',
      matchDetailDesc: 'Compatibility score, strengths and risks will appear here.',
      chatTitle: 'Chat',
      chatDesc: 'Chat request and safe communication will be built here.'
    }
  },

  zh: {
    tabBar: {
      home: '首页',
      matches: '匹配',
      chat: '沟通',
      profile: '我的'
    },

    index: {
      eyebrow: '西浦学生舍友匹配工具',
      title: 'DormHarmony',
      subtitle: '在冲突发生之前，找到更合适的舍友。',
      description:
        '一款温暖、简洁的舍友匹配小程序，帮助学生在合住前了解彼此的生活习惯、边界和宿舍偏好。',
      startButton: '开始匹配',
      demoButton: '查看演示',
      languageButton: 'EN',
      bearName: '哈米熊',
      bearSpeech:
        '你好呀，我是哈米熊。我会陪你一起找到生活习惯更合适的舍友。',
      modulesTitle: '核心功能',
      previewTitle: '匹配预览',
      sampleName: 'Mia Chen',
      sampleMeta: '大一 · 独墅湖校区 · 商学院',
      sampleStrength: '作息时间和卫生习惯比较接近。',
      sampleRisk: '访客接受度需要进一步沟通。',
      features: [
        {
          title: '生活习惯问卷',
          subtitle: '快速建立用户画像',
          desc: '收集作息、卫生、噪音、空调温度、访客边界等关键生活习惯。'
        },
        {
          title: '舍友匹配算法',
          subtitle: '可解释的匹配分数',
          desc: '基于加权生活指标和硬性冲突规则，计算舍友匹配度。'
        },
        {
          title: '温暖沟通引导',
          subtitle: '哈米熊助手',
          desc: '用可爱的宠物助手解释匹配结果，并给出建议沟通话题。'
        }
      ],
      dimensions: [
        { label: '作息时间', score: 92 },
        { label: '卫生整洁', score: 88 },
        { label: '噪音忍受度', score: 84 },
        { label: '访客边界', score: 67 }
      ]
    },

    login: {
      eyebrow: '账户进入',
      title: '登录',
      desc: '使用学生邮箱进行模拟认证。MVP 阶段暂不真实接入学校系统。',
      bearName: '哈米熊',
      bearSpeech:
        '完成学生身份认证可以提高可信度，也能减少虚假舍友信息。',
      nickname: '昵称',
      nicknamePlaceholder: 'Alex',
      email: '学生邮箱',
      emailPlaceholder: 'example@student.xjtlu.edu.cn',
      loginButton: '认证并继续',
      skipButton: '使用演示身份继续',
      reputationTitle: '信誉规则',
      reputationDesc:
        '学生身份认证会提高信誉分。虚假或可疑信息会降低信誉分。'
    },

    profileSetup: {
      eyebrow: '第 1 步，共 3 步',
      title: '基础资料',
      desc: '填写校区、年级、专业和找舍友偏好。资料越完整，匹配越准确，信誉分也越稳定。',
      bearName: '哈米熊',
      bearSpeech:
        '清晰的基础资料能帮助别人了解未来可能一起生活的人。',
      nickname: '昵称',
      university: '学校',
      campus: '校区',
      campusPlaceholder: '选择校区',
      sipCampus: '独墅湖校区',
      taicangCampus: '太仓校区',
      year: '年级',
      yearPlaceholder: '选择年级',
      major: '专业',
      majorPlaceholder: '供应链管理',
      lookingFor: '寻找类型',
      lookingForPlaceholder: '选择类型',
      dormRoommate: '宿舍舍友',
      flatmate: '校外合租室友',
      both: '都可以',
      saveButton: '保存并继续',
      trustNoteTitle: '信誉分机制',
      trustNote:
        '资料不完整或存在误导性信息，后续可能会降低用户信誉分。'
    },

    profile: {
      eyebrow: '我的账户',
      title: '我的',
      desc: '管理个人资料、隐私设置和 DormHarmony 信誉分。',
      verified: '已认证学生',
      unverified: '未认证',
      reputation: '信誉分',
      level: '等级',
      records: '信誉记录',
      editProfile: '编辑基础资料',
      updateQuestionnaire: '更新生活问卷',
      privacy: '隐私设置',
      reset: '清除本地数据',
      noUser: '还没有用户资料。',
      noRecords: '暂无信誉记录。'
    },

    common: {
      languageButton: 'EN',
      notSet: '未填写'
    },

    placeholder: {
      questionnaireTitle: '生活问卷',
      questionnaireDesc: '这里会建立完整的生活习惯问卷。',
      matchesTitle: '舍友匹配',
      matchesDesc: '这里会展示推荐舍友列表。',
      matchDetailTitle: '匹配详情',
      matchDetailDesc: '这里会展示匹配分、风险点和沟通建议。',
      chatTitle: '沟通申请',
      chatDesc: '这里会设计安全私信和沟通申请功能。'
    }
  }
}

function getCurrentLang() {
  return wx.getStorageSync('dh_lang') || 'zh'
}

function setCurrentLang(lang) {
  wx.setStorageSync('dh_lang', lang)
}

function getPageText(pageName, lang) {
  const currentLang = lang || getCurrentLang()
  return dictionary[currentLang][pageName]
}

function getTabBarText(lang) {
  const currentLang = lang || getCurrentLang()
  return dictionary[currentLang].tabBar
}

module.exports = {
  dictionary,
  getCurrentLang,
  setCurrentLang,
  getPageText,
  getTabBarText
}