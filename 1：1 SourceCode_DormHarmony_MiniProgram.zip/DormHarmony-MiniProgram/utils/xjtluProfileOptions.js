const campusOptions = [
  {
    code: 'SIP',
    name: 'SIP Campus',
    zhName: 'SIP Campus',
    enName: 'SIP Campus'
  },
  {
    code: 'TC',
    name: 'TC Campus',
    zhName: 'TC Campus',
    enName: 'TC Campus'
  }
]

const schoolOptionsByCampus = {
  SIP: [
    {
      code: 'IBSS',
      name: 'International Business School Suzhou',
      zhName: 'International Business School Suzhou',
      enName: 'International Business School Suzhou'
    },
    {
      code: 'SAT',
      name: 'School of Advanced Technology',
      zhName: 'School of Advanced Technology',
      enName: 'School of Advanced Technology'
    },
    {
      code: 'DESIGN',
      name: 'Design School',
      zhName: 'Design School',
      enName: 'Design School'
    },
    {
      code: 'HSS',
      name: 'School of Humanities and Social Sciences',
      zhName: 'School of Humanities and Social Sciences',
      enName: 'School of Humanities and Social Sciences'
    },
    {
      code: 'MATH_PHYSICS',
      name: 'School of Mathematics and Physics',
      zhName: 'School of Mathematics and Physics',
      enName: 'School of Mathematics and Physics'
    },
    {
      code: 'SCIENCE',
      name: 'School of Science',
      zhName: 'School of Science',
      enName: 'School of Science'
    },
    {
      code: 'AFCT_SIP',
      name: 'Academy of Film and Creative Technology',
      zhName: 'Academy of Film and Creative Technology',
      enName: 'Academy of Film and Creative Technology'
    },
    {
      code: 'WLAP',
      name: 'XJTLU Wisdom Lake Academy of Pharmacy',
      zhName: 'XJTLU Wisdom Lake Academy of Pharmacy',
      enName: 'XJTLU Wisdom Lake Academy of Pharmacy'
    },
    {
      code: 'OTHER_SIP',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  TC: [
    {
      code: 'AIAC',
      name: 'School of AI and Advanced Computing',
      zhName: 'School of AI and Advanced Computing',
      enName: 'School of AI and Advanced Computing'
    },
    {
      code: 'CHIPS',
      name: 'School of CHIPS',
      zhName: 'School of CHIPS',
      enName: 'School of CHIPS'
    },
    {
      code: 'SIFB',
      name: 'School of Intelligent Finance and Business',
      zhName: 'School of Intelligent Finance and Business',
      enName: 'School of Intelligent Finance and Business'
    },
    {
      code: 'SIME',
      name: 'School of Intelligent Manufacturing Ecosystem',
      zhName: 'School of Intelligent Manufacturing Ecosystem',
      enName: 'School of Intelligent Manufacturing Ecosystem'
    },
    {
      code: 'IOT',
      name: 'School of Internet of Things',
      zhName: 'School of Internet of Things',
      enName: 'School of Internet of Things'
    },
    {
      code: 'ROBOTICS',
      name: 'School of Robotics',
      zhName: 'School of Robotics',
      enName: 'School of Robotics'
    },
    {
      code: 'AFCT_TC',
      name: 'Academy of Film and Creative Technology',
      zhName: 'Academy of Film and Creative Technology',
      enName: 'Academy of Film and Creative Technology'
    },
    {
      code: 'OTHER_TC',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ]
}

const programmeOptionsBySchool = {
  IBSS: [
    {
      code: 'ACCOUNTING',
      name: 'Accounting BA (Hons)',
      zhName: 'Accounting BA (Hons)',
      enName: 'Accounting BA (Hons)'
    },
    {
      code: 'BUSINESS_ADMINISTRATION',
      name: 'Business Administration BA (Hons)',
      zhName: 'Business Administration BA (Hons)',
      enName: 'Business Administration BA (Hons)'
    },
    {
      code: 'DIGITAL_INTELLIGENT_MARKETING',
      name: 'Digital and Intelligent Marketing BA (Hons)',
      zhName: 'Digital and Intelligent Marketing BA (Hons)',
      enName: 'Digital and Intelligent Marketing BA (Hons)'
    },
    {
      code: 'ECONOMICS',
      name: 'Economics BSc (Hons)',
      zhName: 'Economics BSc (Hons)',
      enName: 'Economics BSc (Hons)'
    },
    {
      code: 'ECONOMICS_FINANCE',
      name: 'Economics and Finance BSc (Hons)',
      zhName: 'Economics and Finance BSc (Hons)',
      enName: 'Economics and Finance BSc (Hons)'
    },
    {
      code: 'HRM_PEOPLE_ANALYTICS',
      name: 'Human Resource Management and People Analytics BA (Hons)',
      zhName: 'Human Resource Management and People Analytics BA (Hons)',
      enName: 'Human Resource Management and People Analytics BA (Hons)'
    },
    {
      code: 'IMIS',
      name: 'Information Management and Information Systems BSc (Hons)',
      zhName: 'Information Management and Information Systems BSc (Hons)',
      enName: 'Information Management and Information Systems BSc (Hons)'
    },
    {
      code: 'INTERNATIONAL_BUSINESS_LANGUAGE',
      name: 'International Business with a Language BA (Hons)',
      zhName: 'International Business with a Language BA (Hons)',
      enName: 'International Business with a Language BA (Hons)'
    },
    {
      code: 'OTHER_IBSS',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  SAT: [
    {
      code: 'ARTIFICIAL_INTELLIGENCE_SIP',
      name: 'Artificial Intelligence BEng (Hons)',
      zhName: 'Artificial Intelligence BEng (Hons)',
      enName: 'Artificial Intelligence BEng (Hons)'
    },
    {
      code: 'COMPUTER_SCIENCE_TECHNOLOGY',
      name: 'Computer Science and Technology BEng (Hons)',
      zhName: 'Computer Science and Technology BEng (Hons)',
      enName: 'Computer Science and Technology BEng (Hons)'
    },
    {
      code: 'DIGITAL_MEDIA_TECHNOLOGY',
      name: 'Digital Media Technology BEng (Hons)',
      zhName: 'Digital Media Technology BEng (Hons)',
      enName: 'Digital Media Technology BEng (Hons)'
    },
    {
      code: 'ELECTRICAL_ENGINEERING',
      name: 'Electrical Engineering BEng (Hons)',
      zhName: 'Electrical Engineering BEng (Hons)',
      enName: 'Electrical Engineering BEng (Hons)'
    },
    {
      code: 'ELECTRONIC_SCIENCE_TECHNOLOGY',
      name: 'Electronic Science and Technology BEng (Hons)',
      zhName: 'Electronic Science and Technology BEng (Hons)',
      enName: 'Electronic Science and Technology BEng (Hons)'
    },
    {
      code: 'INFORMATION_COMPUTING_SCIENCE',
      name: 'Information and Computing Science BSc (Hons)',
      zhName: 'Information and Computing Science BSc (Hons)',
      enName: 'Information and Computing Science BSc (Hons)'
    },
    {
      code: 'MECHATRONICS_ROBOTIC_SYSTEMS',
      name: 'Mechatronics and Robotic Systems BEng (Hons)',
      zhName: 'Mechatronics and Robotic Systems BEng (Hons)',
      enName: 'Mechatronics and Robotic Systems BEng (Hons)'
    },
    {
      code: 'TELECOMMUNICATIONS_ENGINEERING',
      name: 'Telecommunications Engineering BEng (Hons)',
      zhName: 'Telecommunications Engineering BEng (Hons)',
      enName: 'Telecommunications Engineering BEng (Hons)'
    },
    {
      code: 'OTHER_SAT',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  DESIGN: [
    {
      code: 'ARCHITECTURE',
      name: 'Architecture BEng (Hons)',
      zhName: 'Architecture BEng (Hons)',
      enName: 'Architecture BEng (Hons)'
    },
    {
      code: 'CIVIL_ENGINEERING',
      name: 'Civil Engineering BEng (Hons)',
      zhName: 'Civil Engineering BEng (Hons)',
      enName: 'Civil Engineering BEng (Hons)'
    },
    {
      code: 'INDUSTRIAL_DESIGN',
      name: 'Industrial Design BEng (Hons)',
      zhName: 'Industrial Design BEng (Hons)',
      enName: 'Industrial Design BEng (Hons)'
    },
    {
      code: 'URBAN_PLANNING_DESIGN',
      name: 'Urban Planning and Design BA (Hons)',
      zhName: 'Urban Planning and Design BA (Hons)',
      enName: 'Urban Planning and Design BA (Hons)'
    },
    {
      code: 'OTHER_DESIGN',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  HSS: [
    {
      code: 'APPLIED_LINGUISTICS',
      name: 'Applied Linguistics BA (Hons)',
      zhName: 'Applied Linguistics BA (Hons)',
      enName: 'Applied Linguistics BA (Hons)'
    },
    {
      code: 'CHINA_STUDIES',
      name: 'China Studies BA (Hons)',
      zhName: 'China Studies BA (Hons)',
      enName: 'China Studies BA (Hons)'
    },
    {
      code: 'ENGLISH_BUSINESS',
      name: 'English and Business BA (Hons)',
      zhName: 'English and Business BA (Hons)',
      enName: 'English and Business BA (Hons)'
    },
    {
      code: 'ENGLISH_COMMUNICATION_STUDIES',
      name: 'English and Communication Studies BA (Hons)',
      zhName: 'English and Communication Studies BA (Hons)',
      enName: 'English and Communication Studies BA (Hons)'
    },
    {
      code: 'ENGLISH_GLOBAL_CONTEXT',
      name: 'English Studies in Global Context BA (Hons)',
      zhName: 'English Studies in Global Context BA (Hons)',
      enName: 'English Studies in Global Context BA (Hons)'
    },
    {
      code: 'INTERNATIONAL_RELATIONS',
      name: 'International Relations BA (Hons)',
      zhName: 'International Relations BA (Hons)',
      enName: 'International Relations BA (Hons)'
    },
    {
      code: 'MEDIA_COMMUNICATION_STUDIES',
      name: 'Media and Communication Studies BA (Hons)',
      zhName: 'Media and Communication Studies BA (Hons)',
      enName: 'Media and Communication Studies BA (Hons)'
    },
    {
      code: 'TRANSLATION_INTERPRETING',
      name: 'Translation and Interpreting BA (Hons)',
      zhName: 'Translation and Interpreting BA (Hons)',
      enName: 'Translation and Interpreting BA (Hons)'
    },
    {
      code: 'OTHER_HSS',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  MATH_PHYSICS: [
    {
      code: 'ACTUARIAL_SCIENCE',
      name: 'Actuarial Science BSc (Hons)',
      zhName: 'Actuarial Science BSc (Hons)',
      enName: 'Actuarial Science BSc (Hons)'
    },
    {
      code: 'APPLIED_MATHEMATICS',
      name: 'Applied Mathematics BSc (Hons)',
      zhName: 'Applied Mathematics BSc (Hons)',
      enName: 'Applied Mathematics BSc (Hons)'
    },
    {
      code: 'FINANCIAL_MATHEMATICS',
      name: 'Financial Mathematics BSc (Hons)',
      zhName: 'Financial Mathematics BSc (Hons)',
      enName: 'Financial Mathematics BSc (Hons)'
    },
    {
      code: 'OTHER_MATH_PHYSICS',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  SCIENCE: [
    {
      code: 'APPLIED_CHEMISTRY',
      name: 'Applied Chemistry BSc (Hons)',
      zhName: 'Applied Chemistry BSc (Hons)',
      enName: 'Applied Chemistry BSc (Hons)'
    },
    {
      code: 'BIOINFORMATICS',
      name: 'Bioinformatics BSc (Hons)',
      zhName: 'Bioinformatics BSc (Hons)',
      enName: 'Bioinformatics BSc (Hons)'
    },
    {
      code: 'BIOLOGICAL_SCIENCES',
      name: 'Biological Sciences BSc (Hons)',
      zhName: 'Biological Sciences BSc (Hons)',
      enName: 'Biological Sciences BSc (Hons)'
    },
    {
      code: 'BIOMEDICAL_SCIENCES',
      name: 'Biomedical Sciences BSc (Hons)',
      zhName: 'Biomedical Sciences BSc (Hons)',
      enName: 'Biomedical Sciences BSc (Hons)'
    },
    {
      code: 'ENVIRONMENTAL_SCIENCE',
      name: 'Environmental Science BSc (Hons)',
      zhName: 'Environmental Science BSc (Hons)',
      enName: 'Environmental Science BSc (Hons)'
    },
    {
      code: 'MATERIALS_SCIENCE_ENGINEERING',
      name: 'Materials Science and Engineering BEng (Hons)',
      zhName: 'Materials Science and Engineering BEng (Hons)',
      enName: 'Materials Science and Engineering BEng (Hons)'
    },
    {
      code: 'OTHER_SCIENCE',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  AFCT_SIP: [
    {
      code: 'DIGITAL_MEDIA_ARTS',
      name: 'Digital Media Arts BA (Hons)',
      zhName: 'Digital Media Arts BA (Hons)',
      enName: 'Digital Media Arts BA (Hons)'
    },
    {
      code: 'FILMMAKING',
      name: 'Filmmaking BA (Hons)',
      zhName: 'Filmmaking BA (Hons)',
      enName: 'Filmmaking BA (Hons)'
    },
    {
      code: 'TV_PRODUCTION',
      name: 'TV Production BA (Hons)',
      zhName: 'TV Production BA (Hons)',
      enName: 'TV Production BA (Hons)'
    },
    {
      code: 'ARTS_TECH_ENTREPRENEURIALISM_SIP',
      name: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)',
      zhName: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)',
      enName: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)'
    },
    {
      code: 'OTHER_AFCT_SIP',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  WLAP: [
    {
      code: 'PHARMACEUTICAL_SCIENCE',
      name: 'Pharmaceutical Science / Pharmacy-related programme',
      zhName: 'Pharmaceutical Science / Pharmacy-related programme',
      enName: 'Pharmaceutical Science / Pharmacy-related programme'
    },
    {
      code: 'OTHER_WLAP',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  AIAC: [
    {
      code: 'ARTIFICIAL_INTELLIGENCE_TC',
      name: 'Artificial Intelligence BEng (Hons)',
      zhName: 'Artificial Intelligence BEng (Hons)',
      enName: 'Artificial Intelligence BEng (Hons)'
    },
    {
      code: 'DATA_SCIENCE_BIG_DATA_CE',
      name: 'Data Science and Big Data Technology with Contemporary Entrepreneurialism BEng (Hons)',
      zhName: 'Data Science and Big Data Technology with Contemporary Entrepreneurialism BEng (Hons)',
      enName: 'Data Science and Big Data Technology with Contemporary Entrepreneurialism BEng (Hons)'
    },
    {
      code: 'OTHER_AIAC',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  CHIPS: [
    {
      code: 'MICROELECTRONIC_SCIENCE_ENGINEERING_CE',
      name: 'Microelectronic Science and Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      zhName: 'Microelectronic Science and Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      enName: 'Microelectronic Science and Engineering with Contemporary Entrepreneurialism BEng (Hons)'
    },
    {
      code: 'OTHER_CHIPS',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  SIFB: [
    {
      code: 'INTELLIGENT_SUPPLY_CHAIN_CE',
      name: 'Intelligent Supply Chain with Contemporary Entrepreneurialism BSc (Hons)',
      zhName: 'Intelligent Supply Chain with Contemporary Entrepreneurialism BSc (Hons)',
      enName: 'Intelligent Supply Chain with Contemporary Entrepreneurialism BSc (Hons)'
    },
    {
      code: 'OTHER_SIFB',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  SIME: [
    {
      code: 'INTELLIGENT_MANUFACTURING_ENGINEERING_CE',
      name: 'Intelligent Manufacturing Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      zhName: 'Intelligent Manufacturing Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      enName: 'Intelligent Manufacturing Engineering with Contemporary Entrepreneurialism BEng (Hons)'
    },
    {
      code: 'OTHER_SIME',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  IOT: [
    {
      code: 'INTERNET_OF_THINGS_ENGINEERING_CE',
      name: 'Internet of Things Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      zhName: 'Internet of Things Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      enName: 'Internet of Things Engineering with Contemporary Entrepreneurialism BEng (Hons)'
    },
    {
      code: 'OTHER_IOT',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  ROBOTICS: [
    {
      code: 'INTELLIGENT_ROBOTICS_ENGINEERING_CE',
      name: 'Intelligent Robotics Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      zhName: 'Intelligent Robotics Engineering with Contemporary Entrepreneurialism BEng (Hons)',
      enName: 'Intelligent Robotics Engineering with Contemporary Entrepreneurialism BEng (Hons)'
    },
    {
      code: 'OTHER_ROBOTICS',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  AFCT_TC: [
    {
      code: 'ARTS_TECH_ENTREPRENEURIALISM_TC',
      name: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)',
      zhName: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)',
      enName: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)'
    },
    {
      code: 'OTHER_AFCT_TC',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  OTHER_SIP: [
    {
      code: 'OTHER_PROGRAMME_SIP',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ],

  OTHER_TC: [
    {
      code: 'OTHER_PROGRAMME_TC',
      name: 'Other / Not listed',
      zhName: 'Other / Not listed',
      enName: 'Other / Not listed'
    }
  ]
}

function getDisplayName(option, lang) {
  if (!option) return ''

  if (lang === 'zh') {
    return option.zhName || option.name || ''
  }

  return option.enName || option.name || ''
}

function getCampusByCode(campusCode) {
  return campusOptions.find(item => item.code === campusCode) || campusOptions[0]
}

function getSchoolsByCampus(campusCode) {
  return schoolOptionsByCampus[campusCode] || schoolOptionsByCampus.SIP
}

function getSchoolByCode(campusCode, schoolCode) {
  const schools = getSchoolsByCampus(campusCode)
  return schools.find(item => item.code === schoolCode) || schools[0]
}

function getProgrammesBySchool(schoolCode) {
  return programmeOptionsBySchool[schoolCode] || []
}

function getProgrammeByCode(schoolCode, programmeCode) {
  const programmes = getProgrammesBySchool(schoolCode)
  return programmes.find(item => item.code === programmeCode) || programmes[0]
}

function getCampusLabels(lang) {
  return campusOptions.map(item => getDisplayName(item, lang))
}

function getSchoolLabels(campusCode, lang) {
  return getSchoolsByCampus(campusCode).map(item => getDisplayName(item, lang))
}

function getProgrammeLabels(schoolCode, lang) {
  return getProgrammesBySchool(schoolCode).map(item => getDisplayName(item, lang))
}

function validateProfileSelection(campusCode, schoolCode, programmeCode) {
  const campus = campusOptions.find(item => item.code === campusCode)

  if (!campus) {
    return {
      ok: false,
      code: 'INVALID_CAMPUS'
    }
  }

  const schools = getSchoolsByCampus(campusCode)
  const school = schools.find(item => item.code === schoolCode)

  if (!school) {
    return {
      ok: false,
      code: 'INVALID_SCHOOL_FOR_CAMPUS'
    }
  }

  const programmes = getProgrammesBySchool(schoolCode)
  const programme = programmes.find(item => item.code === programmeCode)

  if (!programme) {
    return {
      ok: false,
      code: 'INVALID_PROGRAMME_FOR_SCHOOL'
    }
  }

  return {
    ok: true,
    campus,
    school,
    programme
  }
}

module.exports = {
  campusOptions,
  schoolOptionsByCampus,
  programmeOptionsBySchool,

  getDisplayName,
  getCampusByCode,
  getSchoolsByCampus,
  getSchoolByCode,
  getProgrammesBySchool,
  getProgrammeByCode,

  getCampusLabels,
  getSchoolLabels,
  getProgrammeLabels,

  validateProfileSelection
}