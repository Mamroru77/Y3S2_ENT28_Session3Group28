Component({
  properties: {
    title: {
      type: String,
      value: '哈米熊'
    },
    speech: {
      type: String,
      value: '欢迎来到 DormHarmony。'
    },
    actionText: {
      type: String,
      value: ''
    },

    // 兼容旧页面传入的参数，但组件内部不再使用展开/收起逻辑
    expandText: {
      type: String,
      value: ''
    },
    collapseText: {
      type: String,
      value: ''
    },
    defaultCollapsed: {
      type: Boolean,
      value: false
    }
  },

  data: {},

  methods: {
    onActionTap() {
      this.triggerEvent('action')
    }
  }
})