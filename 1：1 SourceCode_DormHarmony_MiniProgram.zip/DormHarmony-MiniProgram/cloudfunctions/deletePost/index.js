const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const postId = cleanText(event.postId)

  if (!postId) {
    return {
      ok: false,
      code: 'EMPTY_POST_ID',
      message: 'Post ID is required.'
    }
  }

  const postRes = await db.collection('posts')
    .doc(postId)
    .get()
    .catch(() => null)

  if (!postRes || !postRes.data || postRes.data.status !== 'published') {
    return {
      ok: false,
      code: 'POST_NOT_FOUND',
      message: 'Post not found.'
    }
  }

  const post = postRes.data

  if (post.authorOpenid !== openid) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You can only delete your own post.'
    }
  }

  await db.collection('posts').doc(postId).update({
    data: {
      status: 'deleted',
      deletedAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })

  return {
    ok: true,
    postId
  }
}