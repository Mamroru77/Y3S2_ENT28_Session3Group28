const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value && value.$date) {
    date = new Date(value.$date)
  }

  if (!date || Number.isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const postId = cleanText(event.postId || event.id)

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  if (!postId) {
    return {
      ok: false,
      code: 'EMPTY_POST_ID',
      message: 'Post ID is required.'
    }
  }

  const postRes = await db.collection('posts')
    .doc(postId)
    .get()
    .catch(() => null)

  if (!postRes || !postRes.data || postRes.data.status === 'deleted') {
    return {
      ok: false,
      code: 'POST_NOT_FOUND',
      message: 'Post not found.'
    }
  }

  const post = postRes.data

  return {
    ok: true,
    post: {
      ...post,
      id: post._id,
      isMine: post.authorOpenid === openid,
      timeText: formatTime(post.createdAt)
    }
  }
}