const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const targetType = String(event.targetType || 'post')
  const targetId = String(event.targetId || '')

  if (!targetId) {
    return {
      ok: false,
      code: 'EMPTY_TARGET_ID',
      message: 'Target ID is required.'
    }
  }

  if (targetType !== 'post') {
    return {
      ok: false,
      code: 'UNSUPPORTED_TARGET_TYPE',
      message: 'Only post like is supported now.'
    }
  }

  const existingRes = await db.collection('likes')
    .where({
      openid,
      targetType,
      targetId
    })
    .limit(1)
    .get()

  const existing = existingRes.data && existingRes.data[0]

  if (existing) {
    await db.collection('likes').doc(existing._id).remove()

    await db.collection('posts').doc(targetId).update({
      data: {
        likeCount: _.inc(-1),
        updatedAt: db.serverDate()
      }
    })

    return {
      ok: true,
      liked: false
    }
  }

  await db.collection('likes').add({
    data: {
      openid,
      targetType,
      targetId,
      createdAt: db.serverDate()
    }
  })

  await db.collection('posts').doc(targetId).update({
    data: {
      likeCount: _.inc(1),
      updatedAt: db.serverDate()
    }
  })

  return {
    ok: true,
    liked: true
  }
}