const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

async function checkContentSafety(content, scene, title, nickname) {
  const res = await cloud.callFunction({
    name: 'contentCheck',
    data: {
      content,
      scene,
      title,
      nickname
    }
  })

  return res.result || {}
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const postId = cleanText(event.postId)
  const title = cleanText(event.title)
  const content = cleanText(event.content)
  const category = cleanText(event.category || 'boundary')

  if (!postId) {
    return {
      ok: false,
      code: 'EMPTY_POST_ID',
      message: 'Post ID is required.'
    }
  }

  if (!title) {
    return {
      ok: false,
      code: 'EMPTY_TITLE',
      message: 'Title is required.'
    }
  }

  if (!content) {
    return {
      ok: false,
      code: 'EMPTY_CONTENT',
      message: 'Content is required.'
    }
  }

  if (title.length > 60) {
    return {
      ok: false,
      code: 'TITLE_TOO_LONG',
      message: 'Title is too long.'
    }
  }

  if (content.length > 500) {
    return {
      ok: false,
      code: 'CONTENT_TOO_LONG',
      message: 'Content is too long.'
    }
  }

  const postRes = await db.collection('posts')
    .doc(postId)
    .get()
    .catch(() => null)

  if (!postRes || !postRes.data || postRes.data.status !== 'published') {
    return {
      ok: false,
      code: 'POST_NOT_FOUND',
      message: 'Post not found.'
    }
  }

  const post = postRes.data

  if (post.authorOpenid !== openid) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You can only edit your own post.'
    }
  }

  const titleCheck = await checkContentSafety(title, 'forum', title, post.authorName || 'Dorm User')

  if (!titleCheck.ok || !titleCheck.safe) {
    return {
      ok: false,
      code: titleCheck.code || 'TITLE_CONTENT_RISK',
      message: titleCheck.message || 'Title may contain risky content.'
    }
  }

  const contentCheck = await checkContentSafety(content, 'forum', title, post.authorName || 'Dorm User')

  if (!contentCheck.ok || !contentCheck.safe) {
    return {
      ok: false,
      code: contentCheck.code || 'POST_CONTENT_RISK',
      message: contentCheck.message || 'Post content may contain risky content.'
    }
  }

  await db.collection('posts').doc(postId).update({
    data: {
      title,
      content,
      category,
      updatedAt: db.serverDate(),
      moderationStatus: 'passed'
    }
  })

  const updatedRes = await db.collection('posts').doc(postId).get()

  return {
    ok: true,
    post: updatedRes.data
  }
}