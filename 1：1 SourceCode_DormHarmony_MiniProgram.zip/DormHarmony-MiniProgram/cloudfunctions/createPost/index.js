const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

async function getOrCreateUser(openid) {
  try {
    const res = await db.collection('users').doc(openid).get()
    return res.data
  } catch (e) {
    const user = {
      _id: openid,
      openid,
      nickname: 'Dorm User',
      avatarText: 'D',
      email: '',
      emailVerified: false,
      verificationStatus: 'skipped',
      reputationScore: 100,
      role: 'student',
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }

    await db.collection('users').add({
      data: user
    })

    return user
  }
}

async function checkContentSafety(content, scene, title, nickname) {
  const res = await cloud.callFunction({
    name: 'contentCheck',
    data: {
      content,
      scene,
      title,
      nickname
    }
  })

  return res.result || {}
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const title = cleanText(event.title)
  const content = cleanText(event.content)
  const category = cleanText(event.category) || 'general'
  const authorName = cleanText(event.authorName) || 'Dorm User'

  if (!title) {
    return {
      ok: false,
      code: 'EMPTY_TITLE',
      message: 'Title is required.'
    }
  }

  if (!content) {
    return {
      ok: false,
      code: 'EMPTY_CONTENT',
      message: 'Content is required.'
    }
  }

  if (title.length > 60) {
    return {
      ok: false,
      code: 'TITLE_TOO_LONG',
      message: 'Title is too long.'
    }
  }

  if (content.length > 500) {
    return {
      ok: false,
      code: 'CONTENT_TOO_LONG',
      message: 'Content is too long.'
    }
  }

  const user = await getOrCreateUser(openid)

  const titleCheck = await checkContentSafety(title, 'forum', title, user.nickname || authorName)

  if (!titleCheck.ok || !titleCheck.safe) {
    return {
      ok: false,
      code: titleCheck.code || 'TITLE_CONTENT_RISK',
      message: titleCheck.message || 'Title may contain risky content.'
    }
  }

  const contentCheck = await checkContentSafety(content, 'forum', title, user.nickname || authorName)

  if (!contentCheck.ok || !contentCheck.safe) {
    return {
      ok: false,
      code: contentCheck.code || 'POST_CONTENT_RISK',
      message: contentCheck.message || 'Post content may contain risky content.'
    }
  }

  const postData = {
    title,
    content,
    category,
    authorOpenid: openid,
    authorName: user.nickname || authorName,
    likeCount: 0,
    commentCount: 0,
    status: 'published',
    moderationStatus: 'passed',
    createdAt: db.serverDate(),
    updatedAt: db.serverDate()
  }

  const res = await db.collection('posts').add({
    data: postData
  })

  return {
    ok: true,
    postId: res._id,
    post: Object.assign(
      {
        _id: res._id
      },
      postData
    )
  }
}