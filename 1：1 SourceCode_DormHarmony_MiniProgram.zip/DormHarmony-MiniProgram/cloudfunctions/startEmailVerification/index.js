const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

const ALLOWED_DOMAINS = [
  '@student.xjtlu.edu.cn',
  '@xjtlu.edu.cn'
]

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase()
}

function isAllowedStudentEmail(email) {
  return ALLOWED_DOMAINS.some(domain => email.endsWith(domain))
}

function generateCode() {
  return String(Math.floor(100000 + Math.random() * 900000))
}

async function ensureUser(openid) {
  try {
    await db.collection('users').doc(openid).get()
  } catch (e) {
    await db.collection('users').add({
      data: {
        _id: openid,
        openid,
        nickname: '',
        email: '',
        emailVerified: false,
        verificationStatus: 'unverified',
        reputationScore: 100,
        role: 'student',
        createdAt: db.serverDate(),
        updatedAt: db.serverDate()
      }
    })
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const email = normalizeEmail(event.email)

  if (!email) {
    return {
      ok: false,
      code: 'EMPTY_EMAIL',
      message: 'Please enter your student email.'
    }
  }

  if (!isAllowedStudentEmail(email)) {
    return {
      ok: false,
      code: 'INVALID_STUDENT_EMAIL',
      message: 'Only XJTLU student email is accepted.'
    }
  }

  await ensureUser(openid)

  await db.collection('email_codes')
    .where({
      openid,
      email,
      used: false
    })
    .update({
      data: {
        used: true,
        invalidatedAt: db.serverDate()
      }
    })
    .catch(() => {})

  const verificationCode = generateCode()
  const now = Date.now()
  const expiresAt = now + 10 * 60 * 1000

  await db.collection('email_codes').add({
    data: {
      openid,
      email,
      code: verificationCode,
      used: false,
      expiresAt,
      createdAt: db.serverDate()
    }
  })

  await db.collection('users').doc(openid).update({
    data: {
      email,
      emailVerified: false,
      verificationStatus: 'pending',
      updatedAt: db.serverDate()
    }
  })

  return {
    ok: true,
    email,
    expiresAt,
    debugCode: verificationCode,
    message: 'Verification code generated. Development mode returns debugCode.'
  }
}