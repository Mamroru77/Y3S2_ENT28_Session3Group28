const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function isAllowedTargetType(type) {
  return [
    'post',
    'comment',
    'message',
    'conversation',
    'user',
    'match_demo'
  ].indexOf(type) > -1
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const targetType = cleanText(event.targetType)
  const targetId = cleanText(event.targetId)
  const reason = cleanText(event.reason) || 'inappropriate_content'
  const description = cleanText(event.description)

  if (!targetType || !isAllowedTargetType(targetType)) {
    return {
      ok: false,
      code: 'INVALID_TARGET_TYPE',
      message: 'Invalid report target type.'
    }
  }

  if (!targetId) {
    return {
      ok: false,
      code: 'EMPTY_TARGET_ID',
      message: 'Report target ID is required.'
    }
  }

  if (description.length > 500) {
    return {
      ok: false,
      code: 'DESCRIPTION_TOO_LONG',
      message: 'Report description is too long.'
    }
  }

  const reportData = {
    reporterOpenid: openid,
    targetType,
    targetId,
    reason,
    description,
    status: 'pending',
    handledBy: '',
    handledAt: null,
    createdAt: db.serverDate(),
    updatedAt: db.serverDate()
  }

  const res = await db.collection('reports').add({
    data: reportData
  })

  return {
    ok: true,
    reportId: res._id,
    report: Object.assign(
      {
        _id: res._id
      },
      reportData
    )
  }
}