const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function buildTargetKey(targetOpenid, targetId) {
  if (targetOpenid) return `openid:${targetOpenid}`
  return `mock:${targetId}`
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const conversationId = cleanText(event.conversationId)
  let targetOpenid = cleanText(event.targetOpenid)
  let targetId = cleanText(event.targetId)

  let conversation = null
  let blockedByAnyone = false
  let blockedByMeInConversation = false

  if (conversationId) {
    const conversationRes = await db.collection('conversations')
      .doc(conversationId)
      .get()
      .catch(() => null)

    if (conversationRes && conversationRes.data) {
      conversation = conversationRes.data

      if (!targetOpenid && conversation.targetOpenid) {
        targetOpenid = conversation.targetOpenid
      }

      if (!targetId && conversation.targetId) {
        targetId = conversation.targetId
      }

      const blockedBy = Array.isArray(conversation.blockedBy)
        ? conversation.blockedBy
        : []

      blockedByAnyone = blockedBy.length > 0
      blockedByMeInConversation = blockedBy.indexOf(openid) > -1
    }
  }

  if (!targetOpenid && !targetId) {
    return {
      ok: true,
      blocked: blockedByAnyone,
      blockedByMe: blockedByMeInConversation,
      blockedByAnyone,
      block: null
    }
  }

  const targetKey = buildTargetKey(targetOpenid, targetId)

  const blockRes = await db.collection('blocks')
    .where({
      blockerOpenid: openid,
      targetKey,
      status: 'active'
    })
    .limit(1)
    .get()

  const block = blockRes.data && blockRes.data[0]
    ? blockRes.data[0]
    : null

  return {
    ok: true,
    blocked: !!block || blockedByAnyone,
    blockedByMe: !!block || blockedByMeInConversation,
    blockedByAnyone,
    block
  }
}