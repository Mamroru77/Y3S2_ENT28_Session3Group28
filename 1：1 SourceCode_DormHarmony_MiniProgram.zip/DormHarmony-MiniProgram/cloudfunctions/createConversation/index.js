const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function cleanText(value, maxLength) {
  return String(value || '').trim().slice(0, maxLength || 80)
}

function getConversationId(openidA, openidB, type) {
  const sorted = [openidA, openidB].sort()
  return `${type}_${sorted[0]}_${sorted[1]}`
}

async function getUser(openid) {
  const res = await db.collection('users')
    .doc(openid)
    .get()
    .catch(() => null)

  return res && res.data ? res.data : null
}

async function checkActiveBlock(openidA, openidB) {
  const res = await db.collection('blocks')
    .where({
      status: 'active'
    })
    .get()
    .catch(() => ({ data: [] }))

  const found = (res.data || []).find(item => {
    const blocker = item.blockerOpenid
    const target = item.targetOpenid

    return (
      (blocker === openidA && target === openidB) ||
      (blocker === openidB && target === openidA)
    )
  })

  return !!found
}

async function createOrOpenRealConversation(openid, event) {
  const targetId = cleanText(event.targetId, 120)

  if (!targetId) {
    return {
      ok: false,
      code: 'EMPTY_TARGET',
      message: 'Target user is required.'
    }
  }

  if (targetId === openid) {
    return {
      ok: false,
      code: 'SELF_CONVERSATION',
      message: 'You cannot create a conversation with yourself.'
    }
  }

  const currentUser = await getUser(openid)
  const targetUser = await getUser(targetId)

  if (!currentUser || !currentUser.profileCompleted) {
    return {
      ok: false,
      code: 'CURRENT_USER_INVALID',
      message: 'Please complete your profile first.'
    }
  }

  if (!targetUser || !targetUser.profileCompleted || targetUser.status !== 'active') {
    return {
      ok: false,
      code: 'TARGET_USER_INVALID',
      message: 'Target user is unavailable.'
    }
  }

  const isBlocked = await checkActiveBlock(openid, targetId)

  if (isBlocked) {
    return {
      ok: false,
      code: 'BLOCKED_CONVERSATION',
      message: 'This conversation is blocked.'
    }
  }

  const conversationId = getConversationId(openid, targetId, 'real_user')
  const now = db.serverDate()

  const existing = await db.collection('conversations')
    .doc(conversationId)
    .get()
    .catch(() => null)

  if (existing && existing.data) {
    await db.collection('conversations')
      .doc(conversationId)
      .update({
        data: {
          updatedAt: now,
          status: existing.data.status || 'active'
        }
      })

    const latest = await db.collection('conversations')
      .doc(conversationId)
      .get()

    return {
      ok: true,
      conversation: latest.data
    }
  }

  const conversation = {
    _id: conversationId,

    conversationType: 'real_user',
    targetType: 'real_user',

    creatorOpenid: openid,
    targetId,

    participants: [openid, targetId],
    participantNames: {
      [openid]: currentUser.nickname || 'Dorm User',
      [targetId]: targetUser.nickname || 'Dorm User'
    },

    targetName: targetUser.nickname || 'Dorm User',
    targetAvatarText: targetUser.avatarText || String(targetUser.nickname || 'D').slice(0, 1).toUpperCase(),

    lastMessage: '',
    lastMessageAt: null,
    messageCount: 0,

    status: 'active',
    createdAt: now,
    updatedAt: now
  }

  await db.collection('conversations').add({
    data: conversation
  })

  const latest = await db.collection('conversations')
    .doc(conversationId)
    .get()

  return {
    ok: true,
    conversation: latest.data
  }
}

async function createOrOpenDemoConversation(openid, event) {
  const targetId = cleanText(event.targetId, 80)
  const targetName = cleanText(event.targetName || 'Dorm User', 40)

  if (!targetId) {
    return {
      ok: false,
      code: 'EMPTY_TARGET',
      message: 'Target is required.'
    }
  }

  const conversationId = getConversationId(openid, `demo_${targetId}`, 'match_demo')
  const now = db.serverDate()

  const existing = await db.collection('conversations')
    .doc(conversationId)
    .get()
    .catch(() => null)

  if (existing && existing.data) {
    await db.collection('conversations')
      .doc(conversationId)
      .update({
        data: {
          updatedAt: now
        }
      })

    const latest = await db.collection('conversations')
      .doc(conversationId)
      .get()

    return {
      ok: true,
      conversation: latest.data
    }
  }

  const conversation = {
    _id: conversationId,

    conversationType: 'match_demo',
    targetType: 'demo',

    creatorOpenid: openid,
    targetId,
    targetName,
    targetAvatarText: String(targetName || 'D').slice(0, 1).toUpperCase(),

    participants: [openid, `demo_${targetId}`],
    participantNames: {
      [openid]: 'Me',
      [`demo_${targetId}`]: targetName
    },

    lastMessage: '',
    lastMessageAt: null,
    messageCount: 0,

    status: 'active',
    createdAt: now,
    updatedAt: now
  }

  await db.collection('conversations').add({
    data: conversation
  })

  const latest = await db.collection('conversations')
    .doc(conversationId)
    .get()

  return {
    ok: true,
    conversation: latest.data
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const targetType = cleanText(event.targetType || '')

  if (targetType === 'real_user') {
    return createOrOpenRealConversation(openid, event)
  }

  return createOrOpenDemoConversation(openid, event)
}