const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function formatConversation(item, openid) {
  const participants = Array.isArray(item.participants)
    ? item.participants
    : []

  const participantNames = item.participantNames || {}
  const conversationType = item.conversationType || item.targetType || 'match_demo'
  const isRealUser = conversationType === 'real_user'

  let targetOpenid = item.targetId || ''

  if (isRealUser) {
    targetOpenid = participants.find(id => id !== openid) || item.targetId || ''
  }

  const targetName = isRealUser
    ? participantNames[targetOpenid] || item.targetName || 'Dorm User'
    : item.targetName || 'Dorm User'

  return {
    ...item,
    id: item._id,
    conversationId: item._id,
    conversationType,
    targetType: item.targetType || conversationType,
    targetId: targetOpenid || item.targetId || '',
    targetName,
    targetAvatarText: item.targetAvatarText || String(targetName || 'D').slice(0, 1).toUpperCase(),
    isRealUser,
    hiddenFor: Array.isArray(item.hiddenFor) ? item.hiddenFor : []
  }
}

exports.main = async () => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const res = await db.collection('conversations')
    .where({
      participants: _.all([openid])
    })
    .limit(100)
    .get()
    .catch(() => ({ data: [] }))

  const conversations = (res.data || [])
    .filter(item => {
      const hiddenFor = Array.isArray(item.hiddenFor) ? item.hiddenFor : []
      if (hiddenFor.indexOf(openid) > -1) return false

      if (item.status && item.status !== 'active') return false

      return true
    })
    .map(item => formatConversation(item, openid))
    .sort((a, b) => {
      const aTime = new Date(a.lastMessageAt || a.updatedAt || a.createdAt || 0).getTime()
      const bTime = new Date(b.lastMessageAt || b.updatedAt || b.createdAt || 0).getTime()

      return bTime - aTime
    })

  return {
    ok: true,
    conversations
  }
}