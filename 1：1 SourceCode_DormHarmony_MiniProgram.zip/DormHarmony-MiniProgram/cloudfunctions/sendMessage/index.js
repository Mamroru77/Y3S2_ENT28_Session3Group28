const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function cleanText(value) {
  return String(value || '').trim()
}

function isParticipant(conversation, openid) {
  const participants = conversation.participants || []
  return participants.indexOf(openid) > -1
}

async function checkContentSafety(content, scene, title, nickname) {
  const res = await cloud.callFunction({
    name: 'contentCheck',
    data: {
      content,
      scene,
      title,
      nickname
    }
  })

  return res.result || {}
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const conversationId = cleanText(event.conversationId)
  const content = cleanText(event.content)

  if (!conversationId) {
    return {
      ok: false,
      code: 'EMPTY_CONVERSATION_ID',
      message: 'Conversation ID is required.'
    }
  }

  if (!content) {
    return {
      ok: false,
      code: 'EMPTY_CONTENT',
      message: 'Message content is required.'
    }
  }

  if (content.length > 500) {
    return {
      ok: false,
      code: 'MESSAGE_TOO_LONG',
      message: 'Message is too long.'
    }
  }

  const conversationRes = await db.collection('conversations')
    .doc(conversationId)
    .get()
    .catch(() => null)

  if (!conversationRes || !conversationRes.data) {
    return {
      ok: false,
      code: 'CONVERSATION_NOT_FOUND',
      message: 'Conversation not found.'
    }
  }

  const conversation = conversationRes.data

  if (conversation.status !== 'active') {
    return {
      ok: false,
      code: 'CONVERSATION_INACTIVE',
      message: 'Conversation is inactive.'
    }
  }

  if (!isParticipant(conversation, openid)) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You are not a participant of this conversation.'
    }
  }

  const blockedBy = Array.isArray(conversation.blockedBy)
    ? conversation.blockedBy
    : []

  if (blockedBy.length > 0) {
    return {
      ok: false,
      code: 'BLOCKED_CONVERSATION',
      message: 'This conversation has been blocked. You cannot send new messages.'
    }
  }

  const safetyCheck = await checkContentSafety(
    content,
    'chat',
    'DormHarmony Chat Message',
    'Dorm User'
  )

  if (!safetyCheck.ok || !safetyCheck.safe) {
    return {
      ok: false,
      code: safetyCheck.code || 'MESSAGE_CONTENT_RISK',
      message: safetyCheck.message || 'Message may contain risky content.'
    }
  }

  const receiverOpenid = conversation.targetOpenid && conversation.targetOpenid !== openid
    ? conversation.targetOpenid
    : conversation.participants.find(item => item !== openid) || ''

  const messageData = {
    conversationId,
    senderOpenid: openid,
    receiverOpenid,
    content,
    messageType: 'text',
    status: 'sent',
    moderationStatus: 'passed',
    createdAt: db.serverDate()
  }

  const res = await db.collection('messages').add({
    data: messageData
  })

  await db.collection('conversations').doc(conversationId).update({
    data: {
      lastMessage: content,
      lastMessageAt: db.serverDate(),
      messageCount: _.inc(1),
      updatedAt: db.serverDate()
    }
  })

  return {
    ok: true,
    messageId: res._id,
    message: Object.assign(
      {
        _id: res._id
      },
      messageData
    )
  }
}