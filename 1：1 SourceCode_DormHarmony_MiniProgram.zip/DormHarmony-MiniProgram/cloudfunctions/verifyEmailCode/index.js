const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function normalizeEmail(email) {
  return String(email || '').trim().toLowerCase()
}

function normalizeCode(code) {
  return String(code || '').trim()
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const email = normalizeEmail(event.email)
  const code = normalizeCode(event.code)

  if (!email || !code) {
    return {
      ok: false,
      code: 'MISSING_FIELDS',
      message: 'Email and code are required.'
    }
  }

  const codeRes = await db.collection('email_codes')
    .where({
      openid,
      email,
      code,
      used: false
    })
    .orderBy('expiresAt', 'desc')
    .limit(1)
    .get()

  if (!codeRes.data || codeRes.data.length === 0) {
    return {
      ok: false,
      code: 'INVALID_CODE',
      message: 'Invalid verification code.'
    }
  }

  const record = codeRes.data[0]

  if (Date.now() > record.expiresAt) {
    return {
      ok: false,
      code: 'CODE_EXPIRED',
      message: 'Verification code has expired.'
    }
  }

  await db.collection('email_codes').doc(record._id).update({
    data: {
      used: true,
      usedAt: db.serverDate()
    }
  })

  await db.collection('users').doc(openid).update({
    data: {
      email,
      emailVerified: true,
      verificationStatus: 'verified',
      verifiedAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })

  return {
    ok: true,
    email,
    message: 'Student email verified successfully.'
  }
}