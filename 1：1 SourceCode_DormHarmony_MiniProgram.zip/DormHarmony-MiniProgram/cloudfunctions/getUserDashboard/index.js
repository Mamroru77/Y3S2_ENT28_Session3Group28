const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

async function getOrCreateUser(openid) {
  try {
    const res = await db.collection('users').doc(openid).get()
    return res.data
  } catch (e) {
    const user = {
      _id: openid,
      openid,
      nickname: '',
      avatarText: 'D',
      email: '',
      emailVerified: false,
      verificationStatus: 'skipped',
      reputationScore: 100,
      role: 'student',
      profileCompleted: false,
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }

    await db.collection('users').add({
      data: user
    })

    return user
  }
}

exports.main = async () => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const user = await getOrCreateUser(openid)

  const postCountRes = await db.collection('posts')
    .where({
      authorOpenid: openid,
      status: 'published'
    })
    .count()

  const conversationCountRes = await db.collection('conversations')
    .where({
      participants: _.in([openid]),
      status: 'active'
    })
    .count()

  const reportCountRes = await db.collection('reports')
    .where({
      reporterOpenid: openid
    })
    .count()

  const blockCountRes = await db.collection('blocks')
    .where({
      blockerOpenid: openid,
      status: 'active'
    })
    .count()

  return {
    ok: true,
    user,
    stats: {
      postCount: postCountRes.total || 0,
      conversationCount: conversationCountRes.total || 0,
      reportCount: reportCountRes.total || 0,
      blockCount: blockCountRes.total || 0
    }
  }
}