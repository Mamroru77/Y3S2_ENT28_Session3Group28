const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function cleanText(value) {
  return String(value || '').trim()
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const conversationId = cleanText(event.conversationId)

  if (!conversationId) {
    return {
      ok: false,
      code: 'EMPTY_CONVERSATION_ID',
      message: 'Conversation ID is required.'
    }
  }

  const conversationRes = await db.collection('conversations')
    .doc(conversationId)
    .get()
    .catch(() => null)

  if (!conversationRes || !conversationRes.data) {
    return {
      ok: false,
      code: 'CONVERSATION_NOT_FOUND',
      message: 'Conversation not found.'
    }
  }

  const conversation = conversationRes.data
  const participants = Array.isArray(conversation.participants)
    ? conversation.participants
    : []

  if (participants.indexOf(openid) === -1) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You are not allowed to manage this conversation.'
    }
  }

  await db.collection('conversations')
    .doc(conversationId)
    .update({
      data: {
        hiddenFor: _.addToSet(openid),
        updatedAt: db.serverDate()
      }
    })

  return {
    ok: true,
    conversationId
  }
}