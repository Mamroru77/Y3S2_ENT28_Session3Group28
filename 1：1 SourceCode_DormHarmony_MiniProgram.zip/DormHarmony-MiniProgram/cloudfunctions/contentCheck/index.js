const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

function cleanText(value) {
  return String(value || '').trim()
}

function getSceneNumber(scene) {
  const value = String(scene || '').trim()

  if (value === 'profile') return 1
  if (value === 'comment') return 2
  if (value === 'forum') return 3
  if (value === 'chat') return 4

  return 3
}

function localRiskCheck(text) {
  const bannedWords = [
    '微信号',
    '手机号',
    '加我',
    '裸聊',
    '赌博',
    '博彩',
    '诈骗',
    '转账',
    '约炮',
    '色情',
    '代写',
    '贷款',
    '刷单'
  ]

  const content = cleanText(text).toLowerCase()

  const hitWord = bannedWords.find(word => {
    return content.indexOf(String(word).toLowerCase()) > -1
  })

  if (hitWord) {
    return {
      safe: false,
      reason: 'LOCAL_RISK_WORD',
      keyword: hitWord
    }
  }

  return {
    safe: true,
    reason: 'LOCAL_PASS',
    keyword: ''
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const content = cleanText(event.content)
  const title = cleanText(event.title)
  const nickname = cleanText(event.nickname)
  const scene = getSceneNumber(event.scene)

  if (!content) {
    return {
      ok: false,
      safe: false,
      code: 'EMPTY_CONTENT',
      message: 'Content is required.'
    }
  }

  if (content.length > 2500) {
    return {
      ok: false,
      safe: false,
      code: 'CONTENT_TOO_LONG',
      message: 'Content is too long.'
    }
  }

  const localResult = localRiskCheck(content)

  if (!localResult.safe) {
    return {
      ok: true,
      safe: false,
      code: 'LOCAL_CONTENT_RISK',
      source: 'local',
      suggest: 'risky',
      label: 'local',
      keyword: localResult.keyword,
      message: 'Content may contain risky words. Please revise it.'
    }
  }

  if (!cloud.openapi || !cloud.openapi.security || !cloud.openapi.security.msgSecCheck) {
    return {
      ok: true,
      safe: true,
      code: 'LOCAL_PASS_OPENAPI_UNAVAILABLE',
      source: 'local_fallback',
      suggest: 'pass',
      label: 'local',
      message: 'Content passed local safety check. WeChat security API is unavailable in this environment.'
    }
  }

  try {
    const checkRes = await cloud.openapi.security.msgSecCheck({
      content,
      version: 2,
      scene,
      openid,
      title,
      nickname
    })

    const result = checkRes.result || {}
    const suggest = result.suggest || 'pass'
    const label = result.label || 100

    if (suggest === 'risky' || suggest === 'review') {
      return {
        ok: true,
        safe: false,
        code: 'WECHAT_CONTENT_RISK',
        source: 'wechat',
        suggest,
        label,
        traceId: checkRes.traceId || checkRes.trace_id || '',
        detail: checkRes.detail || [],
        message: 'Content may be risky. Please revise it before publishing.'
      }
    }

    return {
      ok: true,
      safe: true,
      code: 'WECHAT_PASS',
      source: 'wechat',
      suggest,
      label,
      traceId: checkRes.traceId || checkRes.trace_id || '',
      message: 'Content passed safety check.'
    }
  } catch (err) {
    console.error('msgSecCheck failed, fallback to local pass:', err)

    return {
      ok: true,
      safe: true,
      code: 'LOCAL_PASS_WECHAT_CHECK_FAILED',
      source: 'local_fallback',
      suggest: 'pass',
      label: 'local',
      message: 'Content passed local safety check. WeChat security check failed temporarily, fallback applied.',
      errorMessage: err && err.message ? err.message : String(err)
    }
  }
}