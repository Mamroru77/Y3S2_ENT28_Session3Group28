const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const page = Math.max(Number(event.page || 0), 0)
  const pageSize = Math.min(Math.max(Number(event.pageSize || 20), 1), 50)
  const skip = page * pageSize

  const where = {
    authorOpenid: openid,
    status: 'published'
  }

  const countRes = await db.collection('posts')
    .where(where)
    .count()

  const total = countRes.total || 0

  const postRes = await db.collection('posts')
    .where(where)
    .orderBy('updatedAt', 'desc')
    .skip(skip)
    .limit(pageSize)
    .get()

  return {
    ok: true,
    page,
    pageSize,
    total,
    hasMore: skip + (postRes.data || []).length < total,
    posts: postRes.data || []
  }
}