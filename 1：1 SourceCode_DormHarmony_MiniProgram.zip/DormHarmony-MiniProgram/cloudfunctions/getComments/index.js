const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value && value.$date) {
    date = new Date(value.$date)
  }

  if (!date || Number.isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

function normalizeComment(item, openid) {
  return {
    ...item,
    id: item._id,
    isMine: item.authorOpenid === openid,
    timeText: formatTime(item.createdAt),
    replies: []
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const postId = cleanText(event.postId)

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  if (!postId) {
    return {
      ok: false,
      code: 'EMPTY_POST_ID',
      message: 'Post ID is required.'
    }
  }

  const res = await db.collection('comments')
    .where({
      postId,
      status: 'published'
    })
    .limit(200)
    .get()
    .catch(() => ({ data: [] }))

  const all = (res.data || [])
    .map(item => normalizeComment(item, openid))
    .sort((a, b) => {
      const aTime = new Date(a.createdAt || 0).getTime()
      const bTime = new Date(b.createdAt || 0).getTime()
      return aTime - bTime
    })

  const rootComments = []
  const rootMap = {}

  all.forEach(item => {
    if (!item.parentCommentId) {
      rootMap[item._id] = item
      rootComments.push(item)
    }
  })

  all.forEach(item => {
    if (item.parentCommentId) {
      const rootId = item.rootCommentId || item.parentCommentId
      const root = rootMap[rootId]

      if (root) {
        root.replies.push(item)
      }
    }
  })

  rootComments.forEach(item => {
    item.replies = item.replies.sort((a, b) => {
      const aTime = new Date(a.createdAt || 0).getTime()
      const bTime = new Date(b.createdAt || 0).getTime()
      return aTime - bTime
    })
  })

  return {
    ok: true,
    comments: rootComments,
    total: rootComments.length
  }
}