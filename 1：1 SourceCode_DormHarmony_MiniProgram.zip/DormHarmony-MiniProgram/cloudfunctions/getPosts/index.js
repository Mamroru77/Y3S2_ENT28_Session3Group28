const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function cleanText(value) {
  return String(value || '').trim()
}

function escapeRegExp(value) {
  return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

const CATEGORY_KEYWORDS = [
  {
    key: 'boundary',
    keywords: ['boundary', 'boundaries', '边界', '规则', '底线']
  },
  {
    key: 'schedule',
    keywords: ['schedule', 'sleep', 'wake', '作息', '睡觉', '起床', '熄灯']
  },
  {
    key: 'cleanliness',
    keywords: ['clean', 'cleanliness', '卫生', '清洁', '打扫', '整洁']
  },
  {
    key: 'visitor',
    keywords: ['visitor', 'guest', '访客', '朋友', '留宿']
  },
  {
    key: 'mbti',
    keywords: ['mbti', '性格', '人格']
  },
  {
    key: 'rent',
    keywords: ['rent', 'rental', '合租', '租房', '房租']
  }
]

function getCategoryKeysByKeyword(keyword) {
  const value = cleanText(keyword).toLowerCase()

  if (!value) return []

  return CATEGORY_KEYWORDS
    .filter(item => {
      return item.keywords.some(word => value.indexOf(String(word).toLowerCase()) > -1)
    })
    .map(item => item.key)
}

function buildWhereCondition(event) {
  const category = cleanText(event.category || 'all')
  const keyword = cleanText(event.keyword || '')

  const conditions = [
    {
      status: 'published'
    }
  ]

  if (category && category !== 'all') {
    conditions.push({
      category
    })
  }

  if (keyword) {
    const regex = db.RegExp({
      regexp: escapeRegExp(keyword),
      options: 'i'
    })

    const categoryKeys = getCategoryKeysByKeyword(keyword)

    const keywordConditions = [
      {
        title: regex
      },
      {
        content: regex
      },
      {
        authorName: regex
      },
      {
        category: regex
      }
    ]

    if (categoryKeys.length > 0) {
      keywordConditions.push({
        category: _.in(categoryKeys)
      })
    }

    conditions.push(_.or(keywordConditions))
  }

  if (conditions.length === 1) {
    return conditions[0]
  }

  return _.and(conditions)
}

function applySort(query, sortMode) {
  if (sortMode === 'hot') {
    return query
      .orderBy('likeCount', 'desc')
      .orderBy('commentCount', 'desc')
      .orderBy('createdAt', 'desc')
  }

  if (sortMode === 'discussed') {
    return query
      .orderBy('commentCount', 'desc')
      .orderBy('likeCount', 'desc')
      .orderBy('createdAt', 'desc')
  }

  return query.orderBy('createdAt', 'desc')
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const sortMode = cleanText(event.sortMode || 'latest')
  const page = Math.max(Number(event.page || 0), 0)
  const pageSize = Math.min(Math.max(Number(event.pageSize || event.limit || 20), 1), 50)
  const skip = page * pageSize

  const whereCondition = buildWhereCondition(event)

  const countRes = await db.collection('posts')
    .where(whereCondition)
    .count()

  const total = countRes.total || 0

  let postQuery = db.collection('posts')
    .where(whereCondition)

  postQuery = applySort(postQuery, sortMode)

  const postRes = await postQuery
    .skip(skip)
    .limit(pageSize)
    .get()

  const posts = postRes.data || []
  const postIds = posts.map(item => item._id)

  let likedMap = {}

  if (postIds.length > 0) {
    const likeRes = await db.collection('likes')
      .where({
        openid,
        targetType: 'post',
        targetId: _.in(postIds)
      })
      .get()

    ;(likeRes.data || []).forEach(item => {
      likedMap[item.targetId] = true
    })
  }

  return {
    ok: true,
    page,
    pageSize,
    total,
    hasMore: skip + posts.length < total,
    posts: posts.map(item => {
      return Object.assign({}, item, {
        liked: !!likedMap[item._id]
      })
    })
  }
}