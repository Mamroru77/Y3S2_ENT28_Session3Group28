const cloud = require('wx-server-sdk')
const crypto = require('crypto')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

const campusOptions = [
  {
    code: 'SIP',
    name: 'SIP Campus'
  },
  {
    code: 'TC',
    name: 'TC Campus'
  }
]

const schoolOptionsByCampus = {
  SIP: [
    { code: 'IBSS', name: 'International Business School Suzhou' },
    { code: 'SAT', name: 'School of Advanced Technology' },
    { code: 'DESIGN', name: 'Design School' },
    { code: 'HSS', name: 'School of Humanities and Social Sciences' },
    { code: 'MATH_PHYSICS', name: 'School of Mathematics and Physics' },
    { code: 'SCIENCE', name: 'School of Science' },
    { code: 'AFCT_SIP', name: 'Academy of Film and Creative Technology' },
    { code: 'WLAP', name: 'XJTLU Wisdom Lake Academy of Pharmacy' },
    { code: 'OTHER_SIP', name: 'Other / Not listed' }
  ],

  TC: [
    { code: 'AIAC', name: 'School of AI and Advanced Computing' },
    { code: 'CHIPS', name: 'School of CHIPS' },
    { code: 'SIFB', name: 'School of Intelligent Finance and Business' },
    { code: 'SIME', name: 'School of Intelligent Manufacturing Ecosystem' },
    { code: 'IOT', name: 'School of Internet of Things' },
    { code: 'ROBOTICS', name: 'School of Robotics' },
    { code: 'AFCT_TC', name: 'Academy of Film and Creative Technology' },
    { code: 'OTHER_TC', name: 'Other / Not listed' }
  ]
}

const programmeOptionsBySchool = {
  IBSS: [
    { code: 'ACCOUNTING', name: 'Accounting BA (Hons)' },
    { code: 'BUSINESS_ADMINISTRATION', name: 'Business Administration BA (Hons)' },
    { code: 'DIGITAL_INTELLIGENT_MARKETING', name: 'Digital and Intelligent Marketing BA (Hons)' },
    { code: 'ECONOMICS', name: 'Economics BSc (Hons)' },
    { code: 'ECONOMICS_FINANCE', name: 'Economics and Finance BSc (Hons)' },
    { code: 'HRM_PEOPLE_ANALYTICS', name: 'Human Resource Management and People Analytics BA (Hons)' },
    { code: 'IMIS', name: 'Information Management and Information Systems BSc (Hons)' },
    { code: 'INTERNATIONAL_BUSINESS_LANGUAGE', name: 'International Business with a Language BA (Hons)' },
    { code: 'OTHER_IBSS', name: 'Other / Not listed' }
  ],

  SAT: [
    { code: 'ARTIFICIAL_INTELLIGENCE_SIP', name: 'Artificial Intelligence BEng (Hons)' },
    { code: 'COMPUTER_SCIENCE_TECHNOLOGY', name: 'Computer Science and Technology BEng (Hons)' },
    { code: 'DIGITAL_MEDIA_TECHNOLOGY', name: 'Digital Media Technology BEng (Hons)' },
    { code: 'ELECTRICAL_ENGINEERING', name: 'Electrical Engineering BEng (Hons)' },
    { code: 'ELECTRONIC_SCIENCE_TECHNOLOGY', name: 'Electronic Science and Technology BEng (Hons)' },
    { code: 'INFORMATION_COMPUTING_SCIENCE', name: 'Information and Computing Science BSc (Hons)' },
    { code: 'MECHATRONICS_ROBOTIC_SYSTEMS', name: 'Mechatronics and Robotic Systems BEng (Hons)' },
    { code: 'TELECOMMUNICATIONS_ENGINEERING', name: 'Telecommunications Engineering BEng (Hons)' },
    { code: 'OTHER_SAT', name: 'Other / Not listed' }
  ],

  DESIGN: [
    { code: 'ARCHITECTURE', name: 'Architecture BEng (Hons)' },
    { code: 'CIVIL_ENGINEERING', name: 'Civil Engineering BEng (Hons)' },
    { code: 'INDUSTRIAL_DESIGN', name: 'Industrial Design BEng (Hons)' },
    { code: 'URBAN_PLANNING_DESIGN', name: 'Urban Planning and Design BA (Hons)' },
    { code: 'OTHER_DESIGN', name: 'Other / Not listed' }
  ],

  HSS: [
    { code: 'APPLIED_LINGUISTICS', name: 'Applied Linguistics BA (Hons)' },
    { code: 'CHINA_STUDIES', name: 'China Studies BA (Hons)' },
    { code: 'ENGLISH_BUSINESS', name: 'English and Business BA (Hons)' },
    { code: 'ENGLISH_COMMUNICATION_STUDIES', name: 'English and Communication Studies BA (Hons)' },
    { code: 'ENGLISH_GLOBAL_CONTEXT', name: 'English Studies in Global Context BA (Hons)' },
    { code: 'INTERNATIONAL_RELATIONS', name: 'International Relations BA (Hons)' },
    { code: 'MEDIA_COMMUNICATION_STUDIES', name: 'Media and Communication Studies BA (Hons)' },
    { code: 'TRANSLATION_INTERPRETING', name: 'Translation and Interpreting BA (Hons)' },
    { code: 'OTHER_HSS', name: 'Other / Not listed' }
  ],

  MATH_PHYSICS: [
    { code: 'ACTUARIAL_SCIENCE', name: 'Actuarial Science BSc (Hons)' },
    { code: 'APPLIED_MATHEMATICS', name: 'Applied Mathematics BSc (Hons)' },
    { code: 'FINANCIAL_MATHEMATICS', name: 'Financial Mathematics BSc (Hons)' },
    { code: 'OTHER_MATH_PHYSICS', name: 'Other / Not listed' }
  ],

  SCIENCE: [
    { code: 'APPLIED_CHEMISTRY', name: 'Applied Chemistry BSc (Hons)' },
    { code: 'BIOINFORMATICS', name: 'Bioinformatics BSc (Hons)' },
    { code: 'BIOLOGICAL_SCIENCES', name: 'Biological Sciences BSc (Hons)' },
    { code: 'BIOMEDICAL_SCIENCES', name: 'Biomedical Sciences BSc (Hons)' },
    { code: 'ENVIRONMENTAL_SCIENCE', name: 'Environmental Science BSc (Hons)' },
    { code: 'MATERIALS_SCIENCE_ENGINEERING', name: 'Materials Science and Engineering BEng (Hons)' },
    { code: 'OTHER_SCIENCE', name: 'Other / Not listed' }
  ],

  AFCT_SIP: [
    { code: 'DIGITAL_MEDIA_ARTS', name: 'Digital Media Arts BA (Hons)' },
    { code: 'FILMMAKING', name: 'Filmmaking BA (Hons)' },
    { code: 'TV_PRODUCTION', name: 'TV Production BA (Hons)' },
    { code: 'ARTS_TECH_ENTREPRENEURIALISM_SIP', name: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)' },
    { code: 'OTHER_AFCT_SIP', name: 'Other / Not listed' }
  ],

  WLAP: [
    { code: 'PHARMACEUTICAL_SCIENCE', name: 'Pharmaceutical Science / Pharmacy-related programme' },
    { code: 'OTHER_WLAP', name: 'Other / Not listed' }
  ],

  AIAC: [
    { code: 'ARTIFICIAL_INTELLIGENCE_TC', name: 'Artificial Intelligence BEng (Hons)' },
    { code: 'DATA_SCIENCE_BIG_DATA_CE', name: 'Data Science and Big Data Technology with Contemporary Entrepreneurialism BEng (Hons)' },
    { code: 'OTHER_AIAC', name: 'Other / Not listed' }
  ],

  CHIPS: [
    { code: 'MICROELECTRONIC_SCIENCE_ENGINEERING_CE', name: 'Microelectronic Science and Engineering with Contemporary Entrepreneurialism BEng (Hons)' },
    { code: 'OTHER_CHIPS', name: 'Other / Not listed' }
  ],

  SIFB: [
    { code: 'INTELLIGENT_SUPPLY_CHAIN_CE', name: 'Intelligent Supply Chain with Contemporary Entrepreneurialism BSc (Hons)' },
    { code: 'OTHER_SIFB', name: 'Other / Not listed' }
  ],

  SIME: [
    { code: 'INTELLIGENT_MANUFACTURING_ENGINEERING_CE', name: 'Intelligent Manufacturing Engineering with Contemporary Entrepreneurialism BEng (Hons)' },
    { code: 'OTHER_SIME', name: 'Other / Not listed' }
  ],

  IOT: [
    { code: 'INTERNET_OF_THINGS_ENGINEERING_CE', name: 'Internet of Things Engineering with Contemporary Entrepreneurialism BEng (Hons)' },
    { code: 'OTHER_IOT', name: 'Other / Not listed' }
  ],

  ROBOTICS: [
    { code: 'INTELLIGENT_ROBOTICS_ENGINEERING_CE', name: 'Intelligent Robotics Engineering with Contemporary Entrepreneurialism BEng (Hons)' },
    { code: 'OTHER_ROBOTICS', name: 'Other / Not listed' }
  ],

  AFCT_TC: [
    { code: 'ARTS_TECH_ENTREPRENEURIALISM_TC', name: 'Arts, Technology and Entertainment with Contemporary Entrepreneurialism BA (Hons)' },
    { code: 'OTHER_AFCT_TC', name: 'Other / Not listed' }
  ],

  OTHER_SIP: [
    { code: 'OTHER_PROGRAMME_SIP', name: 'Other / Not listed' }
  ],

  OTHER_TC: [
    { code: 'OTHER_PROGRAMME_TC', name: 'Other / Not listed' }
  ]
}

function cleanText(value) {
  return String(value || '').trim()
}

function limitText(value, maxLength) {
  return cleanText(value).slice(0, maxLength)
}

function createPublicProfileId(openid) {
  const hash = crypto
    .createHash('sha256')
    .update(String(openid))
    .digest('hex')
    .slice(0, 8)
    .toUpperCase()

  return `DH-${hash}`
}

function findByCode(list, code) {
  return (list || []).find(item => item.code === code) || null
}

function validateXjtluSelection(campusCode, schoolCode, programmeCode) {
  const campus = findByCode(campusOptions, campusCode)

  if (!campus) {
    return {
      ok: false,
      code: 'INVALID_CAMPUS',
      message: 'Invalid campus.'
    }
  }

  const schools = schoolOptionsByCampus[campusCode] || []
  const school = findByCode(schools, schoolCode)

  if (!school) {
    return {
      ok: false,
      code: 'INVALID_SCHOOL_FOR_CAMPUS',
      message: 'Selected school does not belong to this campus.'
    }
  }

  const programmes = programmeOptionsBySchool[schoolCode] || []
  const programme = findByCode(programmes, programmeCode)

  if (!programme) {
    return {
      ok: false,
      code: 'INVALID_PROGRAMME_FOR_SCHOOL',
      message: 'Selected programme does not belong to this school.'
    }
  }

  return {
    ok: true,
    campus,
    school,
    programme
  }
}

function normalizeLegacyCampus(event) {
  const rawCampus = cleanText(event.campus)
  const lower = rawCampus.toLowerCase()

  if (event.campusCode) return cleanText(event.campusCode)

  if (lower.indexOf('tc') > -1 || lower.indexOf('taicang') > -1) {
    return 'TC'
  }

  return 'SIP'
}

function normalizeLegacySchool(event, campusCode) {
  if (event.schoolCode) return cleanText(event.schoolCode)

  const rawSchool = cleanText(event.school).toLowerCase()

  if (campusCode === 'TC') {
    if (rawSchool.indexOf('finance') > -1 || rawSchool.indexOf('business') > -1 || rawSchool.indexOf('sifb') > -1) return 'SIFB'
    if (rawSchool.indexOf('manufacturing') > -1 || rawSchool.indexOf('sime') > -1) return 'SIME'
    if (rawSchool.indexOf('robotics') > -1) return 'ROBOTICS'
    if (rawSchool.indexOf('internet of things') > -1 || rawSchool.indexOf('iot') > -1) return 'IOT'
    if (rawSchool.indexOf('chips') > -1) return 'CHIPS'
    if (rawSchool.indexOf('ai') > -1 || rawSchool.indexOf('advanced computing') > -1) return 'AIAC'
    if (rawSchool.indexOf('film') > -1 || rawSchool.indexOf('creative') > -1) return 'AFCT_TC'

    return 'SIFB'
  }

  if (rawSchool.indexOf('business') > -1 || rawSchool.indexOf('ibss') > -1) return 'IBSS'
  if (rawSchool.indexOf('advanced technology') > -1) return 'SAT'
  if (rawSchool.indexOf('design') > -1) return 'DESIGN'
  if (rawSchool.indexOf('humanities') > -1 || rawSchool.indexOf('social sciences') > -1) return 'HSS'
  if (rawSchool.indexOf('mathematics') > -1 || rawSchool.indexOf('physics') > -1) return 'MATH_PHYSICS'
  if (rawSchool.indexOf('science') > -1) return 'SCIENCE'
  if (rawSchool.indexOf('film') > -1 || rawSchool.indexOf('creative') > -1) return 'AFCT_SIP'
  if (rawSchool.indexOf('pharmacy') > -1) return 'WLAP'

  return 'IBSS'
}

function normalizeLegacyProgramme(event, schoolCode) {
  if (event.programmeCode) return cleanText(event.programmeCode)

  const rawProgramme = cleanText(event.programme || event.major).toLowerCase()
  const programmes = programmeOptionsBySchool[schoolCode] || []

  if (schoolCode === 'SIFB') {
    return 'INTELLIGENT_SUPPLY_CHAIN_CE'
  }

  if (schoolCode === 'IBSS') {
    if (rawProgramme.indexOf('accounting') > -1) return 'ACCOUNTING'
    if (rawProgramme.indexOf('economics and finance') > -1) return 'ECONOMICS_FINANCE'
    if (rawProgramme.indexOf('economics') > -1) return 'ECONOMICS'
    if (rawProgramme.indexOf('marketing') > -1) return 'DIGITAL_INTELLIGENT_MARKETING'
    if (rawProgramme.indexOf('human resource') > -1 || rawProgramme.indexOf('people analytics') > -1) return 'HRM_PEOPLE_ANALYTICS'
    if (rawProgramme.indexOf('information management') > -1) return 'IMIS'
    if (rawProgramme.indexOf('international business') > -1) return 'INTERNATIONAL_BUSINESS_LANGUAGE'
    return 'BUSINESS_ADMINISTRATION'
  }

  if (programmes.length) {
    return programmes[0].code
  }

  return ''
}

function normalizeProfile(event) {
  const livingType = cleanText(event.livingType || 'school_dorm')
  const matchGenderPreference = livingType === 'school_dorm'
    ? 'same'
    : cleanText(event.matchGenderPreference || 'same')

  const campusCode = normalizeLegacyCampus(event)
  const schoolCode = normalizeLegacySchool(event, campusCode)
  const programmeCode = normalizeLegacyProgramme(event, schoolCode)

  const validation = validateXjtluSelection(campusCode, schoolCode, programmeCode)

  return {
    nickname: limitText(event.nickname, 24),

    gender: cleanText(event.gender || ''),
    livingType,
    matchGenderPreference,

    year: cleanText(event.year || 'Year 1'),

    campusCode,
    schoolCode,
    programmeCode,

    campus: validation.ok ? validation.campus.name : cleanText(event.campus),
    school: validation.ok ? validation.school.name : cleanText(event.school),
    programme: validation.ok ? validation.programme.name : cleanText(event.programme || event.major),
    major: validation.ok ? validation.programme.name : limitText(event.major || event.programme || '', 120),

    mbti: cleanText(event.mbti || ''),
    bio: limitText(event.bio || '', 160),

    validation
  }
}

function isAllowedGender(gender) {
  return [
    'male',
    'female',
    'prefer_not_to_say'
  ].indexOf(gender) > -1
}

function isAllowedLivingType(livingType) {
  return [
    'school_dorm',
    'off_campus'
  ].indexOf(livingType) > -1
}

function isAllowedMatchGenderPreference(preference) {
  return [
    'same',
    'male',
    'female',
    'any'
  ].indexOf(preference) > -1
}

function isAllowedYear(year) {
  return [
    'Year 1',
    'Year 2',
    'Year 3',
    'Year 4',
    'Master',
    'PhD'
  ].indexOf(year) > -1
}

function isAllowedMbti(mbti) {
  if (!mbti) return true

  return [
    'INTJ', 'INTP', 'ENTJ', 'ENTP',
    'INFJ', 'INFP', 'ENFJ', 'ENFP',
    'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
    'ISTP', 'ISFP', 'ESTP', 'ESFP',
    'Not sure'
  ].indexOf(mbti) > -1
}

function localRiskCheck(text) {
  const bannedWords = [
    '微信号',
    '手机号',
    '加我',
    '裸聊',
    '赌博',
    '博彩',
    '诈骗',
    '转账',
    '约炮',
    '色情',
    '代写',
    '贷款',
    '刷单'
  ]

  const content = cleanText(text).toLowerCase()

  const hitWord = bannedWords.find(word => {
    return content.indexOf(String(word).toLowerCase()) > -1
  })

  return {
    safe: !hitWord,
    keyword: hitWord || ''
  }
}

async function getOrCreateUser(openid) {
  try {
    const res = await db.collection('users').doc(openid).get()
    return res.data
  } catch (e) {
    const user = {
      _id: openid,
      openid,

      publicProfileId: createPublicProfileId(openid),

      nickname: '',
      avatarText: 'D',

      gender: '',
      livingType: 'school_dorm',
      matchGenderPreference: 'same',

      campusCode: 'SIP',
      campus: 'SIP Campus',
      schoolCode: 'IBSS',
      school: 'International Business School Suzhou',
      programmeCode: 'BUSINESS_ADMINISTRATION',
      programme: 'Business Administration BA (Hons)',
      major: 'Business Administration BA (Hons)',

      email: '',
      emailVerified: false,
      verificationStatus: 'skipped',
      reputationScore: 100,
      role: 'student',
      status: 'active',
      profileCompleted: false,
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }

    await db.collection('users').add({
      data: user
    })

    return user
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const profile = normalizeProfile(event)

  if (!profile.nickname) {
    return {
      ok: false,
      code: 'EMPTY_NICKNAME',
      message: 'Nickname is required.'
    }
  }

  if (!isAllowedGender(profile.gender)) {
    return {
      ok: false,
      code: 'INVALID_GENDER',
      message: 'Invalid gender.'
    }
  }

  if (!isAllowedLivingType(profile.livingType)) {
    return {
      ok: false,
      code: 'INVALID_LIVING_TYPE',
      message: 'Invalid living scenario.'
    }
  }

  if (!isAllowedMatchGenderPreference(profile.matchGenderPreference)) {
    return {
      ok: false,
      code: 'INVALID_MATCH_GENDER_PREFERENCE',
      message: 'Invalid matching gender preference.'
    }
  }

  if (profile.livingType === 'school_dorm') {
    profile.matchGenderPreference = 'same'
  }

  if (!isAllowedYear(profile.year)) {
    return {
      ok: false,
      code: 'INVALID_YEAR',
      message: 'Invalid year.'
    }
  }

  if (!profile.validation.ok) {
    return {
      ok: false,
      code: profile.validation.code,
      message: profile.validation.message
    }
  }

  if (!isAllowedMbti(profile.mbti)) {
    return {
      ok: false,
      code: 'INVALID_MBTI',
      message: 'Invalid MBTI.'
    }
  }

  const nicknameRisk = localRiskCheck(profile.nickname)
  const bioRisk = localRiskCheck(profile.bio)

  if (!nicknameRisk.safe || !bioRisk.safe) {
    return {
      ok: false,
      code: 'PROFILE_CONTENT_RISK',
      message: 'Profile contains risky words. Please revise it.'
    }
  }

  const existingUser = await getOrCreateUser(openid)

  const avatarText = profile.nickname
    ? profile.nickname.slice(0, 1).toUpperCase()
    : 'D'

  const publicProfileId = existingUser.publicProfileId || createPublicProfileId(openid)
  const profileId = existingUser.profileId || ''

  const updateData = {
    publicProfileId,
    profileId,

    nickname: profile.nickname,
    avatarText,

    gender: profile.gender,
    livingType: profile.livingType,
    matchGenderPreference: profile.matchGenderPreference,

    year: profile.year,

    campusCode: profile.campusCode,
    campus: profile.campus,

    schoolCode: profile.schoolCode,
    school: profile.school,

    programmeCode: profile.programmeCode,
    programme: profile.programme,

    major: profile.major,

    mbti: profile.mbti,
    bio: profile.bio,

    status: 'active',
    profileCompleted: true,
    updatedAt: db.serverDate()
  }

  await db.collection('users').doc(openid).update({
    data: updateData
  })

  const userRes = await db.collection('users').doc(openid).get()

  return {
    ok: true,
    user: userRes.data
  }
}