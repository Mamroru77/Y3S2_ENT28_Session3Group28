const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function buildTargetKey(targetOpenid, targetId) {
  if (targetOpenid) return `openid:${targetOpenid}`
  return `mock:${targetId}`
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const conversationId = cleanText(event.conversationId)
  let targetOpenid = cleanText(event.targetOpenid)
  let targetId = cleanText(event.targetId)
  let targetName = cleanText(event.targetName) || 'Dorm User'
  const reason = cleanText(event.reason) || 'blocked_by_user'

  let conversation = null

  if (conversationId) {
    const conversationRes = await db.collection('conversations')
      .doc(conversationId)
      .get()
      .catch(() => null)

    if (conversationRes && conversationRes.data) {
      conversation = conversationRes.data

      if (!targetOpenid && conversation.targetOpenid) {
        targetOpenid = conversation.targetOpenid
      }

      if (!targetId && conversation.targetId) {
        targetId = conversation.targetId
      }

      if (conversation.targetName) {
        targetName = conversation.targetName
      }
    }
  }

  if (!targetOpenid && !targetId) {
    return {
      ok: false,
      code: 'MISSING_TARGET',
      message: 'Target openid or target id is required.'
    }
  }

  if (targetOpenid && targetOpenid === openid) {
    return {
      ok: false,
      code: 'SELF_BLOCK_NOT_ALLOWED',
      message: 'You cannot block yourself.'
    }
  }

  const targetKey = buildTargetKey(targetOpenid, targetId)

  const existingRes = await db.collection('blocks')
    .where({
      blockerOpenid: openid,
      targetKey,
      status: 'active'
    })
    .limit(1)
    .get()

  if (existingRes.data && existingRes.data.length > 0) {
    return {
      ok: true,
      existed: true,
      block: existingRes.data[0]
    }
  }

  const blockData = {
    blockerOpenid: openid,
    targetKey,
    targetOpenid: targetOpenid || '',
    targetId: targetId || '',
    targetName,
    conversationId: conversationId || '',
    reason,
    status: 'active',
    createdAt: db.serverDate(),
    updatedAt: db.serverDate()
  }

  const res = await db.collection('blocks').add({
    data: blockData
  })

  if (conversationId && conversation) {
    const oldBlockedBy = Array.isArray(conversation.blockedBy)
      ? conversation.blockedBy
      : []

    const nextBlockedBy = oldBlockedBy.indexOf(openid) > -1
      ? oldBlockedBy
      : oldBlockedBy.concat(openid)

    await db.collection('conversations').doc(conversationId).update({
      data: {
        blockedBy: nextBlockedBy,
        updatedAt: db.serverDate()
      }
    })
  }

  return {
    ok: true,
    existed: false,
    blockId: res._id,
    block: Object.assign(
      {
        _id: res._id
      },
      blockData
    )
  }
}