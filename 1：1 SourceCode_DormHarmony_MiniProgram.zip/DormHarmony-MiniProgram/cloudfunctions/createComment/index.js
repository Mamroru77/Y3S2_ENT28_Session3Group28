const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function cleanText(value, maxLength) {
  return String(value || '').trim().slice(0, maxLength || 500)
}

function localRiskCheck(text) {
  const bannedWords = [
    '微信号',
    '手机号',
    '加我',
    '裸聊',
    '赌博',
    '博彩',
    '诈骗',
    '转账',
    '约炮',
    '色情',
    '代写',
    '贷款',
    '刷单'
  ]

  const content = cleanText(text).toLowerCase()

  const hitWord = bannedWords.find(word => {
    return content.indexOf(String(word).toLowerCase()) > -1
  })

  return {
    safe: !hitWord,
    keyword: hitWord || ''
  }
}

async function getCurrentUser(openid) {
  const res = await db.collection('users')
    .doc(openid)
    .get()
    .catch(() => null)

  return res && res.data ? res.data : null
}

async function getComment(commentId) {
  if (!commentId) return null

  const res = await db.collection('comments')
    .doc(commentId)
    .get()
    .catch(() => null)

  return res && res.data ? res.data : null
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const postId = cleanText(event.postId, 120)
  const content = cleanText(event.content, 500)
  const parentCommentId = cleanText(event.parentCommentId, 120)

  if (!postId) {
    return {
      ok: false,
      code: 'EMPTY_POST_ID',
      message: 'Post ID is required.'
    }
  }

  if (!content) {
    return {
      ok: false,
      code: 'EMPTY_CONTENT',
      message: 'Comment content is required.'
    }
  }

  const risk = localRiskCheck(content)

  if (!risk.safe) {
    return {
      ok: false,
      code: 'CONTENT_RISK',
      message: 'Comment contains risky words. Please revise it.',
      keyword: risk.keyword
    }
  }

  const postRes = await db.collection('posts')
    .doc(postId)
    .get()
    .catch(() => null)

  if (!postRes || !postRes.data || postRes.data.status === 'deleted') {
    return {
      ok: false,
      code: 'POST_NOT_FOUND',
      message: 'Post not found.'
    }
  }

  const user = await getCurrentUser(openid)

  if (!user || !user.profileCompleted) {
    return {
      ok: false,
      code: 'PROFILE_INCOMPLETE',
      message: 'Please complete your profile first.'
    }
  }

  let rootCommentId = ''
  let replyToOpenid = ''
  let replyToName = ''

  if (parentCommentId) {
    const parentComment = await getComment(parentCommentId)

    if (!parentComment || parentComment.status === 'deleted') {
      return {
        ok: false,
        code: 'PARENT_COMMENT_NOT_FOUND',
        message: 'Parent comment not found.'
      }
    }

    if (parentComment.postId !== postId) {
      return {
        ok: false,
        code: 'COMMENT_POST_MISMATCH',
        message: 'Comment does not belong to this post.'
      }
    }

    rootCommentId = parentComment.rootCommentId || parentComment._id
    replyToOpenid = parentComment.authorOpenid || ''
    replyToName = parentComment.authorName || ''
  }

  const commentData = {
    postId,
    content,

    authorOpenid: openid,
    authorName: user.nickname || 'Dorm User',
    authorAvatarText: user.avatarText || String(user.nickname || 'D').slice(0, 1).toUpperCase(),

    parentCommentId,
    rootCommentId,
    replyToOpenid,
    replyToName,

    replyCount: 0,
    likeCount: 0,

    status: 'published',
    createdAt: db.serverDate(),
    updatedAt: db.serverDate()
  }

  const addRes = await db.collection('comments').add({
    data: commentData
  })

  await db.collection('posts')
    .doc(postId)
    .update({
      data: {
        commentCount: _.inc(1),
        updatedAt: db.serverDate()
      }
    })
    .catch(() => null)

  if (parentCommentId) {
    await db.collection('comments')
      .doc(rootCommentId)
      .update({
        data: {
          replyCount: _.inc(1),
          updatedAt: db.serverDate()
        }
      })
      .catch(() => null)
  }

  const latest = await db.collection('comments')
    .doc(addRes._id)
    .get()

  return {
    ok: true,
    comment: latest.data
  }
}