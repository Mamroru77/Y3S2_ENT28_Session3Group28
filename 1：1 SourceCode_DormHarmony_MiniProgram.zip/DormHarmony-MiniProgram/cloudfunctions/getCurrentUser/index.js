const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

async function getUser(openid) {
  try {
    const res = await db.collection('users').doc(openid).get()
    return res.data
  } catch (e) {
    return null
  }
}

exports.main = async () => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  let user = await getUser(openid)

  if (!user) {
    const newUser = {
      _id: openid,
      openid,
      nickname: '',
      email: '',
      emailVerified: false,
      verificationStatus: 'unverified',
      reputationScore: 100,
      role: 'student',
      createdAt: db.serverDate(),
      updatedAt: db.serverDate()
    }

    await db.collection('users').add({
      data: newUser
    })

    user = newUser
  }

  return {
    ok: true,
    user
  }
}