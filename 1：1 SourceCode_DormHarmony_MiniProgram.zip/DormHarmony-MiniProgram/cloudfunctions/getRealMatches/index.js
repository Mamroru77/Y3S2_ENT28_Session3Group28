const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()
const _ = db.command

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value))
}

function cleanText(value) {
  return String(value || '').trim()
}

function toNumber(value, fallback) {
  const n = Number(value)
  return Number.isNaN(n) ? fallback : n
}

function timeToMinutes(value, fallback) {
  const text = cleanText(value)

  if (!text || text.indexOf(':') === -1) return fallback

  const parts = text.split(':')
  const hour = Number(parts[0])
  const minute = Number(parts[1])

  if (Number.isNaN(hour) || Number.isNaN(minute)) return fallback

  return hour * 60 + minute
}

function timeDiffScore(timeA, timeB, maxDiffMinutes, maxScore) {
  const a = timeToMinutes(timeA, 0)
  const b = timeToMinutes(timeB, 0)

  let diff = Math.abs(a - b)

  if (diff > 720) {
    diff = 1440 - diff
  }

  const ratio = clamp(1 - diff / maxDiffMinutes, 0, 1)

  return Math.round(ratio * maxScore)
}

function numberDiffScore(valueA, valueB, maxDiff, maxScore) {
  const a = toNumber(valueA, 3)
  const b = toNumber(valueB, 3)
  const diff = Math.abs(a - b)
  const ratio = clamp(1 - diff / maxDiff, 0, 1)

  return Math.round(ratio * maxScore)
}

function arrayOverlapScore(listA, listB, maxScore) {
  const a = Array.isArray(listA) ? listA : []
  const b = Array.isArray(listB) ? listB : []

  if (!a.length || !b.length) {
    return {
      score: 0,
      overlap: []
    }
  }

  const setB = new Set(b.map(item => String(item)))
  const overlap = a.filter(item => setB.has(String(item)))

  const ratio = clamp(overlap.length / Math.max(a.length, b.length), 0, 1)

  return {
    score: Math.round(ratio * maxScore),
    overlap
  }
}

function arrayOverlap(listA, listB) {
  const a = Array.isArray(listA) ? listA : []
  const b = Array.isArray(listB) ? listB : []
  const setB = new Set(b.map(item => String(item)))

  return a.filter(item => setB.has(String(item)))
}

function allowsGender(preference, selfGender, targetGender) {
  if (!selfGender || !targetGender) return false

  if (selfGender === 'prefer_not_to_say') return false
  if (targetGender === 'prefer_not_to_say') return false

  if (preference === 'same') {
    return selfGender === targetGender
  }

  if (preference === 'male') {
    return targetGender === 'male'
  }

  if (preference === 'female') {
    return targetGender === 'female'
  }

  if (preference === 'any') {
    return true
  }

  return selfGender === targetGender
}

function isGenderCompatible(currentUser, candidateUser) {
  const currentGender = currentUser.gender
  const candidateGender = candidateUser.gender

  const currentLivingType = currentUser.livingType || 'school_dorm'
  const candidateLivingType = candidateUser.livingType || 'school_dorm'

  if (!currentGender || !candidateGender) return false
  if (currentGender === 'prefer_not_to_say') return false
  if (candidateGender === 'prefer_not_to_say') return false

  if (currentLivingType === 'school_dorm') {
    return candidateLivingType === 'school_dorm' && currentGender === candidateGender
  }

  if (currentLivingType === 'off_campus') {
    if (candidateLivingType !== 'off_campus') return false

    const currentPreference = currentUser.matchGenderPreference || 'same'
    const candidatePreference = candidateUser.matchGenderPreference || 'same'

    return allowsGender(currentPreference, currentGender, candidateGender) &&
      allowsGender(candidatePreference, candidateGender, currentGender)
  }

  return false
}

function getScoreClass(score) {
  if (score >= 85) return 'high'
  if (score >= 70) return 'medium'
  return 'low'
}

function getScoreLevel(score, lang) {
  if (lang === 'zh') {
    if (score >= 85) return '高度匹配'
    if (score >= 70) return '中高匹配'
    if (score >= 55) return '可进一步沟通'
    return '存在明显差异'
  }

  if (score >= 85) return 'High Match'
  if (score >= 70) return 'Good Match'
  if (score >= 55) return 'Worth Discussing'
  return 'Clear Differences'
}

function getReputationLevel(score, lang) {
  const value = toNumber(score, 100)

  if (lang === 'zh') {
    if (value >= 90) return '稳定'
    if (value >= 75) return '正常'
    return '需观察'
  }

  if (value >= 90) return 'Stable'
  if (value >= 75) return 'Normal'
  return 'Needs Review'
}

function buildDisplayTags(user, questionnaire) {
  const tags = []

  if (user.livingType === 'school_dorm') {
    tags.push('School Dorm')
  } else if (user.livingType === 'off_campus') {
    tags.push('Off-campus')
  }

  if (user.gender === 'male') tags.push('Male')
  if (user.gender === 'female') tags.push('Female')

  if (questionnaire.dormVibe) {
    tags.push(questionnaire.dormVibe)
  }

  if (questionnaire.mbti) {
    tags.push(questionnaire.mbti)
  } else if (user.mbti) {
    tags.push(user.mbti)
  }

  const lifestyleTags = Array.isArray(questionnaire.lifestyleTags)
    ? questionnaire.lifestyleTags
    : []

  lifestyleTags.slice(0, 2).forEach(item => tags.push(item))

  return tags.filter(Boolean).slice(0, 6)
}

function buildStrengths(currentQ, candidateQ, candidateUser, lang) {
  const strengths = []

  const sleepDiff = Math.abs(
    timeToMinutes(currentQ.sleepTime, 0) -
    timeToMinutes(candidateQ.sleepTime, 0)
  )

  if (sleepDiff <= 60) {
    strengths.push(lang === 'zh'
      ? '你们的睡觉时间较接近，作息冲突风险较低。'
      : 'Your sleep schedules are close, so schedule conflict risk is lower.')
  }

  if (Math.abs(toNumber(currentQ.cleanliness, 3) - toNumber(candidateQ.cleanliness, 3)) <= 1) {
    strengths.push(lang === 'zh'
      ? '你们对卫生整洁的要求比较接近。'
      : 'Your cleanliness expectations are relatively similar.')
  }

  if (Math.abs(toNumber(currentQ.visitorAcceptance, 3) - toNumber(candidateQ.visitorAcceptance, 3)) <= 1) {
    strengths.push(lang === 'zh'
      ? '你们对访客边界的接受度比较接近。'
      : 'Your visitor-boundary expectations are relatively close.')
  }

  const greenOverlap = arrayOverlap(currentQ.greenFlags, candidateQ.greenFlags)
  if (greenOverlap.length) {
    strengths.push(lang === 'zh'
      ? `你们都重视 ${greenOverlap.slice(0, 2).join('、')}。`
      : `You both value ${greenOverlap.slice(0, 2).join(', ')}.`)
  }

  if (!strengths.length) {
    strengths.push(lang === 'zh'
      ? `${candidateUser.nickname || '该用户'} 的资料完整，可以进一步沟通具体生活边界。`
      : `${candidateUser.nickname || 'This user'} has a complete profile. Further boundary discussion is recommended.`)
  }

  return strengths.slice(0, 4)
}

function buildRisks(currentQ, candidateQ, lang) {
  const risks = []

  const sleepDiff = Math.abs(
    timeToMinutes(currentQ.sleepTime, 0) -
    timeToMinutes(candidateQ.sleepTime, 0)
  )

  if (sleepDiff > 120 && sleepDiff < 1320) {
    risks.push(lang === 'zh'
      ? '你们的睡觉时间差异较大，需要提前确认安静时间。'
      : 'Your sleep schedules differ significantly. Quiet hours should be confirmed early.')
  }

  if (Math.abs(toNumber(currentQ.noiseTolerance, 3) - toNumber(candidateQ.noiseTolerance, 3)) >= 3) {
    risks.push(lang === 'zh'
      ? '你们对噪音的接受度差异较大。'
      : 'Your noise tolerance differs significantly.')
  }

  if (Math.abs(toNumber(currentQ.cleanliness, 3) - toNumber(candidateQ.cleanliness, 3)) >= 3) {
    risks.push(lang === 'zh'
      ? '你们对卫生标准的要求差异较大。'
      : 'Your cleanliness standards differ significantly.')
  }

  if (Math.abs(toNumber(currentQ.visitorAcceptance, 3) - toNumber(candidateQ.visitorAcceptance, 3)) >= 3) {
    risks.push(lang === 'zh'
      ? '你们对访客边界的接受度差异较大。'
      : 'Your visitor-boundary expectations differ significantly.')
  }

  const redOverlap = arrayOverlap(currentQ.redFlags, candidateQ.redFlags)
  if (redOverlap.length) {
    risks.push(lang === 'zh'
      ? `共同敏感点包括：${redOverlap.slice(0, 2).join('、')}，建议提前沟通。`
      : `Shared sensitive points include: ${redOverlap.slice(0, 2).join(', ')}. Discuss them early.`)
  }

  if (!risks.length) {
    risks.push(lang === 'zh'
      ? '暂未发现明显硬性冲突，但仍建议先沟通作息、卫生和访客规则。'
      : 'No obvious hard conflict detected, but schedule, cleaning and visitor rules should still be discussed.')
  }

  return risks.slice(0, 4)
}

function buildSuggestedQuestions(currentQ, candidateQ, lang) {
  const questions = []

  questions.push(lang === 'zh'
    ? '你通常几点之后希望宿舍保持安静？'
    : 'After what time do you expect the room to stay quiet?')

  questions.push(lang === 'zh'
    ? '公共区域清洁你希望如何分工？'
    : 'How would you prefer to divide shared-area cleaning?')

  questions.push(lang === 'zh'
    ? '朋友来宿舍前是否需要提前说明？'
    : 'Should visitors be mentioned in advance?')

  if (Math.abs(toNumber(currentQ.acTemp, 24) - toNumber(candidateQ.acTemp, 24)) >= 3) {
    questions.push(lang === 'zh'
      ? '你能接受的空调温度范围是多少？'
      : 'What AC temperature range is acceptable for you?')
  }

  return questions
}

function calculateMatch(currentUser, currentQ, candidateUser, candidateQ, lang) {
  let score = 0

  score += timeDiffScore(currentQ.sleepTime, candidateQ.sleepTime, 180, 12)
  score += timeDiffScore(currentQ.wakeTime, candidateQ.wakeTime, 180, 8)
  score += timeDiffScore(currentQ.lightsOffTime, candidateQ.lightsOffTime, 180, 15)

  score += numberDiffScore(currentQ.noiseTolerance, candidateQ.noiseTolerance, 4, 15)
  score += numberDiffScore(currentQ.cleanliness, candidateQ.cleanliness, 4, 15)
  score += numberDiffScore(currentQ.visitorAcceptance, candidateQ.visitorAcceptance, 4, 15)

  const currentAc = cleanText(currentQ.acTemp || currentQ.acTemperature).replace(/[^0-9]/g, '')
  const candidateAc = cleanText(candidateQ.acTemp || candidateQ.acTemperature).replace(/[^0-9]/g, '')
  score += numberDiffScore(currentAc, candidateAc, 8, 8)

  score += numberDiffScore(
    currentQ.spacePreference || currentQ.studySpacePreference,
    candidateQ.spacePreference || candidateQ.studySpacePreference,
    4,
    7
  )

  const lifestyle = arrayOverlapScore(currentQ.lifestyleTags, candidateQ.lifestyleTags, 10)
  score += lifestyle.score

  const greenOverlap = arrayOverlap(currentQ.greenFlags, candidateQ.greenFlags)
  score += Math.min(greenOverlap.length * 2, 5)

  const redOverlap = arrayOverlap(currentQ.redFlags, candidateQ.redFlags)
  score -= Math.min(redOverlap.length * 5, 15)

  const reputationScore = toNumber(candidateUser.reputationScore, 100)
  if (reputationScore >= 90) {
    score += 5
  } else if (reputationScore < 70) {
    score -= 10
  } else if (reputationScore < 80) {
    score -= 5
  }

  score = clamp(Math.round(score), 0, 100)

  const strengths = buildStrengths(currentQ, candidateQ, candidateUser, lang)
  const risks = buildRisks(currentQ, candidateQ, lang)
  const suggestedQuestions = buildSuggestedQuestions(currentQ, candidateQ, lang)

  return {
    id: candidateUser._id,
    candidateOpenid: candidateUser._id,
    isRealUser: true,

    name: candidateUser.nickname || 'Dorm User',
    year: candidateUser.year || '',
    campus: candidateUser.campus || '',
    school: candidateUser.school || '',
    major: candidateUser.major || '',
    mbti: candidateUser.mbti || candidateQ.mbti || '',

    displayCampus: candidateUser.campus || '',
    displaySchool: candidateUser.school || '',
    displayMajor: candidateUser.major || '',

    gender: candidateUser.gender || '',
    livingType: candidateUser.livingType || 'school_dorm',
    matchGenderPreference: candidateUser.matchGenderPreference || 'same',

    reputationScore,
    displayReputationLevel: getReputationLevel(reputationScore, lang),

    score,
    scoreClass: getScoreClass(score),
    scoreLevel: getScoreLevel(score, lang),
    scoreStyle: `width: ${score}%;`,

    displayTags: buildDisplayTags(candidateUser, candidateQ),

    strengths,
    risks,
    hardConflicts: risks.filter(item => {
      return item.indexOf('差异较大') > -1 || item.indexOf('differ') > -1
    }),

    suggestedQuestions,

    profile: candidateQ
  }
}

async function getBlockedOpenidSet(openid) {
  const set = new Set()

  const blockRes = await db.collection('blocks')
    .where({
      status: 'active'
    })
    .limit(100)
    .get()
    .catch(() => ({ data: [] }))

  ;(blockRes.data || []).forEach(item => {
    const blocker = item.blockerOpenid
    const target = item.targetOpenid

    if (blocker === openid && target) {
      set.add(target)
    }

    if (target === openid && blocker) {
      set.add(blocker)
    }
  })

  return set
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const lang = event.lang === 'en' ? 'en' : 'zh'
  const limit = clamp(Number(event.limit || 20), 1, 50)

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const currentUserRes = await db.collection('users')
    .doc(openid)
    .get()
    .catch(() => null)

  if (!currentUserRes || !currentUserRes.data) {
    return {
      ok: false,
      code: 'USER_NOT_FOUND',
      message: 'User profile not found.'
    }
  }

  const currentUser = currentUserRes.data

  if (!currentUser.profileCompleted) {
    return {
      ok: false,
      code: 'PROFILE_INCOMPLETE',
      message: 'Please complete your basic profile first.'
    }
  }

  if (currentUser.status && currentUser.status !== 'active') {
    return {
      ok: false,
      code: 'USER_NOT_ACTIVE',
      message: 'Current user is not active.'
    }
  }

  if (!currentUser.gender || currentUser.gender === 'prefer_not_to_say') {
    return {
      ok: false,
      code: 'GENDER_REQUIRED',
      message: 'Please select a clear gender before real-user matching.'
    }
  }

  const currentQRes = await db.collection('questionnaires')
    .doc(openid)
    .get()
    .catch(() => null)

  if (!currentQRes || !currentQRes.data) {
    return {
      ok: false,
      code: 'QUESTIONNAIRE_NOT_FOUND',
      message: 'Please complete your lifestyle questionnaire first.'
    }
  }

  const currentQ = currentQRes.data

  if (currentQ.status && currentQ.status !== 'active') {
    return {
      ok: false,
      code: 'QUESTIONNAIRE_NOT_ACTIVE',
      message: 'Current questionnaire is not active.'
    }
  }

  const blockedOpenids = await getBlockedOpenidSet(openid)

  const userRes = await db.collection('users')
    .where({
      profileCompleted: true
    })
    .limit(100)
    .get()

  const candidates = (userRes.data || []).filter(user => {
    if (!user || !user._id) return false
    if (user._id === openid) return false

    // 兼容旧用户：没有 status 的用户允许进入候选池；
    // 只有明确不是 active 的用户才排除。
    if (user.status && user.status !== 'active') return false

    if (blockedOpenids.has(user._id)) return false
    if (!user.gender || user.gender === 'prefer_not_to_say') return false
    if (!isGenderCompatible(currentUser, user)) return false

    return true
  })

  if (!candidates.length) {
    return {
      ok: true,
      mode: 'real',
      total: 0,
      matches: [],
      message: 'No compatible real users found.'
    }
  }

  const candidateOpenids = candidates.map(item => item._id)

  const questionnaireRes = await db.collection('questionnaires')
    .where({
      _id: _.in(candidateOpenids)
    })
    .limit(100)
    .get()

  const questionnaireMap = {}

  ;(questionnaireRes.data || []).forEach(item => {
    // 兼容旧问卷：没有 status 的问卷允许参与匹配；
    // 只有明确不是 active 的问卷才排除。
    if (item.status && item.status !== 'active') return

    questionnaireMap[item._id] = item
  })

  const matches = candidates
    .filter(user => !!questionnaireMap[user._id])
    .map(user => calculateMatch(currentUser, currentQ, user, questionnaireMap[user._id], lang))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)

  return {
    ok: true,
    mode: 'real',
    total: matches.length,
    matches
  }
}