const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const blockId = cleanText(event.blockId)

  if (!blockId) {
    return {
      ok: false,
      code: 'EMPTY_BLOCK_ID',
      message: 'Block ID is required.'
    }
  }

  const blockRes = await db.collection('blocks')
    .doc(blockId)
    .get()
    .catch(() => null)

  if (!blockRes || !blockRes.data) {
    return {
      ok: false,
      code: 'BLOCK_NOT_FOUND',
      message: 'Block record not found.'
    }
  }

  const block = blockRes.data

  if (block.blockerOpenid !== openid) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You can only unblock your own block record.'
    }
  }

  await db.collection('blocks').doc(blockId).update({
    data: {
      status: 'inactive',
      unblockedAt: db.serverDate(),
      updatedAt: db.serverDate()
    }
  })

  if (block.conversationId) {
    const conversationRes = await db.collection('conversations')
      .doc(block.conversationId)
      .get()
      .catch(() => null)

    if (conversationRes && conversationRes.data) {
      const conversation = conversationRes.data
      const blockedBy = Array.isArray(conversation.blockedBy)
        ? conversation.blockedBy
        : []

      const nextBlockedBy = blockedBy.filter(item => item !== openid)

      await db.collection('conversations').doc(block.conversationId).update({
        data: {
          blockedBy: nextBlockedBy,
          updatedAt: db.serverDate()
        }
      })
    }
  }

  return {
    ok: true,
    blockId
  }
}