const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value) {
  return String(value || '').trim()
}

function isParticipant(conversation, openid) {
  const participants = conversation.participants || []
  return participants.indexOf(openid) > -1
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const conversationId = cleanText(event.conversationId)
  const limit = Math.min(Number(event.limit || 50), 100)

  if (!conversationId) {
    return {
      ok: false,
      code: 'EMPTY_CONVERSATION_ID',
      message: 'Conversation ID is required.'
    }
  }

  const conversationRes = await db.collection('conversations')
    .doc(conversationId)
    .get()
    .catch(() => null)

  if (!conversationRes || !conversationRes.data) {
    return {
      ok: false,
      code: 'CONVERSATION_NOT_FOUND',
      message: 'Conversation not found.'
    }
  }

  const conversation = conversationRes.data

  if (!isParticipant(conversation, openid)) {
    return {
      ok: false,
      code: 'NO_PERMISSION',
      message: 'You are not a participant of this conversation.'
    }
  }

  const messageRes = await db.collection('messages')
    .where({
      conversationId,
      status: 'sent'
    })
    .orderBy('createdAt', 'asc')
    .limit(limit)
    .get()

  const messages = (messageRes.data || []).map(item => {
    return Object.assign({}, item, {
      isMine: item.senderOpenid === openid
    })
  })

  return {
    ok: true,
    conversation,
    messages
  }
}