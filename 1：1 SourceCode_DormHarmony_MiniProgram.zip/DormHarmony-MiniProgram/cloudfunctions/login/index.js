const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

async function getOrCreateUser(openid) {
  const now = db.serverDate()

  try {
    const res = await db.collection('users').doc(openid).get()
    const user = res.data || {}

    await db.collection('users').doc(openid).update({
      data: {
        lastLoginAt: now,
        updatedAt: now
      }
    })

    const latestRes = await db.collection('users').doc(openid).get()

    return latestRes.data || user
  } catch (e) {
    const user = {
      _id: openid,
      openid,

      nickname: '',
      avatarText: 'D',

      year: '',
      campus: '',
      school: '',
      major: '',
      mbti: '',
      bio: '',

      email: '',
      emailVerified: false,
      verificationStatus: 'skipped',

      reputationScore: 100,
      role: 'student',
      profileCompleted: false,

      status: 'active',
      createdAt: now,
      updatedAt: now,
      lastLoginAt: now
    }

    await db.collection('users').add({
      data: user
    })

    return user
  }
}

exports.main = async () => {
  const wxContext = cloud.getWXContext()

  const openid = wxContext.OPENID || ''
  const appid = wxContext.APPID || ''
  const unionid = wxContext.UNIONID || ''

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get WeChat openid.'
    }
  }

  const user = await getOrCreateUser(openid)

  return {
    ok: true,
    openid,
    appid,
    unionid,
    user
  }
}