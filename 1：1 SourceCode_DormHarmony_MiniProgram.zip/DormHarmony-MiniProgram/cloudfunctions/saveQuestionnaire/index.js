const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

function cleanText(value, maxLength) {
  return String(value || '').trim().slice(0, maxLength || 300)
}

function cleanNumber(value, fallback) {
  const number = Number(value)

  if (Number.isNaN(number)) {
    return fallback
  }

  return number
}

function cleanArray(value, maxItems) {
  if (!Array.isArray(value)) return []

  return value
    .map(item => cleanText(item, 80))
    .filter(Boolean)
    .slice(0, maxItems || 8)
}

function normalizeQuestionnaire(raw) {
  return {
    sleepTime: cleanText(raw.sleepTime || raw.sleepTimeCode || '23:30', 20),
    sleepTimeCode: cleanText(raw.sleepTimeCode || raw.sleepTime || '23:30', 20),

    wakeTime: cleanText(raw.wakeTime || raw.wakeTimeCode || '07:30', 20),
    wakeTimeCode: cleanText(raw.wakeTimeCode || raw.wakeTime || '07:30', 20),

    lightsOffTime: cleanText(raw.lightsOffTime || raw.lightsOffCode || raw.lightsOff || '23:45', 20),
    lightsOffCode: cleanText(raw.lightsOffCode || raw.lightsOffTime || raw.lightsOff || '23:45', 20),
    lightsOff: cleanText(raw.lightsOff || raw.lightsOffTime || raw.lightsOffCode || '23:45', 20),

    noiseTolerance: cleanNumber(raw.noiseTolerance, 3),
    noiseToleranceLabel: cleanText(raw.noiseToleranceLabel || '', 80),

    cleanliness: cleanNumber(raw.cleanliness, 3),
    cleanlinessLabel: cleanText(raw.cleanlinessLabel || '', 80),

    acTemp: cleanText(raw.acTemp || raw.acTemperature || '24', 20),
    acTemperature: cleanText(raw.acTemperature || raw.acTemp || '24°C', 20),

    visitorAcceptance: cleanNumber(raw.visitorAcceptance, 3),
    visitorBoundary: cleanText(raw.visitorBoundary || '', 80),

    socialTendency: cleanNumber(raw.socialTendency || raw.socialStyle, 3),
    socialStyle: cleanNumber(raw.socialStyle || raw.socialTendency, 3),

    studySpacePreference: cleanText(raw.studySpacePreference || raw.studySpace || raw.spacePreference || '3', 80),
    studySpace: cleanText(raw.studySpace || raw.studySpacePreference || '', 80),
    spacePreference: cleanNumber(raw.spacePreference, 3),

    mbti: cleanText(raw.mbti || 'Not sure', 20),
    dormVibe: cleanText(raw.dormVibe || '', 80),

    lifestyleTags: cleanArray(raw.lifestyleTags, 8),
    lifestyleTagLabels: cleanArray(raw.lifestyleTagLabels, 8),

    redFlags: cleanArray(raw.redFlags, 8),
    redFlagLabels: cleanArray(raw.redFlagLabels, 8),

    greenFlags: cleanArray(raw.greenFlags, 8),
    greenFlagLabels: cleanArray(raw.greenFlagLabels, 8),

    unacceptableBehavior: cleanText(raw.unacceptableBehavior, 300),

    display: raw.display || {}
  }
}

exports.main = async (event) => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  if (!openid) {
    return {
      ok: false,
      code: 'NO_OPENID',
      message: 'Unable to get user identity.'
    }
  }

  const userRes = await db.collection('users')
    .doc(openid)
    .get()
    .catch(() => null)

  if (!userRes || !userRes.data) {
    return {
      ok: false,
      code: 'USER_NOT_FOUND',
      message: 'User profile not found.'
    }
  }

  const user = userRes.data

  if (!user.profileCompleted) {
    return {
      ok: false,
      code: 'PROFILE_INCOMPLETE',
      message: 'Please complete your basic profile first.'
    }
  }

  const payload = normalizeQuestionnaire(event.questionnaire || event || {})

  const docData = {
    _id: openid,
    openid,

    gender: user.gender || '',
    livingType: user.livingType || 'school_dorm',
    matchGenderPreference: user.matchGenderPreference || 'same',

    ...payload,

    status: 'active',
    updatedAt: db.serverDate()
  }

  const existing = await db.collection('questionnaires')
    .doc(openid)
    .get()
    .catch(() => null)

  if (existing && existing.data) {
    await db.collection('questionnaires').doc(openid).update({
      data: {
        gender: docData.gender,
        livingType: docData.livingType,
        matchGenderPreference: docData.matchGenderPreference,

        ...payload,

        status: 'active',
        updatedAt: db.serverDate()
      }
    })
  } else {
    await db.collection('questionnaires').add({
      data: {
        ...docData,
        createdAt: db.serverDate()
      }
    })
  }

  const latestRes = await db.collection('questionnaires').doc(openid).get()

  return {
    ok: true,
    questionnaire: latestRes.data
  }
}