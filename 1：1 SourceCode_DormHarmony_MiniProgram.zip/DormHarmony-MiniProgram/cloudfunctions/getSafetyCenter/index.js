const cloud = require('wx-server-sdk')

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

const db = cloud.database()

exports.main = async () => {
  const wxContext = cloud.getWXContext()
  const openid = wxContext.OPENID

  const reportRes = await db.collection('reports')
    .where({
      reporterOpenid: openid
    })
    .limit(50)
    .get()

  const blockRes = await db.collection('blocks')
    .where({
      blockerOpenid: openid,
      status: 'active'
    })
    .limit(50)
    .get()

  return {
    ok: true,
    reports: reportRes.data || [],
    blocks: blockRes.data || []
  }
}