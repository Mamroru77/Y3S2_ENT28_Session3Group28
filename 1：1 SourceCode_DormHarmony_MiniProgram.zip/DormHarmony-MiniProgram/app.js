const CLOUD_ENV_ID = 'cloud1-d7gbnnvzffa05224a'

App({
  globalData: {
    lang: 'zh',
    cloudEnvId: CLOUD_ENV_ID,
    openid: '',
    userProfile: null,
    loginReady: false
  },

  onLaunch() {
    this.initLanguage()
    this.initCloud()
    this.restoreLoginCache()
  },

  initLanguage() {
    const savedLang = wx.getStorageSync('dh_lang') || 'zh'
    this.globalData.lang = savedLang
  },

  initCloud() {
    if (!wx.cloud) {
      console.error('当前微信基础库不支持云开发，wx.cloud 不存在')
      return
    }

    wx.cloud.init({
      env: CLOUD_ENV_ID,
      traceUser: true
    })

    console.log('DormHarmony 云开发初始化成功:', CLOUD_ENV_ID)
  },

  restoreLoginCache() {
    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    this.globalData.openid = openid
    this.globalData.userProfile = user
    this.globalData.loginReady = !!openid
  },

  ensureLogin(callback) {
    if (!wx.cloud || !wx.cloud.callFunction) {
      console.error('wx.cloud.callFunction 不存在，无法登录')
      if (typeof callback === 'function') callback(false)
      return
    }

    wx.cloud.callFunction({
      name: 'login',
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          console.error('login 云函数返回失败:', result)
          this.globalData.loginReady = false

          if (typeof callback === 'function') {
            callback(false, result)
          }

          return
        }

        this.globalData.openid = result.openid || ''
        this.globalData.userProfile = result.user || null
        this.globalData.loginReady = true

        wx.setStorageSync('dh_openid', result.openid || '')
        wx.setStorageSync('dh_current_user', result.user || null)

        console.log('DormHarmony 微信登录成功:', result.openid)

        if (typeof callback === 'function') {
          callback(true, result)
        }
      },
      fail: (err) => {
        console.error('login 云函数调用失败:', err)
        this.globalData.loginReady = false

        if (typeof callback === 'function') {
          callback(false, err)
        }
      }
    })
  },

  setLanguage(lang) {
    this.globalData.lang = lang
    wx.setStorageSync('dh_lang', lang)

    if (this.applyTabBarLanguage) {
      this.applyTabBarLanguage()
    }
  },

  applyTabBarLanguage() {
    const lang = wx.getStorageSync('dh_lang') || this.globalData.lang || 'zh'

    const zhList = ['首页', '匹配', '社区', '沟通', '我的']
    const enList = ['Home', 'Match', 'Community', 'Chat', 'Me']

    const list = lang === 'zh' ? zhList : enList

    list.forEach((text, index) => {
      wx.setTabBarItem({
        index,
        text
      })
    })
  },

  setOpenid(openid) {
    this.globalData.openid = openid
    this.globalData.loginReady = !!openid
    wx.setStorageSync('dh_openid', openid)
  },

  getOpenid() {
    return this.globalData.openid || wx.getStorageSync('dh_openid') || ''
  },

  setUserProfile(user) {
    this.globalData.userProfile = user || null
    wx.setStorageSync('dh_current_user', user || null)
  },

  getUserProfile() {
    return this.globalData.userProfile || wx.getStorageSync('dh_current_user') || null
  },

  clearLogin() {
    this.globalData.openid = ''
    this.globalData.userProfile = null
    this.globalData.loginReady = false

    wx.removeStorageSync('dh_openid')
    wx.removeStorageSync('dh_current_user')
  }
})