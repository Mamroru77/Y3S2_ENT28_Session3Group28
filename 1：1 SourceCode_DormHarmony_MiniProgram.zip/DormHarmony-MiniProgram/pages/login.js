const app = getApp()

const {
  getCurrentLang,
  getPageText,
  setCurrentLang
} = require('../../utils/i18n')

const {
  saveUser
} = require('../../utils/storage')

const {
  initReputation,
  updateReputation,
  evaluateStudentEmail
} = require('../../utils/reputation')

Page({
  data: {
    lang: 'zh',
    text: {},
    nickname: '',
    email: ''
  },

  onLoad() {
    initReputation()
    this.refreshLanguage()
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  refreshLanguage() {
    const lang = getCurrentLang()
    const text = getPageText('login', lang)

    this.setData({
      lang,
      text
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.refreshLanguage()

    wx.showToast({
      title: nextLang === 'zh' ? '已切换中文' : 'Switched to English',
      icon: 'none'
    })
  },

  onNicknameInput(event) {
    this.setData({
      nickname: event.detail.value
    })
  },

  onEmailInput(event) {
    this.setData({
      email: event.detail.value
    })
  },

  handleLogin() {
    const nickname = String(this.data.nickname || '').trim()
    const email = String(this.data.email || '').trim().toLowerCase()

    if (!nickname) {
      wx.showToast({
        title: this.data.lang === 'zh' ? '请先填写昵称' : 'Please enter nickname',
        icon: 'none'
      })
      return
    }

    if (!email) {
      wx.showToast({
        title: this.data.lang === 'zh' ? '请填写学生邮箱' : 'Please enter student email',
        icon: 'none'
      })
      return
    }

    const emailEvaluation = evaluateStudentEmail(email)

    updateReputation(
      emailEvaluation.change,
      emailEvaluation.reasonEn,
      emailEvaluation.reasonZh,
      emailEvaluation.type
    )

    const user = {
      nickname,
      email,
      verified: emailEvaluation.verified,
      loginType: 'student_email_simulation',
      createdAt: new Date().toISOString()
    }

    saveUser(user)

    wx.showToast({
      title: emailEvaluation.verified
        ? this.data.lang === 'zh'
          ? '学生认证成功'
          : 'Student verified'
        : this.data.lang === 'zh'
          ? '未认证用户继续'
          : 'Continue as unverified',
      icon: 'none'
    })

    setTimeout(() => {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
    }, 600)
  },

  continueDemo() {
    const user = {
      nickname: 'Demo Student',
      email: 'demo@student.xjtlu.edu.cn',
      verified: true,
      loginType: 'demo',
      createdAt: new Date().toISOString()
    }

    saveUser(user)

    updateReputation(
      8,
      'Demo student verification completed.',
      '演示学生身份认证完成。',
      'demo_verification'
    )

    wx.navigateTo({
      url: '/pages/profileSetup/profileSetup'
    })
  }
})