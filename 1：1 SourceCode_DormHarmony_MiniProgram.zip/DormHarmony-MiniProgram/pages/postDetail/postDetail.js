const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '社区帖子',
    title: '帖子详情',
    languageButton: 'EN',

    comments: '评论',
    replies: '回复',
    reply: '回复',
    cancelReply: '取消回复',
    replyTo: '回复',
    inputPlaceholder: '写下你的评论……',
    replyPlaceholder: '回复 {{name}}……',
    send: '发送',
    refresh: '刷新',
    emptyComments: '还没有评论，来写第一条吧。',
    contentEmpty: '请输入内容',
    commentSuccess: '已发布',
    commentFailed: '发布失败',
    networkError: '网络异常，请稍后再试',
    postNotFound: '帖子不存在或已删除',
    back: '返回'
  },

  en: {
    eyebrow: 'Community Post',
    title: 'Post Detail',
    languageButton: '中文',

    comments: 'Comments',
    replies: 'Replies',
    reply: 'Reply',
    cancelReply: 'Cancel Reply',
    replyTo: 'Reply to',
    inputPlaceholder: 'Write a comment...',
    replyPlaceholder: 'Reply to {{name}}...',
    send: 'Send',
    refresh: 'Refresh',
    emptyComments: 'No comments yet. Start the discussion.',
    contentEmpty: 'Please enter content',
    commentSuccess: 'Published',
    commentFailed: 'Failed to publish',
    networkError: 'Network error. Please try again later.',
    postNotFound: 'Post not found or deleted',
    back: 'Back'
  }
}

function getReplyPlaceholder(text, replyTarget) {
  if (!replyTarget) return text.inputPlaceholder

  return text.replyPlaceholder.replace('{{name}}', replyTarget.authorName || 'User')
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    postId: '',
    post: null,
    comments: [],

    inputValue: '',
    replyTarget: null,
    inputPlaceholder: '',

    loading: false,
    sending: false
  },

  onLoad(options) {
    const postId = options.id || options.postId || ''

    this.setData({
      postId
    })

    this.initPage()
  },

  onShow() {
    this.initPage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  initPage() {
    if (!this.guardLogin()) return

    const lang = getCurrentLang()
    const text = pageText[lang]

    this.setData({
      lang,
      text,
      inputPlaceholder: getReplyPlaceholder(text, this.data.replyTarget)
    })

    if (!this.data.postId) {
      wx.showToast({
        title: text.postNotFound,
        icon: 'none'
      })
      return
    }

    this.loadPost()
    this.loadComments()
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'
    const text = pageText[nextLang]

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.setData({
      lang: nextLang,
      text,
      inputPlaceholder: getReplyPlaceholder(text, this.data.replyTarget)
    })
  },

  loadPost() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    this.setData({
      loading: true
    })

    wx.cloud.callFunction({
      name: 'getPostDetail',
      data: {
        postId: this.data.postId
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.postNotFound,
            icon: 'none'
          })
          return
        }

        this.setData({
          post: result.post || null
        })
      },
      fail: (err) => {
        console.error('getPostDetail failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  loadComments() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getComments',
      data: {
        postId: this.data.postId
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          this.setData({
            comments: []
          })
          return
        }

        this.setData({
          comments: result.comments || []
        })
      },
      fail: (err) => {
        console.error('getComments failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      }
    })
  },

  refreshPage() {
    this.loadPost()
    this.loadComments()
  },

  onInput(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },

  startReply(e) {
    const commentId = e.currentTarget.dataset.id
    const authorName = e.currentTarget.dataset.name || 'User'
    const rootId = e.currentTarget.dataset.rootId || ''
    const parentId = e.currentTarget.dataset.parentId || commentId

    const replyTarget = {
      id: commentId,
      parentId,
      rootId,
      authorName
    }

    this.setData({
      replyTarget,
      inputPlaceholder: getReplyPlaceholder(this.data.text, replyTarget)
    })
  },

  cancelReply() {
    this.setData({
      replyTarget: null,
      inputPlaceholder: this.data.text.inputPlaceholder
    })
  },

  submitComment() {
    if (this.data.sending) return

    const content = String(this.data.inputValue || '').trim()

    if (!content) {
      wx.showToast({
        title: this.data.text.contentEmpty,
        icon: 'none'
      })
      return
    }

    const replyTarget = this.data.replyTarget

    this.setData({
      sending: true
    })

    wx.cloud.callFunction({
      name: 'createComment',
      data: {
        postId: this.data.postId,
        content,
        parentCommentId: replyTarget ? replyTarget.parentId : ''
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.commentFailed,
            icon: 'none'
          })
          return
        }

        wx.showToast({
          title: this.data.text.commentSuccess,
          icon: 'success'
        })

        this.setData({
          inputValue: '',
          replyTarget: null,
          inputPlaceholder: this.data.text.inputPlaceholder
        })

        this.loadPost()
        this.loadComments()
      },
      fail: (err) => {
        console.error('createComment failed:', err)
        wx.showToast({
          title: this.data.text.commentFailed,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          sending: false
        })
      }
    })
  },

  goBack() {
    wx.navigateBack()
  }
})