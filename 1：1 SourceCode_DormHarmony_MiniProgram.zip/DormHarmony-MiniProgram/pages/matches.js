Page({
  data: {},

  onLoad(options) {
    console.log('Match ID:', options.id)
  }
})