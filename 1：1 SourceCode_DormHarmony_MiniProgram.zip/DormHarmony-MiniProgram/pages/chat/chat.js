const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '沟通',
    title: 'Chat',
    languageButton: 'EN',

    emptyTitle: '还没有沟通对象',
    emptyDesc: '请先从匹配详情页发起沟通申请，然后在这里开始聊天。',
    goMatches: '去查看匹配',

    noMessage: '暂无消息',
    onlineHint: '安全沟通中',
    realUser: '真实用户',
    demoUser: '演示对象',

    inputPlaceholder: '输入你想发送的内容……',
    blockedPlaceholder: '当前会话已被拉黑，无法发送消息',
    send: '发送',
    more: '更多操作',
    close: '收起',

    suggestedTopics: '建议话题',
    quickMessages: '快速开场白',
    agreement: '生成合住协议',
    report: '举报',
    block: '拉黑',
    unblock: '解除拉黑',
    refresh: '刷新消息',
    deleteConversation: '删除会话',

    deleteConfirmTitle: '删除会话？',
    deleteConfirmContent: '这只会从你的会话列表中隐藏该会话，不会删除对方的聊天记录。',
    deleteSuccess: '会话已删除',

    copied: '已复制',
    sendEmpty: '请输入消息内容',
    sendFailed: '发送失败',
    networkError: '网络异常，请稍后再试',
    reportSuccess: '已提交举报',
    blockSuccess: '已拉黑',
    unblockSuccess: '已解除拉黑',

    suggestedQuestions: [
      '你通常几点之后希望宿舍保持安静？',
      '公共区域清洁你希望如何分工？',
      '朋友来宿舍前是否需要提前说明？',
      '如果之后合住，空调温度和公共费用怎么约定？'
    ],

    quickTexts: [
      '你好，我想先了解一下你的作息和公共区域习惯。',
      '我们可以先确认一下安静时间、访客和公共费用规则吗？',
      '我觉得提前说清楚边界会比较舒服，你怎么看？'
    ]
  },

  en: {
    eyebrow: 'Chat',
    title: 'Chat',
    languageButton: '中文',

    emptyTitle: 'No conversation yet',
    emptyDesc: 'Start a chat request from a match detail page, then continue the conversation here.',
    goMatches: 'View Matches',

    noMessage: 'No messages yet',
    onlineHint: 'Safe communication',
    realUser: 'Real User',
    demoUser: 'Demo',

    inputPlaceholder: 'Type your message...',
    blockedPlaceholder: 'This conversation is blocked. You cannot send messages.',
    send: 'Send',
    more: 'More',
    close: 'Close',

    suggestedTopics: 'Suggested Topics',
    quickMessages: 'Quick Openers',
    agreement: 'Generate Agreement',
    report: 'Report',
    block: 'Block',
    unblock: 'Unblock',
    refresh: 'Refresh',
    deleteConversation: 'Delete Conversation',

    deleteConfirmTitle: 'Delete conversation?',
    deleteConfirmContent: 'This only hides the conversation from your list. It will not delete the other user’s chat record.',
    deleteSuccess: 'Conversation deleted',

    copied: 'Copied',
    sendEmpty: 'Please enter a message',
    sendFailed: 'Failed to send',
    networkError: 'Network error. Please try again later.',
    reportSuccess: 'Report submitted',
    blockSuccess: 'Blocked',
    unblockSuccess: 'Unblocked',

    suggestedQuestions: [
      'After what time do you expect the room to stay quiet?',
      'How would you prefer to divide shared-area cleaning?',
      'Should visitors be mentioned in advance?',
      'If we live together later, how should we set AC and shared-cost rules?'
    ],

    quickTexts: [
      'Hi, I would like to learn about your schedule and shared-space habits first.',
      'Can we first confirm quiet hours, visitors and shared-cost rules?',
      'I think it is better to clarify boundaries early. What do you think?'
    ]
  }
}

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value && value.$date) {
    date = new Date(value.$date)
  } else {
    return ''
  }

  if (!date || Number.isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

function getCurrentOpenid() {
  const appOpenid = app && app.getOpenid ? app.getOpenid() : ''
  return appOpenid || wx.getStorageSync('dh_openid') || ''
}

function getTargetName(conversation, openid) {
  if (!conversation) return 'Dorm User'

  if (conversation.participantNames && conversation.participants) {
    const targetOpenid = conversation.participants.find(item => item !== openid && String(item).indexOf('demo_') !== 0)

    if (targetOpenid && conversation.participantNames[targetOpenid]) {
      return conversation.participantNames[targetOpenid]
    }
  }

  return conversation.targetName || 'Dorm User'
}

function getTargetId(conversation, openid) {
  if (!conversation) return ''

  if (conversation.conversationType === 'real_user' && Array.isArray(conversation.participants)) {
    return conversation.participants.find(item => item !== openid) || conversation.targetId || ''
  }

  return conversation.targetId || ''
}

function normalizeConversation(item, openid, lang) {
  const type = item.conversationType || item.targetType || 'match_demo'
  const isReal = type === 'real_user'

  const targetName = getTargetName(item, openid)
  const targetId = getTargetId(item, openid)

  return Object.assign({}, item, {
    id: item._id || item.id || item.conversationId,
    conversationId: item._id || item.id || item.conversationId,
    targetId,
    targetName,
    displayName: targetName,
    avatarText: item.targetAvatarText || String(targetName || 'D').slice(0, 1).toUpperCase(),
    typeLabel: isReal
      ? pageText[lang].realUser
      : pageText[lang].demoUser,
    isReal,
    lastMessageText: item.lastMessage || pageText[lang].noMessage,
    lastTimeText: formatTime(item.lastMessageAt || item.updatedAt || item.createdAt),
    selected: false,
    blocked: item.blocked || false
  })
}

function normalizeMessage(item, openid) {
  const senderOpenid = item.senderOpenid || item.fromOpenid || ''
  const isMine = senderOpenid === openid

  return Object.assign({}, item, {
    id: item._id || item.id,
    isMine,
    timeText: formatTime(item.createdAt || item.sentAt),
    content: item.content || ''
  })
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    openid: '',
    conversations: [],
    currentConversation: null,
    messages: [],

    inputValue: '',
    loadingConversations: false,
    loadingMessages: false,
    sending: false,

    actionPanelOpen: false,
    blockStatus: {
      blocked: false,
      blockedByMe: false,
      blockedByOther: false
    },

    scrollIntoView: ''
  },

  onLoad() {
    this.initPage()
  },

  onShow() {
    this.initPage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  initPage() {
    if (!this.guardLogin()) {
      return
    }

    const lang = getCurrentLang()
    const text = pageText[lang]
    const openid = getCurrentOpenid()

    this.setData({
      lang,
      text,
      openid
    })

    this.loadConversations()
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = getCurrentOpenid()

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    const text = pageText[nextLang]

    const conversations = this.data.conversations.map(item => {
      return normalizeConversation(item, this.data.openid, nextLang)
    })

    this.setData({
      lang: nextLang,
      text,
      conversations
    })
  },

  loadConversations() {
    if (!wx.cloud || !wx.cloud.callFunction) {
      wx.showToast({
        title: this.data.text.networkError,
        icon: 'none'
      })
      return
    }

    this.setData({
      loadingConversations: true
    })

    wx.cloud.callFunction({
      name: 'getConversations',
      data: {},
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          this.setData({
            conversations: [],
            currentConversation: null,
            messages: []
          })
          return
        }

        const rawList = result.conversations || result.data || []
        const conversations = rawList
          .map(item => normalizeConversation(item, this.data.openid, this.data.lang))
          .sort((a, b) => {
            const aTime = new Date(a.lastMessageAt || a.updatedAt || a.createdAt || 0).getTime()
            const bTime = new Date(b.lastMessageAt || b.updatedAt || b.createdAt || 0).getTime()
            return bTime - aTime
          })

        let current = this.data.currentConversation

        if (current) {
          const found = conversations.find(item => item.conversationId === current.conversationId)
          current = found || conversations[0] || null
        } else {
          current = conversations[0] || null
        }

        const finalList = conversations.map(item => {
          return Object.assign({}, item, {
            selected: current && item.conversationId === current.conversationId
          })
        })

        this.setData({
          conversations: finalList,
          currentConversation: current || null,
          actionPanelOpen: false
        })

        if (current) {
          this.loadMessages(current.conversationId)
          this.loadBlockStatus(current.conversationId)
        } else {
          this.setData({
            messages: []
          })
        }
      },
      fail: (err) => {
        console.error('getConversations failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loadingConversations: false
        })
      }
    })
  },

  selectConversation(e) {
    const conversationId = e.currentTarget.dataset.id
    const current = this.data.conversations.find(item => item.conversationId === conversationId)

    if (!current) return

    const conversations = this.data.conversations.map(item => {
      return Object.assign({}, item, {
        selected: item.conversationId === conversationId
      })
    })

    this.setData({
      conversations,
      currentConversation: current,
      actionPanelOpen: false,
      inputValue: ''
    })

    this.loadMessages(conversationId)
    this.loadBlockStatus(conversationId)
  },

  loadMessages(conversationId) {
    if (!conversationId) return

    this.setData({
      loadingMessages: true
    })

    wx.cloud.callFunction({
      name: 'getMessages',
      data: {
        conversationId
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          this.setData({
            messages: []
          })
          return
        }

        const rawMessages = result.messages || result.data || []
        const messages = rawMessages.map(item => normalizeMessage(item, this.data.openid))

        this.setData({
          messages,
          scrollIntoView: messages.length ? `msg-${messages[messages.length - 1].id}` : ''
        })
      },
      fail: (err) => {
        console.error('getMessages failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loadingMessages: false
        })
      }
    })
  },

  loadBlockStatus(conversationId) {
    if (!conversationId || !wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getBlockStatus',
      data: {
        conversationId
      },
      success: (res) => {
        const result = res.result || {}

        this.setData({
          blockStatus: {
            blocked: !!result.blocked,
            blockedByMe: !!result.blockedByMe,
            blockedByOther: !!result.blockedByOther,
            blockId: result.blockId || ''
          }
        })
      },
      fail: () => {
        this.setData({
          blockStatus: {
            blocked: false,
            blockedByMe: false,
            blockedByOther: false
          }
        })
      }
    })
  },

  onInput(e) {
    this.setData({
      inputValue: e.detail.value
    })
  },

  sendMessage() {
    if (this.data.sending) return

    const current = this.data.currentConversation

    if (!current) return

    if (this.data.blockStatus.blocked) {
      wx.showToast({
        title: this.data.text.blockedPlaceholder,
        icon: 'none'
      })
      return
    }

    const content = String(this.data.inputValue || '').trim()

    if (!content) {
      wx.showToast({
        title: this.data.text.sendEmpty,
        icon: 'none'
      })
      return
    }

    this.setData({
      sending: true
    })

    wx.cloud.callFunction({
      name: 'sendMessage',
      data: {
        conversationId: current.conversationId,
        content
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.sendFailed,
            icon: 'none'
          })
          return
        }

        this.setData({
          inputValue: ''
        })

        this.loadMessages(current.conversationId)
        this.loadConversations()
      },
      fail: (err) => {
        console.error('sendMessage failed:', err)
        wx.showToast({
          title: this.data.text.sendFailed,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          sending: false
        })
      }
    })
  },

  useQuickText(e) {
    const text = e.currentTarget.dataset.text || ''

    this.setData({
      inputValue: text
    })
  },

  copyQuestion(e) {
    const text = e.currentTarget.dataset.text || ''

    wx.setClipboardData({
      data: text,
      success: () => {
        wx.showToast({
          title: this.data.text.copied,
          icon: 'success'
        })
      }
    })
  },

  toggleActionPanel() {
    this.setData({
      actionPanelOpen: !this.data.actionPanelOpen
    })
  },

  refreshMessages() {
    if (!this.data.currentConversation) {
      this.loadConversations()
      return
    }

    this.loadMessages(this.data.currentConversation.conversationId)
    this.loadConversations()
  },

  goMatches() {
    wx.switchTab({
      url: '/pages/matches/matches'
    })
  },

  goAgreement() {
    const current = this.data.currentConversation

    if (!current) return

    const id = current.targetId || current.conversationId
    const mode = current.isReal ? 'real' : 'demo'

    wx.navigateTo({
      url: `/pages/agreement/agreement?id=${id}&mode=${mode}`
    })
  },

  reportConversation() {
    const current = this.data.currentConversation

    if (!current) return

    wx.showModal({
      title: this.data.text.report,
      content: this.data.lang === 'zh'
        ? '确认举报这段沟通吗？'
        : 'Report this conversation?',
      success: (res) => {
        if (!res.confirm) return

        wx.cloud.callFunction({
          name: 'reportContent',
          data: {
            targetType: 'conversation',
            targetId: current.conversationId,
            reason: 'chat_safety',
            description: 'Reported from chat page.'
          },
          success: (resultRes) => {
            const result = resultRes.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || this.data.text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: this.data.text.reportSuccess,
              icon: 'success'
            })
          },
          fail: (err) => {
            console.error('reportContent failed:', err)
            wx.showToast({
              title: this.data.text.networkError,
              icon: 'none'
            })
          }
        })
      }
    })
  },

  blockConversation() {
    const current = this.data.currentConversation

    if (!current) return

    wx.showModal({
      title: this.data.text.block,
      content: this.data.lang === 'zh'
        ? '拉黑后，你将无法继续向对方发送消息。'
        : 'After blocking, you cannot continue sending messages to this user.',
      success: (res) => {
        if (!res.confirm) return

        wx.cloud.callFunction({
          name: 'blockUser',
          data: {
            conversationId: current.conversationId,
            targetOpenid: current.targetId
          },
          success: (resultRes) => {
            const result = resultRes.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || this.data.text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: this.data.text.blockSuccess,
              icon: 'success'
            })

            this.loadBlockStatus(current.conversationId)
            this.loadConversations()
          },
          fail: (err) => {
            console.error('blockUser failed:', err)
            wx.showToast({
              title: this.data.text.networkError,
              icon: 'none'
            })
          }
        })
      }
    })
  },

  unblockConversation() {
    const current = this.data.currentConversation

    if (!current) return

    wx.cloud.callFunction({
      name: 'unblockUser',
      data: {
        conversationId: current.conversationId,
        blockId: this.data.blockStatus.blockId || '',
        targetOpenid: current.targetId
      },
      success: (resultRes) => {
        const result = resultRes.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        wx.showToast({
          title: this.data.text.unblockSuccess,
          icon: 'success'
        })

        this.loadBlockStatus(current.conversationId)
        this.loadConversations()
      },
      fail: (err) => {
        console.error('unblockUser failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      }
    })
  },

  deleteConversation() {
    const current = this.data.currentConversation

    if (!current) return

    wx.showModal({
      title: this.data.text.deleteConfirmTitle,
      content: this.data.text.deleteConfirmContent,
      success: (res) => {
        if (!res.confirm) return

        wx.cloud.callFunction({
          name: 'deleteConversationForMe',
          data: {
            conversationId: current.conversationId
          },
          success: (resultRes) => {
            const result = resultRes.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || this.data.text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: this.data.text.deleteSuccess,
              icon: 'success'
            })

            this.setData({
              currentConversation: null,
              messages: [],
              inputValue: '',
              actionPanelOpen: false
            })

            this.loadConversations()
          },
          fail: (err) => {
            console.error('deleteConversationForMe failed:', err)

            wx.showToast({
              title: this.data.text.networkError,
              icon: 'none'
            })
          }
        })
      }
    })
  }
})