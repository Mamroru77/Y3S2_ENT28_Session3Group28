Page({
  data: {},

  onShow() {
    const app = getApp()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  }
})