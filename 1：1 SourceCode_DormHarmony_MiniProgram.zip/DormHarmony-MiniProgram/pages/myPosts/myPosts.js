const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '我的内容',
    title: '我的帖子',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '这里可以管理你发布过的 DormTalk 帖子。建议只保留对他人有帮助、表达清晰的内容。',

    empty: '你还没有发布过帖子。',
    refresh: '刷新',
    view: '查看',
    edit: '编辑',
    delete: '删除',
    save: '保存修改',
    cancel: '取消编辑',
    loadMore: '加载更多',
    noMore: '没有更多了',

    titleLabel: '标题',
    contentLabel: '内容',
    categoryLabel: '分类',

    titleEmpty: '请输入标题',
    contentEmpty: '请输入内容',
    updateSuccess: '修改成功',
    deleteTitle: '确认删除？',
    deleteContent: '删除后该帖子将不再出现在社区中。',
    deleteSuccess: '已删除',
    networkError: '网络或云函数异常'
  },

  en: {
    eyebrow: 'My Content',
    title: 'My Posts',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'You can manage your DormTalk posts here. Keep content useful, clear and respectful.',

    empty: 'You have not published any posts yet.',
    refresh: 'Refresh',
    view: 'View',
    edit: 'Edit',
    delete: 'Delete',
    save: 'Save Changes',
    cancel: 'Cancel',
    loadMore: 'Load More',
    noMore: 'No more posts',

    titleLabel: 'Title',
    contentLabel: 'Content',
    categoryLabel: 'Category',

    titleEmpty: 'Please enter a title',
    contentEmpty: 'Please enter content',
    updateSuccess: 'Updated',
    deleteTitle: 'Confirm delete?',
    deleteContent: 'After deletion, this post will no longer appear in the community.',
    deleteSuccess: 'Deleted',
    networkError: 'Network or cloud function error'
  }
}

const categories = [
  { key: 'boundary', zh: '边界', en: 'Boundaries' },
  { key: 'schedule', zh: '作息', en: 'Schedule' },
  { key: 'cleanliness', zh: '卫生', en: 'Cleanliness' },
  { key: 'visitor', zh: '访客', en: 'Visitors' },
  { key: 'mbti', zh: 'MBTI', en: 'MBTI' },
  { key: 'rent', zh: '合租', en: 'Renting' }
]

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value.$date) {
    date = new Date(value.$date)
  }

  if (!date || isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

function getCategoryLabel(category, lang) {
  const found = categories.find(item => item.key === category)
  if (!found) return category || 'general'
  return lang === 'zh' ? found.zh : found.en
}

function buildCategoryOptions(lang, activeCategory) {
  return categories.map(item => {
    return {
      key: item.key,
      label: lang === 'zh' ? item.zh : item.en,
      active: item.key === activeCategory
    }
  })
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    posts: [],
    total: 0,
    page: 0,
    pageSize: 10,
    hasMore: false,

    loading: false,
    loadingMore: false,
    updating: false,
    deleting: false,

    editingPostId: '',
    editTitle: '',
    editContent: '',
    editCategory: 'boundary',
    categoryOptions: []
  },

  onLoad() {
    this.refreshLanguage()

    if (!this.guardLogin()) {
      return
    }

    this.loadPosts(true)
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }

    if (!this.guardLogin()) {
      return
    }

    this.loadPosts(true)
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  refreshLanguage() {
    const lang = getCurrentLang()

    this.setData({
      lang,
      text: pageText[lang],
      posts: this.decoratePosts(this.data.posts, lang),
      categoryOptions: buildCategoryOptions(lang, this.data.editCategory)
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'
    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.setData({
      lang: nextLang,
      text: pageText[nextLang],
      posts: this.decoratePosts(this.data.posts, nextLang),
      categoryOptions: buildCategoryOptions(nextLang, this.data.editCategory)
    })
  },

  decoratePosts(posts, langValue) {
    const lang = langValue || this.data.lang

    return (posts || []).map(item => {
      return Object.assign({}, item, {
        displayCategory: getCategoryLabel(item.category, lang),
        displayTime: formatTime(item.createdAt),
        displayUpdatedTime: formatTime(item.updatedAt),
        safeLikeCount: Number(item.likeCount || 0),
        safeCommentCount: Number(item.commentCount || 0)
      })
    })
  },

  loadPosts(reset) {
    if (!wx.cloud || !wx.cloud.callFunction) return
    if (this.data.loading || this.data.loadingMore) return

    const isReset = reset !== false
    const nextPage = isReset ? 0 : this.data.page + 1

    this.setData({
      loading: isReset,
      loadingMore: !isReset
    })

    wx.cloud.callFunction({
      name: 'getMyPosts',
      data: {
        page: nextPage,
        pageSize: this.data.pageSize
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        const newPosts = this.decoratePosts(result.posts || [])
        const posts = isReset ? newPosts : this.data.posts.concat(newPosts)

        this.setData({
          posts,
          page: result.page || nextPage,
          total: result.total || 0,
          hasMore: !!result.hasMore
        })
      },
      fail: (err) => {
        console.error('getMyPosts failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loading: false,
          loadingMore: false
        })
      }
    })
  },

  loadMorePosts() {
    if (!this.guardLogin()) return
    if (!this.data.hasMore) return

    this.loadPosts(false)
  },

  viewPost(e) {
    if (!this.guardLogin()) return

    const postId = e.currentTarget.dataset.id

    if (!postId) return

    wx.navigateTo({
      url: `/pages/postDetail/postDetail?id=${postId}`
    })
  },

  startEdit(e) {
    if (!this.guardLogin()) return

    const postId = e.currentTarget.dataset.id
    const post = this.data.posts.find(item => item._id === postId)

    if (!post) return

    this.setData({
      editingPostId: post._id,
      editTitle: post.title,
      editContent: post.content,
      editCategory: post.category || 'boundary',
      categoryOptions: buildCategoryOptions(this.data.lang, post.category || 'boundary')
    })
  },

  cancelEdit() {
    this.setData({
      editingPostId: '',
      editTitle: '',
      editContent: '',
      editCategory: 'boundary',
      categoryOptions: buildCategoryOptions(this.data.lang, 'boundary')
    })
  },

  onEditTitleInput(e) {
    this.setData({
      editTitle: e.detail.value
    })
  },

  onEditContentInput(e) {
    this.setData({
      editContent: e.detail.value
    })
  },

  chooseEditCategory(e) {
    const category = e.currentTarget.dataset.category || 'boundary'

    this.setData({
      editCategory: category,
      categoryOptions: buildCategoryOptions(this.data.lang, category)
    })
  },

  saveEdit() {
    if (!this.guardLogin()) return

    const text = this.data.text
    const postId = this.data.editingPostId
    const title = String(this.data.editTitle || '').trim()
    const content = String(this.data.editContent || '').trim()

    if (!postId) return

    if (!title) {
      wx.showToast({
        title: text.titleEmpty,
        icon: 'none'
      })
      return
    }

    if (!content) {
      wx.showToast({
        title: text.contentEmpty,
        icon: 'none'
      })
      return
    }

    this.setData({
      updating: true
    })

    wx.cloud.callFunction({
      name: 'updatePost',
      data: {
        postId,
        title,
        content,
        category: this.data.editCategory
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || text.networkError,
            icon: 'none'
          })
          return
        }

        wx.showToast({
          title: text.updateSuccess,
          icon: 'success'
        })

        this.cancelEdit()
        this.loadPosts(true)
      },
      fail: (err) => {
        console.error('updatePost failed:', err)
        wx.showToast({
          title: text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          updating: false
        })
      }
    })
  },

  deletePost(e) {
    if (!this.guardLogin()) return

    const postId = e.currentTarget.dataset.id
    const text = this.data.text

    if (!postId) return

    wx.showModal({
      title: text.deleteTitle,
      content: text.deleteContent,
      confirmColor: '#c95645',
      success: (modalRes) => {
        if (!modalRes.confirm) return

        this.setData({
          deleting: true
        })

        wx.cloud.callFunction({
          name: 'deletePost',
          data: {
            postId
          },
          success: (res) => {
            const result = res.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: text.deleteSuccess,
              icon: 'success'
            })

            this.loadPosts(true)
          },
          fail: (err) => {
            console.error('deletePost failed:', err)
            wx.showToast({
              title: text.networkError,
              icon: 'none'
            })
          },
          complete: () => {
            this.setData({
              deleting: false
            })
          }
        })
      }
    })
  }
})