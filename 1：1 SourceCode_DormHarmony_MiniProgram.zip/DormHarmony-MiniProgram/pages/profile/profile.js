const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '个人中心',
    title: '我的',
    languageButton: 'EN',

    profileId: 'Profile ID',
    reputation: '信誉分',
    completed: '资料完整',
    incomplete: '资料待完善',
    livingType: '住宿场景',
    gender: '性别',
    year: '年级',
    campus: '校区',
    school: '学院',
    programme: '专业',

    schoolDorm: '学校宿舍',
    offCampus: '校外合租',
    male: '男',
    female: '女',
    preferNotSay: '暂不说明',
    unknown: '未设置',

    quickActions: '常用功能',
    editProfile: '编辑基础资料',
    questionnaire: '生活习惯问卷',
    boundaryCard: '我的边界卡',
    myPosts: '我的帖子',

    safetyAndAccount: '安全与账号',
    safetyCenter: '安全中心',
    refreshProfile: '刷新资料',
    logout: '退出登录',

    dataOverview: '数据概览',
    posts: '帖子',
    comments: '评论',
    reports: '安全记录',

    bearName: '哈米熊',
    bearSpeech: '这里是你的 DormHarmony 个人中枢。资料越完整，真实匹配、边界卡和合住协议会越准确。',

    logoutTitle: '确认退出登录？',
    logoutContent: '退出后需要重新微信登录才能继续使用。',
    confirm: '确认',
    cancel: '取消',
    refreshed: '已刷新',
    networkError: '网络异常，请稍后再试'
  },

  en: {
    eyebrow: 'Profile Center',
    title: 'Me',
    languageButton: '中文',

    profileId: 'Profile ID',
    reputation: 'Reputation',
    completed: 'Profile Complete',
    incomplete: 'Profile Incomplete',
    livingType: 'Living Scenario',
    gender: 'Gender',
    year: 'Year',
    campus: 'Campus',
    school: 'School',
    programme: 'Programme',

    schoolDorm: 'School dorm',
    offCampus: 'Off-campus housing',
    male: 'Male',
    female: 'Female',
    preferNotSay: 'Prefer not to say',
    unknown: 'Not set',

    quickActions: 'Quick Actions',
    editProfile: 'Edit Basic Profile',
    questionnaire: 'Lifestyle Questionnaire',
    boundaryCard: 'My Boundary Card',
    myPosts: 'My Posts',

    safetyAndAccount: 'Safety & Account',
    safetyCenter: 'Safety Center',
    refreshProfile: 'Refresh Profile',
    logout: 'Log Out',

    dataOverview: 'Data Overview',
    posts: 'Posts',
    comments: 'Comments',
    reports: 'Safety Records',

    bearName: 'Harmony Bear',
    bearSpeech: 'This is your DormHarmony profile hub. A more complete profile improves real matching, boundary cards and roommate agreements.',

    logoutTitle: 'Log out?',
    logoutContent: 'You will need to log in again with WeChat to continue.',
    confirm: 'Confirm',
    cancel: 'Cancel',
    refreshed: 'Refreshed',
    networkError: 'Network error. Please try again later.'
  }
}

function getProfileId(user) {
  if (!user) return ''

  return (
    user.profileId ||
    user.dormProfileId ||
    user.studentProfileId ||
    user.publicProfileId ||
    ''
  )
}

function getGenderText(gender, text) {
  if (gender === 'male') return text.male
  if (gender === 'female') return text.female
  if (gender === 'prefer_not_to_say') return text.preferNotSay
  return text.unknown
}

function getLivingTypeText(livingType, text) {
  if (livingType === 'school_dorm') return text.schoolDorm
  if (livingType === 'off_campus') return text.offCampus
  return text.unknown
}

function shortSchoolName(school) {
  const value = String(school || '')

  const map = [
    ['International Business School Suzhou', 'IBSS'],
    ['School of Advanced Technology', 'SAT'],
    ['School of Intelligent Finance and Business', 'SIFB'],
    ['School of Intelligent Manufacturing Ecosystem', 'SIME'],
    ['School of AI and Advanced Computing', 'AI & Advanced Computing'],
    ['School of Internet of Things', 'IoT'],
    ['School of Humanities and Social Sciences', 'HSS'],
    ['School of Mathematics and Physics', 'Maths & Physics'],
    ['Academy of Film and Creative Technology', 'AFCT'],
    ['XJTLU Wisdom Lake Academy of Pharmacy', 'Wisdom Lake Pharmacy']
  ]

  const found = map.find(item => value.indexOf(item[0]) > -1)

  return found ? found[1] : value
}

function shortProgrammeName(programme, programmeCode) {
  const value = String(programme || '')
  const code = String(programmeCode || '')

  const codeMap = {
    INTELLIGENT_SUPPLY_CHAIN_CE: 'Intelligent Supply Chain',
    INTELLIGENT_MANUFACTURING_ENGINEERING_CE: 'Intelligent Manufacturing',
    INTERNET_OF_THINGS_ENGINEERING_CE: 'IoT Engineering',
    INTELLIGENT_ROBOTICS_ENGINEERING_CE: 'Intelligent Robotics',
    MICROELECTRONIC_SCIENCE_ENGINEERING_CE: 'Microelectronic Science',
    DATA_SCIENCE_BIG_DATA_CE: 'Data Science & Big Data',
    ARTIFICIAL_INTELLIGENCE_TC: 'Artificial Intelligence',
    ARTIFICIAL_INTELLIGENCE_SIP: 'Artificial Intelligence',
    BUSINESS_ADMINISTRATION: 'Business Administration',
    ECONOMICS_FINANCE: 'Economics & Finance',
    DIGITAL_INTELLIGENT_MARKETING: 'Digital & Intelligent Marketing',
    HRM_PEOPLE_ANALYTICS: 'HRM & People Analytics',
    INTERNATIONAL_BUSINESS_LANGUAGE: 'International Business',
    COMPUTER_SCIENCE_TECHNOLOGY: 'Computer Science',
    DIGITAL_MEDIA_TECHNOLOGY: 'Digital Media Technology',
    MECHATRONICS_ROBOTIC_SYSTEMS: 'Mechatronics & Robotics',
    TELECOMMUNICATIONS_ENGINEERING: 'Telecommunications',
    MATERIALS_SCIENCE_ENGINEERING: 'Materials Science',
    MEDIA_COMMUNICATION_STUDIES: 'Media & Communication',
    TRANSLATION_INTERPRETING: 'Translation & Interpreting',
    FINANCIAL_MATHEMATICS: 'Financial Mathematics',
    ACTUARIAL_SCIENCE: 'Actuarial Science'
  }

  if (codeMap[code]) return codeMap[code]

  return value
    .replace(' with Contemporary Entrepreneurialism', '')
    .replace(' BSc (Hons)', '')
    .replace(' BEng (Hons)', '')
    .replace(' BA (Hons)', '')
    .replace(' / Pharmacy-related programme', '')
}

function getProfileProgress(user) {
  if (!user) return 0

  const fields = [
    user.nickname,
    user.gender,
    user.livingType,
    user.year,
    user.campusCode || user.campus,
    user.schoolCode || user.school,
    user.programmeCode || user.programme || user.major,
    user.mbti
  ]

  const done = fields.filter(item => !!item).length

  return Math.round((done / fields.length) * 100)
}

function normalizeUser(user, text) {
  if (!user) {
    return {
      nickname: 'DormHarmony User',
      avatarText: 'D',
      profileId: '',
      profileCompleted: false,
      progress: 0,
      progressStyle: 'width: 0%;',
      reputationScore: 100,
      livingTypeText: text.unknown,
      genderText: text.unknown,
      yearText: text.unknown,
      campusText: text.unknown,
      schoolText: text.unknown,
      schoolShortText: text.unknown,
      programmeText: text.unknown,
      programmeShortText: text.unknown
    }
  }

  const progress = getProfileProgress(user)
  const programmeText = user.programme || user.major || text.unknown
  const schoolText = user.school || text.unknown

  return {
    ...user,
    nickname: user.nickname || 'DormHarmony User',
    avatarText: user.avatarText || String(user.nickname || 'D').slice(0, 1).toUpperCase(),
    profileId: getProfileId(user),
    profileCompleted: !!user.profileCompleted,
    progress,
    progressStyle: `width: ${progress}%;`,
    reputationScore: Number(user.reputationScore || 100),

    livingTypeText: getLivingTypeText(user.livingType, text),
    genderText: getGenderText(user.gender, text),

    yearText: user.year || text.unknown,
    campusText: user.campus || text.unknown,

    schoolText,
    schoolShortText: shortSchoolName(schoolText),

    programmeText,
    programmeShortText: shortProgrammeName(programmeText, user.programmeCode)
  }
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    user: null,
    normalizedUser: null,

    stats: {
      posts: 0,
      comments: 0,
      reports: 0
    },

    loading: false
  },

  onLoad() {
    this.initPage()
  },

  onShow() {
    this.initPage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  initPage() {
    const lang = getCurrentLang()
    const text = pageText[lang]
    const cachedUser = wx.getStorageSync('dh_current_user') || null

    this.setData({
      lang,
      text,
      user: cachedUser,
      normalizedUser: normalizeUser(cachedUser, text)
    })

    if (!this.guardLogin()) {
      return
    }

    this.loadCurrentUser()
    this.loadDashboardStats()
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    const text = pageText[nextLang]

    this.setData({
      lang: nextLang,
      text,
      normalizedUser: normalizeUser(this.data.user, text)
    })
  },

  loadCurrentUser() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    this.setData({
      loading: true
    })

    wx.cloud.callFunction({
      name: 'getCurrentUser',
      success: (res) => {
        const result = res.result || {}
        const user = result.user || null

        if (!user) return

        wx.setStorageSync('dh_current_user', user)

        this.setData({
          user,
          normalizedUser: normalizeUser(user, this.data.text)
        })

        if (auth.updateUser) {
          auth.updateUser(user)
        } else if (app.setUserProfile) {
          app.setUserProfile(user)
        }
      },
      fail: (err) => {
        console.warn('profile getCurrentUser failed:', err)
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  loadDashboardStats() {
    this.loadMyPostsCount()
    this.loadSafetyCount()
  },

  loadMyPostsCount() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getMyPosts',
      data: {
        limit: 50
      },
      success: (res) => {
        const result = res.result || {}
        const posts = result.posts || result.data || []

        if (!Array.isArray(posts)) return

        this.setData({
          'stats.posts': posts.length
        })
      },
      fail: () => {}
    })
  },

  loadSafetyCount() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getSafetyCenter',
      data: {},
      success: (res) => {
        const result = res.result || {}

        const reports = Array.isArray(result.reports)
          ? result.reports.length
          : Array.isArray(result.myReports)
            ? result.myReports.length
            : 0

        this.setData({
          'stats.reports': reports
        })
      },
      fail: () => {}
    })
  },

  refreshProfile() {
    this.loadCurrentUser()
    this.loadDashboardStats()

    wx.showToast({
      title: this.data.text.refreshed,
      icon: 'success'
    })
  },

  goProfileSetup() {
    wx.navigateTo({
      url: '/pages/profileSetup/profileSetup'
    })
  },

  goQuestionnaire() {
    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  },

  goBoundaryCard() {
    wx.navigateTo({
      url: '/pages/boundaryCard/boundaryCard'
    })
  },

  goMyPosts() {
    wx.navigateTo({
      url: '/pages/myPosts/myPosts'
    })
  },

  goSafetyCenter() {
    wx.navigateTo({
      url: '/pages/safetyCenter/safetyCenter'
    })
  },

  logout() {
    wx.showModal({
      title: this.data.text.logoutTitle,
      content: this.data.text.logoutContent,
      confirmText: this.data.text.confirm,
      cancelText: this.data.text.cancel,
      success: (res) => {
        if (!res.confirm) return

        wx.removeStorageSync('dh_openid')
        wx.removeStorageSync('dh_current_user')
        wx.removeStorageSync('dh_selected_real_match')
        wx.removeStorageSync('dh_real_matches_cache')
        wx.removeStorageSync('dh_questionnaire')

        if (app.setOpenid) {
          app.setOpenid('')
        }

        if (app.setUserProfile) {
          app.setUserProfile(null)
        }

        wx.reLaunch({
          url: '/pages/login/login'
        })
      }
    })
  }
})