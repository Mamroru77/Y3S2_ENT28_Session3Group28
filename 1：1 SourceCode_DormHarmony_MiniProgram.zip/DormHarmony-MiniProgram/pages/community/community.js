const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: 'DormTalk 社区',
    title: '校园合住讨论区',
    subtitle: '围绕作息、卫生、访客、MBTI、边界和合租经验进行讨论。',

    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '这里适合讨论合住边界和生活习惯，不建议发布联系方式、私人信息或攻击性内容。',

    categoriesTitle: '话题分类',
    searchTitle: '搜索与排序',
    latestTitle: '搜索结果',
    createTitle: '发布新话题',

    searchPlaceholder: '搜索标题、内容、分类或作者……',
    searchButton: '搜索',
    clearSearch: '清空',
    sortTitle: '排序方式',
    searchResultCount: '当前结果',
    loadMore: '加载更多',
    noMore: '没有更多了',
    manageMyPosts: '管理我的帖子',

    titleLabel: '标题',
    titlePlaceholder: '例如：朋友来宿舍，是否一定要提前说？',
    contentLabel: '内容',
    contentPlaceholder: '写下你的具体情况、观点或想讨论的问题……',

    publish: '发布话题',
    refresh: '刷新',
    viewDetail: '查看详情',
    like: '点赞',
    liked: '已点赞',

    reportPost: '举报帖子',
    reportTitle: '确认举报？',
    reportPostContent: '举报后该帖子会被记录到安全系统中，用于后续审核。',
    reportSuccess: '举报已提交',

    emptyPost: '暂无帖子。你可以发布第一个 DormTalk 话题。',
    emptySearch: '没有找到符合条件的帖子。可以换一个关键词或切换分类。',
    loading: '加载中...',
    postSuccess: '发布成功',
    titleEmpty: '请输入标题',
    contentEmpty: '请输入内容',
    networkError: '网络或云函数异常'
  },

  en: {
    eyebrow: 'DormTalk Community',
    title: 'Shared-living Discussion',
    subtitle: 'Discuss sleep schedule, cleanliness, visitors, MBTI, boundaries and roommate experience.',

    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'This space is for living-boundary discussions. Avoid sharing contact details, private information or aggressive content.',

    categoriesTitle: 'Categories',
    searchTitle: 'Search & Sort',
    latestTitle: 'Search Results',
    createTitle: 'Create a Topic',

    searchPlaceholder: 'Search title, content, category or author...',
    searchButton: 'Search',
    clearSearch: 'Clear',
    sortTitle: 'Sort by',
    searchResultCount: 'Results',
    loadMore: 'Load More',
    noMore: 'No more posts',
    manageMyPosts: 'Manage My Posts',

    titleLabel: 'Title',
    titlePlaceholder: 'e.g. Should visitors always be announced in advance?',
    contentLabel: 'Content',
    contentPlaceholder: 'Write your situation, opinion or question...',

    publish: 'Publish',
    refresh: 'Refresh',
    viewDetail: 'View Detail',
    like: 'Like',
    liked: 'Liked',

    reportPost: 'Report Post',
    reportTitle: 'Confirm report?',
    reportPostContent: 'This post will be recorded in the safety system for review.',
    reportSuccess: 'Report submitted',

    emptyPost: 'No posts yet. You can create the first DormTalk topic.',
    emptySearch: 'No matching posts found. Try another keyword or category.',
    loading: 'Loading...',
    postSuccess: 'Published',
    titleEmpty: 'Please enter a title',
    contentEmpty: 'Please enter content',
    networkError: 'Network or cloud function error'
  }
}

const categories = [
  { key: 'all', zh: '全部', en: 'All' },
  { key: 'boundary', zh: '边界', en: 'Boundaries' },
  { key: 'schedule', zh: '作息', en: 'Schedule' },
  { key: 'cleanliness', zh: '卫生', en: 'Cleanliness' },
  { key: 'visitor', zh: '访客', en: 'Visitors' },
  { key: 'mbti', zh: 'MBTI', en: 'MBTI' },
  { key: 'rent', zh: '合租', en: 'Renting' }
]

const sortModes = [
  { key: 'latest', zh: '最新', en: 'Latest' },
  { key: 'hot', zh: '最热门', en: 'Most Liked' },
  { key: 'discussed', zh: '评论最多', en: 'Most Discussed' }
]

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value.$date) {
    date = new Date(value.$date)
  }

  if (!date || isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

function buildCategories(lang, activeCategory) {
  return categories.map(item => {
    return {
      key: item.key,
      label: lang === 'zh' ? item.zh : item.en,
      active: item.key === activeCategory
    }
  })
}

function buildSortOptions(lang, activeSort) {
  return sortModes.map(item => {
    return {
      key: item.key,
      label: lang === 'zh' ? item.zh : item.en,
      active: item.key === activeSort
    }
  })
}

function getCategoryLabel(categoryKey, lang) {
  const found = categories.find(item => item.key === categoryKey)

  if (!found) return categoryKey || 'general'

  return lang === 'zh' ? found.zh : found.en
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    categories: [],
    activeCategory: 'all',

    sortOptions: [],
    sortMode: 'latest',
    searchKeyword: '',

    posts: [],
    total: 0,
    page: 0,
    pageSize: 10,
    hasMore: false,

    newPostTitle: '',
    newPostContent: '',
    newPostCategory: 'boundary',

    loadingPosts: false,
    loadingMore: false,
    submittingPost: false,
    reporting: false
  },

  onLoad() {
    this.refreshLanguage()

    if (!this.guardProfileCompleted()) {
      return
    }

    this.loadPosts(true)
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }

    if (!this.guardProfileCompleted()) {
      return
    }

    this.loadPosts(true)
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  refreshLanguage() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    this.setData({
      lang,
      text,
      categories: buildCategories(lang, this.data.activeCategory),
      sortOptions: buildSortOptions(lang, this.data.sortMode),
      posts: this.decoratePosts(this.data.posts, lang)
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'
    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.setData({
      lang: nextLang,
      text: pageText[nextLang],
      categories: buildCategories(nextLang, this.data.activeCategory),
      sortOptions: buildSortOptions(nextLang, this.data.sortMode),
      posts: this.decoratePosts(this.data.posts, nextLang)
    })
  },

  decoratePosts(posts, langValue) {
    const lang = langValue || this.data.lang

    return (posts || []).map(item => {
      return Object.assign({}, item, {
        displayCategory: getCategoryLabel(item.category, lang),
        displayTime: formatTime(item.createdAt),
        displayUpdatedTime: formatTime(item.updatedAt),
        safeLikeCount: Number(item.likeCount || 0),
        safeCommentCount: Number(item.commentCount || 0)
      })
    })
  },

  selectCategory(e) {
    if (!this.guardProfileCompleted()) return

    const category = e.currentTarget.dataset.category || 'all'

    this.setData({
      activeCategory: category,
      categories: buildCategories(this.data.lang, category),
      page: 0
    })

    this.loadPosts(true)
  },

  onSearchInput(e) {
    this.setData({
      searchKeyword: e.detail.value
    })
  },

  submitSearch() {
    if (!this.guardProfileCompleted()) return

    this.setData({
      page: 0
    })

    this.loadPosts(true)
  },

  clearSearch() {
    if (!this.guardProfileCompleted()) return

    this.setData({
      searchKeyword: '',
      page: 0
    })

    this.loadPosts(true)
  },

  chooseSort(e) {
    if (!this.guardProfileCompleted()) return

    const sortMode = e.currentTarget.dataset.sort || 'latest'

    this.setData({
      sortMode,
      sortOptions: buildSortOptions(this.data.lang, sortMode),
      page: 0
    })

    this.loadPosts(true)
  },

  onPostTitleInput(e) {
    this.setData({
      newPostTitle: e.detail.value
    })
  },

  onPostContentInput(e) {
    this.setData({
      newPostContent: e.detail.value
    })
  },

  choosePostCategory(e) {
    const category = e.currentTarget.dataset.category || 'boundary'

    this.setData({
      newPostCategory: category
    })
  },

  refreshPosts() {
    if (!this.guardProfileCompleted()) return
    this.loadPosts(true)
  },

  loadPosts(reset) {
    if (!wx.cloud || !wx.cloud.callFunction) return

    if (this.data.loadingPosts || this.data.loadingMore) return

    const isReset = reset !== false
    const nextPage = isReset ? 0 : this.data.page + 1

    this.setData({
      loadingPosts: isReset,
      loadingMore: !isReset
    })

    wx.cloud.callFunction({
      name: 'getPosts',
      data: {
        category: this.data.activeCategory,
        keyword: this.data.searchKeyword,
        sortMode: this.data.sortMode,
        page: nextPage,
        pageSize: this.data.pageSize
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        const newPosts = this.decoratePosts(result.posts || [])
        const posts = isReset ? newPosts : this.data.posts.concat(newPosts)

        this.setData({
          posts,
          page: Number(result.page || nextPage),
          total: Number(result.total || 0),
          hasMore: !!result.hasMore
        })
      },
      fail: (err) => {
        console.error('getPosts failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loadingPosts: false,
          loadingMore: false
        })
      }
    })
  },

  loadMorePosts() {
    if (!this.guardProfileCompleted()) return
    if (!this.data.hasMore) return

    this.loadPosts(false)
  },

  publishPost() {
    if (!this.guardProfileCompleted()) return

    const text = this.data.text
    const title = String(this.data.newPostTitle || '').trim()
    const content = String(this.data.newPostContent || '').trim()

    if (!title) {
      wx.showToast({
        title: text.titleEmpty,
        icon: 'none'
      })
      return
    }

    if (!content) {
      wx.showToast({
        title: text.contentEmpty,
        icon: 'none'
      })
      return
    }

    this.setData({
      submittingPost: true
    })

    wx.cloud.callFunction({
      name: 'createPost',
      data: {
        title,
        content,
        category: this.data.newPostCategory
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || text.networkError,
            icon: 'none'
          })
          return
        }

        wx.showToast({
          title: text.postSuccess,
          icon: 'success'
        })

        this.setData({
          newPostTitle: '',
          newPostContent: '',
          searchKeyword: '',
          sortMode: 'latest',
          activeCategory: 'all',
          categories: buildCategories(this.data.lang, 'all'),
          sortOptions: buildSortOptions(this.data.lang, 'latest'),
          page: 0
        })

        this.loadPosts(true)
      },
      fail: (err) => {
        console.error('createPost failed:', err)
        wx.showToast({
          title: text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          submittingPost: false
        })
      }
    })
  },

  viewDetail(e) {
    if (!this.guardProfileCompleted()) return

    const postId = e.currentTarget.dataset.id

    if (!postId) return

    wx.navigateTo({
      url: `/pages/postDetail/postDetail?id=${postId}`
    })
  },

  toggleLike(e) {
    if (!this.guardProfileCompleted()) return

    const postId = e.currentTarget.dataset.id

    if (!postId) return

    wx.cloud.callFunction({
      name: 'toggleLike',
      data: {
        targetType: 'post',
        targetId: postId
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        const posts = this.data.posts.map(item => {
          if (item._id !== postId) return item

          const currentLikeCount = Number(item.safeLikeCount || item.likeCount || 0)
          const nextLikeCount = result.liked
            ? currentLikeCount + 1
            : Math.max(currentLikeCount - 1, 0)

          return Object.assign({}, item, {
            liked: result.liked,
            likeCount: nextLikeCount,
            safeLikeCount: nextLikeCount
          })
        })

        this.setData({
          posts
        })
      },
      fail: (err) => {
        console.error('toggleLike failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      }
    })
  },

  reportPost(e) {
    if (!this.guardProfileCompleted()) return

    const postId = e.currentTarget.dataset.id
    const text = this.data.text

    if (!postId) return

    wx.showModal({
      title: text.reportTitle,
      content: text.reportPostContent,
      confirmColor: '#c95645',
      success: (modalRes) => {
        if (!modalRes.confirm) return

        this.setData({
          reporting: true
        })

        wx.cloud.callFunction({
          name: 'reportContent',
          data: {
            targetType: 'post',
            targetId: postId,
            reason: 'community_post_report',
            description: 'User reported this post from DormTalk community list.'
          },
          success: (res) => {
            const result = res.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: text.reportSuccess,
              icon: 'success'
            })
          },
          fail: (err) => {
            console.error('reportContent post failed:', err)
            wx.showToast({
              title: text.networkError,
              icon: 'none'
            })
          },
          complete: () => {
            this.setData({
              reporting: false
            })
          }
        })
      }
    })
  },

  goMyPosts() {
    if (!this.guardProfileCompleted()) return

    wx.navigateTo({
      url: '/pages/myPosts/myPosts'
    })
  }
})