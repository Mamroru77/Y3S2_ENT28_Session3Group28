const app = getApp()
const {
  getCurrentLang,
  getPageText,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getUser,
  getProfile,
  saveProfile
} = require('../../utils/storage')

const {
  updateReputation,
  evaluateProfileCompletion
} = require('../../utils/reputation')

Page({
  data: {
    lang: 'zh',
    text: {},
    user: null,
    campusOptions: [],
    yearOptions: ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Postgraduate'],
    lookingForOptions: [],
    profile: {
      nickname: '',
      university: 'XJTLU',
      campus: '',
      year: '',
      major: '',
      lookingFor: ''
    }
  },

  onLoad() {
    const user = getUser()
    const savedProfile = getProfile()

    this.setData({
      user,
      profile: savedProfile || {
        nickname: user ? user.nickname : '',
        university: 'XJTLU',
        campus: '',
        year: '',
        major: '',
        lookingFor: ''
      }
    })

    this.refreshLanguage()
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  refreshLanguage() {
    const lang = getCurrentLang()
    const text = getPageText('profileSetup', lang)

    this.setData({
      lang,
      text,
      campusOptions: [text.sipCampus, text.taicangCampus],
      lookingForOptions: [text.dormRoommate, text.flatmate, text.both]
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.refreshLanguage()
  },

  updateField(event) {
    const field = event.currentTarget.dataset.field
    const value = event.detail.value

    this.setData({
      [`profile.${field}`]: value
    })
  },

  updatePicker(event) {
    const field = event.currentTarget.dataset.field
    const source = event.currentTarget.dataset.source
    const index = Number(event.detail.value)

    const options = this.data[source] || []
    const selectedValue = options[index] || ''

    this.setData({
      [`profile.${field}`]: selectedValue
    })
  },

  saveAndContinue() {
    const profile = this.data.profile

    if (!profile.nickname || !profile.campus || !profile.year || !profile.major || !profile.lookingFor) {
      wx.showToast({
        title: this.data.lang === 'zh' ? '请完整填写资料' : 'Please complete profile',
        icon: 'none'
      })

      const evaluation = evaluateProfileCompletion(profile)

      updateReputation(
        evaluation.change,
        evaluation.reasonEn,
        evaluation.reasonZh,
        evaluation.type
      )

      return
    }

    saveProfile({
      ...profile,
      updatedAt: new Date().toISOString()
    })

    const evaluation = evaluateProfileCompletion(profile)

    updateReputation(
      evaluation.change,
      evaluation.reasonEn,
      evaluation.reasonZh,
      evaluation.type
    )

    wx.showToast({
      title: this.data.lang === 'zh' ? '资料已保存' : 'Profile saved',
      icon: 'success'
    })

    setTimeout(() => {
      wx.navigateTo({
        url: '/pages/questionnaire/questionnaire'
      })
    }, 600)
  }
})