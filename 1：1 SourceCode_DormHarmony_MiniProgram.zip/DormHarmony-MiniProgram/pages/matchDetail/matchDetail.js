const app = getApp()

let auth = {}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const {
  getCurrentLang,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getQuestionnaire,
  saveSelectedChatMatchId,
  addChatRequest
} = require('../../utils/storage')

const {
  roommateCandidates
} = require('../../utils/mockData')

const {
  calculateAllMatches
} = require('../../utils/matching')

const pageText = {
  zh: {
    eyebrow: 'DormHarmony',
    title: '匹配详情',
    pageDesc: '查看匹配解释、学术信息、生活边界和建议沟通点，帮助你判断是否值得进一步联系。',
    languageButton: 'EN',

    totalScore: '总匹配分',
    reputation: '候选人信誉分',
    matchType: '候选类型',
    gender: '性别',
    livingType: '住宿场景',

    academicProfile: '学术资料',
    campus: '校区',
    school: '学院',
    programme: '专业',
    fullProgramme: '完整专业名称',

    personalityTitle: '人格与生活方式画像',
    yourStack: '你的画像',
    candidateStack: '对方画像',
    lifestyleOverlap: '共同生活方式',
    greenOverlap: '共同 Green Flags',
    redConflict: 'Red Flag 风险',
    noOverlap: '暂无明显重合',
    noRedConflict: '暂无明显 Red Flag 重合风险',
    noProfileTags: '暂无可展示标签',

    dimensionTitle: '维度拆解',
    strengthsTitle: '优势匹配点',
    risksTitle: '潜在风险点',
    conflictsTitle: '硬性冲突提醒',
    questionsTitle: '建议沟通话题',

    bearName: '哈米熊',
    bearSpeech: '别只看总分。真正适合沟通的舍友，往往体现在边界、作息、访客规则和冲突风险是否清楚。',

    sendRequest: '发送沟通申请',
    generateAgreement: '生成合住协议',
    back: '返回匹配列表',

    noConflict: '没有检测到严重硬性冲突。',
    requestCreated: '沟通对象已选择',
    conversationCreated: '会话已创建',
    noQuestionnaire: '请先完成生活习惯问卷',
    noMatch: '暂无匹配对象',
    networkError: '网络或云函数异常',
    realUserBadge: '真实用户',
    demoUserBadge: '演示候选人'
  },

  en: {
    eyebrow: 'DormHarmony',
    title: 'Match Detail',
    pageDesc: 'Review the match explanation, academic profile, lifestyle boundaries and suggested topics before deciding whether to contact this person.',
    languageButton: '中文',

    totalScore: 'Total Match Score',
    reputation: 'Candidate Reputation',
    matchType: 'Candidate Type',
    gender: 'Gender',
    livingType: 'Living Type',

    academicProfile: 'Academic Profile',
    campus: 'Campus',
    school: 'School',
    programme: 'Programme',
    fullProgramme: 'Full Programme',

    personalityTitle: 'Personality & Lifestyle Stack',
    yourStack: 'Your Stack',
    candidateStack: 'Candidate Stack',
    lifestyleOverlap: 'Shared Lifestyle',
    greenOverlap: 'Shared Green Flags',
    redConflict: 'Red Flag Risk',
    noOverlap: 'No obvious overlap',
    noRedConflict: 'No obvious Red Flag overlap',
    noProfileTags: 'No visible tags yet',

    dimensionTitle: 'Dimension Breakdown',
    strengthsTitle: 'Strengths',
    risksTitle: 'Potential Risks',
    conflictsTitle: 'Hard Conflict Warning',
    questionsTitle: 'Suggested Topics',

    bearName: 'Harmony Bear',
    bearSpeech: 'Do not judge only by total score. A truly suitable roommate depends on boundaries, schedule, visitor rules and conflict risks.',
    sendRequest: 'Send Chat Request',
    generateAgreement: 'Generate Agreement',
    back: 'Back to Matches',

    noConflict: 'No serious hard conflict detected.',
    requestCreated: 'Chat target selected',
    conversationCreated: 'Conversation created',
    noQuestionnaire: 'Please complete the lifestyle questionnaire first',
    noMatch: 'No match selected',
    networkError: 'Network or cloud function error',
    realUserBadge: 'Real User',
    demoUserBadge: 'Demo Candidate'
  }
}

function safeArray(value) {
  return Array.isArray(value) ? value : []
}

function getScoreClass(score) {
  const value = Number(score || 0)

  if (value >= 85) return 'high'
  if (value >= 70) return 'medium'
  return 'low'
}

function getScoreLevel(score, lang) {
  const value = Number(score || 0)

  if (lang === 'zh') {
    if (value >= 85) return '高度匹配'
    if (value >= 70) return '良好匹配'
    if (value >= 55) return '可进一步沟通'
    return '存在明显差异'
  }

  if (value >= 85) return 'High Match'
  if (value >= 70) return 'Good Match'
  if (value >= 55) return 'Worth Discussing'
  return 'Clear Differences'
}

function getReputationLevel(score, lang) {
  const value = Number(score || 0)

  if (lang === 'zh') {
    if (value >= 90) return '优秀'
    if (value >= 75) return '稳定'
    if (value >= 60) return '可信'
    return '需观察'
  }

  if (value >= 90) return 'Excellent'
  if (value >= 75) return 'Stable'
  if (value >= 60) return 'Reliable'
  return 'Needs review'
}

function normalizeGenderText(gender, lang) {
  if (gender === 'male') return lang === 'zh' ? '男' : 'Male'
  if (gender === 'female') return lang === 'zh' ? '女' : 'Female'
  return lang === 'zh' ? '未说明' : 'Not specified'
}

function normalizeLivingTypeText(livingType, lang) {
  if (livingType === 'school_dorm') {
    return lang === 'zh' ? '学校宿舍' : 'School Dorm'
  }

  if (livingType === 'off_campus') {
    return lang === 'zh' ? '校外合租' : 'Off-campus'
  }

  return lang === 'zh' ? '未说明' : 'Not specified'
}

function shortSchoolName(school) {
  const value = String(school || '')

  const map = [
    ['International Business School Suzhou', 'IBSS'],
    ['Business School', 'Business School'],
    ['School of Advanced Technology', 'SAT'],
    ['School of Intelligent Finance and Business', 'SIFB'],
    ['School of Intelligent Manufacturing Ecosystem', 'SIME'],
    ['School of AI and Advanced Computing', 'AI & Advanced Computing'],
    ['School of Internet of Things', 'IoT School'],
    ['School of Humanities and Social Sciences', 'HSS'],
    ['School of Mathematics and Physics', 'Maths & Physics'],
    ['Academy of Film and Creative Technology', 'AFCT'],
    ['XJTLU Wisdom Lake Academy of Pharmacy', 'WLAP']
  ]

  const found = map.find(item => value.indexOf(item[0]) > -1)
  return found ? found[1] : value
}

function shortProgrammeName(programme, programmeCode) {
  const value = String(programme || '')
  const code = String(programmeCode || '')

  const codeMap = {
    SUPPLY_CHAIN_MANAGEMENT: 'Supply Chain Management',
    INTELLIGENT_SUPPLY_CHAIN_CE: 'Intelligent Supply Chain',
    INTELLIGENT_MANUFACTURING_ENGINEERING_CE: 'Intelligent Manufacturing',
    INTERNET_OF_THINGS_ENGINEERING_CE: 'IoT Engineering',
    INTELLIGENT_ROBOTICS_ENGINEERING_CE: 'Intelligent Robotics',
    MICROELECTRONIC_SCIENCE_ENGINEERING_CE: 'Microelectronic Science',
    DATA_SCIENCE_BIG_DATA_CE: 'Data Science & Big Data',
    ARTIFICIAL_INTELLIGENCE_TC: 'Artificial Intelligence',
    ARTIFICIAL_INTELLIGENCE_SIP: 'Artificial Intelligence',
    ACCOUNTING: 'Accounting',
    BUSINESS_ADMINISTRATION: 'Business Administration',
    ECONOMICS: 'Economics',
    ECONOMICS_FINANCE: 'Economics & Finance',
    DIGITAL_INTELLIGENT_MARKETING: 'Digital & Intelligent Marketing',
    HRM_PEOPLE_ANALYTICS: 'HRM & People Analytics',
    IMIS: 'Information Management',
    INTERNATIONAL_BUSINESS_LANGUAGE: 'International Business',
    COMPUTER_SCIENCE_TECHNOLOGY: 'Computer Science',
    DIGITAL_MEDIA_TECHNOLOGY: 'Digital Media Technology',
    ELECTRICAL_ENGINEERING: 'Electrical Engineering',
    ELECTRONIC_SCIENCE_TECHNOLOGY: 'Electronic Science',
    INFORMATION_COMPUTING_SCIENCE: 'Information & Computing',
    MECHATRONICS_ROBOTIC_SYSTEMS: 'Mechatronics & Robotics',
    TELECOMMUNICATIONS_ENGINEERING: 'Telecommunications',
    ARCHITECTURE: 'Architecture',
    CIVIL_ENGINEERING: 'Civil Engineering',
    INDUSTRIAL_DESIGN: 'Industrial Design',
    URBAN_PLANNING_DESIGN: 'Urban Planning',
    MEDIA_COMMUNICATION_STUDIES: 'Media & Communication',
    TRANSLATION_INTERPRETING: 'Translation & Interpreting',
    INTERNATIONAL_RELATIONS: 'International Relations',
    FINANCIAL_MATHEMATICS: 'Financial Mathematics',
    ACTUARIAL_SCIENCE: 'Actuarial Science',
    APPLIED_MATHEMATICS: 'Applied Mathematics',
    MATERIALS_SCIENCE_ENGINEERING: 'Materials Science',
    BIOLOGICAL_SCIENCES: 'Biological Sciences',
    BIOMEDICAL_SCIENCES: 'Biomedical Sciences',
    ENVIRONMENTAL_SCIENCE: 'Environmental Science',
    APPLIED_CHEMISTRY: 'Applied Chemistry'
  }

  if (codeMap[code]) return codeMap[code]

  return value
    .replace(' with Contemporary Entrepreneurialism', '')
    .replace(' BSc (Hons)', '')
    .replace(' BEng (Hons)', '')
    .replace(' BA (Hons)', '')
    .trim()
}

function buildAcademicProfile(rawMatch) {
  const campus = rawMatch.campus || rawMatch.displayCampus || ''
  const school = rawMatch.school || rawMatch.displaySchool || ''
  const programme = rawMatch.programme || rawMatch.major || rawMatch.displayMajor || ''
  const programmeCode = rawMatch.programmeCode || ''

  const schoolShort = rawMatch.schoolShortText || shortSchoolName(school)
  const programmeShort = rawMatch.programmeShortText || shortProgrammeName(programme, programmeCode)

  const academicLine = [
    rawMatch.year || '',
    campus,
    schoolShort
  ].filter(Boolean).join(' · ')

  return {
    campus,
    school,
    schoolShort,
    programme,
    programmeShort,
    programmeCode,
    academicLine
  }
}

function getQuestionnaireStack(questionnaire, lang) {
  if (!questionnaire) return []

  const stack = []

  if (questionnaire.dormVibe) stack.push(questionnaire.dormVibe)
  if (questionnaire.mbti) stack.push(questionnaire.mbti)

  safeArray(questionnaire.lifestyleTags).slice(0, 3).forEach(item => {
    stack.push(item)
  })

  if (questionnaire.cleanliness) {
    stack.push(lang === 'zh'
      ? `卫生标准 ${questionnaire.cleanliness}/5`
      : `Cleanliness ${questionnaire.cleanliness}/5`)
  }

  if (questionnaire.noiseTolerance) {
    stack.push(lang === 'zh'
      ? `噪音接受 ${questionnaire.noiseTolerance}/5`
      : `Noise tolerance ${questionnaire.noiseTolerance}/5`)
  }

  return stack.filter(Boolean)
}

function getEmptyPersonality() {
  return {
    yourStack: [],
    candidateStack: [],
    lifestyleOverlap: [],
    greenOverlap: [],
    redFlagConflicts: []
  }
}

function normalizeDimensionList(list) {
  return safeArray(list).map(item => {
    const score = Math.max(0, Math.min(100, Math.round(Number(item.score || 0))))

    return Object.assign({}, item, {
      score,
      scoreClass: item.scoreClass || getScoreClass(score),
      scoreStyle: item.scoreStyle || `width: ${score}%;`
    })
  })
}

function buildRealPersonality(match, lang) {
  const currentQuestionnaire = getQuestionnaire() || {}
  const candidateQuestionnaire = match.profile || {}

  const lifestyleOverlap = safeArray(currentQuestionnaire.lifestyleTags)
    .filter(item => safeArray(candidateQuestionnaire.lifestyleTags).indexOf(item) > -1)

  const greenOverlap = safeArray(currentQuestionnaire.greenFlags)
    .filter(item => safeArray(candidateQuestionnaire.greenFlags).indexOf(item) > -1)

  const redFlagConflicts = safeArray(currentQuestionnaire.redFlags)
    .filter(item => safeArray(candidateQuestionnaire.redFlags).indexOf(item) > -1)

  return {
    yourStack: getQuestionnaireStack(currentQuestionnaire, lang),
    candidateStack: getQuestionnaireStack(candidateQuestionnaire, lang),
    lifestyleOverlap,
    greenOverlap,
    redFlagConflicts
  }
}

function buildRealDimensions(match, lang) {
  const profile = match.profile || {}

  return [
    {
      key: 'schedule',
      label: lang === 'zh' ? '作息时间' : 'Schedule',
      score: Number(match.score || 0),
      desc: lang === 'zh'
        ? `睡觉 ${profile.sleepTime || '-'}，起床 ${profile.wakeTime || '-'}`
        : `Sleep ${profile.sleepTime || '-'}, wake ${profile.wakeTime || '-'}`
    },
    {
      key: 'cleanliness',
      label: lang === 'zh' ? '卫生习惯' : 'Cleanliness',
      score: Number(profile.cleanliness || 3) * 20,
      desc: lang === 'zh'
        ? `卫生要求 ${profile.cleanliness || '-'}/5`
        : `Cleanliness ${profile.cleanliness || '-'}/5`
    },
    {
      key: 'noise',
      label: lang === 'zh' ? '噪音接受度' : 'Noise Tolerance',
      score: Number(profile.noiseTolerance || 3) * 20,
      desc: lang === 'zh'
        ? `噪音接受度 ${profile.noiseTolerance || '-'}/5`
        : `Noise tolerance ${profile.noiseTolerance || '-'}/5`
    },
    {
      key: 'visitors',
      label: lang === 'zh' ? '访客边界' : 'Visitor Boundary',
      score: Number(profile.visitorAcceptance || 3) * 20,
      desc: lang === 'zh'
        ? `访客接受度 ${profile.visitorAcceptance || '-'}/5`
        : `Visitor acceptance ${profile.visitorAcceptance || '-'}/5`
    }
  ].map(item => {
    const score = Math.max(0, Math.min(100, Math.round(item.score || 0)))

    return Object.assign({}, item, {
      score,
      scoreClass: getScoreClass(score),
      scoreStyle: `width: ${score}%;`
    })
  })
}

function normalizeRealMatch(rawMatch, lang) {
  const score = Number(rawMatch.score || 0)
  const profile = rawMatch.profile || {}
  const academic = buildAcademicProfile(rawMatch)

  const match = Object.assign({}, rawMatch, {
    id: rawMatch.id || rawMatch.candidateOpenid,
    candidateOpenid: rawMatch.candidateOpenid || rawMatch.id,
    isRealUser: true,
    matchMode: 'real',

    name: rawMatch.name || 'Dorm User',
    year: rawMatch.year || '',
    campus: academic.campus,
    school: academic.school,
    major: academic.programme,
    programme: academic.programme,
    programmeCode: academic.programmeCode,
    mbti: rawMatch.mbti || profile.mbti || '',

    displayCampus: academic.campus,
    displaySchool: academic.school,
    displayMajor: academic.programme,

    schoolShortText: academic.schoolShort,
    programmeShortText: academic.programmeShort,
    academicLine: academic.academicLine,

    score,
    scoreClass: rawMatch.scoreClass || getScoreClass(score),
    scoreLevel: rawMatch.scoreLevel || getScoreLevel(score, lang),
    scoreStyle: rawMatch.scoreStyle || `width: ${score}%;`,

    reputationScore: Number(rawMatch.reputationScore || 100),
    displayReputationLevel: rawMatch.displayReputationLevel || getReputationLevel(rawMatch.reputationScore || 100, lang),

    displayTags: safeArray(rawMatch.displayTags),
    strengths: safeArray(rawMatch.strengths),
    risks: safeArray(rawMatch.risks),
    hardConflicts: safeArray(rawMatch.hardConflicts),
    suggestedQuestions: safeArray(rawMatch.suggestedQuestions),

    genderText: normalizeGenderText(rawMatch.gender, lang),
    livingTypeText: normalizeLivingTypeText(rawMatch.livingType, lang),

    academic,
    profile,

    personality: buildRealPersonality(rawMatch, lang),
    dimensions: buildRealDimensions(rawMatch, lang)
  })

  if (!match.displayTags.length) {
    match.displayTags = [
      match.livingTypeText,
      match.genderText,
      match.mbti
    ].filter(Boolean)
  }

  if (!match.strengths.length) {
    match.strengths = [
      lang === 'zh'
        ? '该用户资料较完整，可进一步沟通作息、卫生和访客规则。'
        : 'This user has a relatively complete profile and is worth discussing schedule, cleaning and visitor rules with.'
    ]
  }

  if (!match.risks.length) {
    match.risks = [
      lang === 'zh'
        ? '暂未发现明显硬性冲突，但仍建议先确认边界和合住预期。'
        : 'No obvious hard conflict detected, but boundaries and expectations should still be confirmed first.'
    ]
  }

  if (!match.hardConflicts.length) {
    match.hardConflicts = [pageText[lang].noConflict]
  }

  if (!match.suggestedQuestions.length) {
    match.suggestedQuestions = [
      lang === 'zh'
        ? '你通常几点之后希望宿舍保持安静？'
        : 'After what time do you expect the room to stay quiet?',
      lang === 'zh'
        ? '公共区域清洁你希望如何分工？'
        : 'How would you prefer to divide shared-area cleaning?',
      lang === 'zh'
        ? '朋友来宿舍前是否需要提前说明？'
        : 'Should visitors be mentioned in advance?'
    ]
  }

  return match
}

function normalizeDemoMatch(rawMatch, lang) {
  if (!rawMatch) return null

  const score = Number(rawMatch.score || 0)
  const academic = buildAcademicProfile(rawMatch)
  const personality = rawMatch.personality || getEmptyPersonality()

  return Object.assign({}, rawMatch, {
    isRealUser: false,
    matchMode: 'demo',

    campus: academic.campus,
    school: academic.school,
    major: academic.programme,
    programme: academic.programme,
    programmeCode: academic.programmeCode,

    displayCampus: academic.campus,
    displaySchool: academic.school,
    displayMajor: academic.programme,

    schoolShortText: academic.schoolShort,
    programmeShortText: academic.programmeShort,
    academicLine: academic.academicLine,

    score,
    scoreClass: rawMatch.scoreClass || getScoreClass(score),
    scoreLevel: rawMatch.scoreLevel || getScoreLevel(score, lang),
    scoreStyle: rawMatch.scoreStyle || `width: ${score}%;`,

    reputationScore: Number(rawMatch.reputationScore || 100),
    displayReputationLevel: rawMatch.displayReputationLevel || getReputationLevel(rawMatch.reputationScore || 100, lang),

    displayTags: safeArray(rawMatch.displayTags),
    strengths: safeArray(rawMatch.strengths),
    risks: safeArray(rawMatch.risks),
    hardConflicts: safeArray(rawMatch.hardConflicts),
    suggestedQuestions: safeArray(rawMatch.suggestedQuestions),

    genderText: normalizeGenderText(rawMatch.gender, lang),
    livingTypeText: normalizeLivingTypeText(rawMatch.livingType, lang),

    academic,

    personality: {
      yourStack: safeArray(personality.yourStack),
      candidateStack: safeArray(personality.candidateStack),
      lifestyleOverlap: safeArray(personality.lifestyleOverlap),
      greenOverlap: safeArray(personality.greenOverlap),
      redFlagConflicts: safeArray(personality.redFlagConflicts)
    },

    dimensions: normalizeDimensionList(rawMatch.dimensions)
  })
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,
    match: null,
    mode: 'demo',
    creatingConversation: false
  },

  onLoad(options) {
    this.matchId = options.id || ''
    this.mode = options.mode || 'demo'

    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadMatch()
  },

  onShow() {
    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadMatch()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  guardProfileAndQuestionnaire() {
    if (!this.guardProfileCompleted()) {
      return false
    }

    const questionnaire = getQuestionnaire()
    const hasQuestionnaire = !!(questionnaire && Object.keys(questionnaire).length > 0)

    if (!hasQuestionnaire) {
      wx.showToast({
        title: pageText[getCurrentLang()].noQuestionnaire,
        icon: 'none'
      })

      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/questionnaire/questionnaire'
        })
      }, 400)

      return false
    }

    return true
  },

  loadMatch() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    if (this.mode === 'real') {
      this.loadRealMatch(lang, text)
      return
    }

    this.loadDemoMatch(lang, text)
  },

  loadRealMatch(lang, text) {
    const selectedRealMatch = wx.getStorageSync('dh_selected_real_match') || null
    const realMatchesCache = wx.getStorageSync('dh_real_matches_cache') || []

    let rawMatch = null

    if (selectedRealMatch && (selectedRealMatch.id === this.matchId || selectedRealMatch.candidateOpenid === this.matchId)) {
      rawMatch = selectedRealMatch
    }

    if (!rawMatch && Array.isArray(realMatchesCache)) {
      rawMatch = realMatchesCache.find(item => {
        return item.id === this.matchId || item.candidateOpenid === this.matchId
      })
    }

    if (!rawMatch) {
      wx.showToast({
        title: text.noMatch,
        icon: 'none'
      })

      this.setData({
        lang,
        text,
        mode: 'real',
        match: null
      })

      return
    }

    const match = normalizeRealMatch(rawMatch, lang)

    this.setData({
      lang,
      text,
      mode: 'real',
      match
    })
  },

  loadDemoMatch(lang, text) {
    const questionnaire = getQuestionnaire()
    const matches = calculateAllMatches(questionnaire, roommateCandidates, lang)

    const rawMatch = matches.find((item) => item.id === this.matchId) || matches[0] || null
    const match = normalizeDemoMatch(rawMatch, lang)

    this.setData({
      lang,
      text,
      mode: 'demo',
      match
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.loadMatch()
  },

  sendRequest() {
    if (!this.guardProfileAndQuestionnaire()) return

    if (!this.data.match) {
      wx.showToast({
        title: this.data.text.noMatch,
        icon: 'none'
      })
      return
    }

    if (this.data.mode === 'real') {
      this.createRealConversation()
      return
    }

    this.createDemoConversation()
  },

  createDemoConversation() {
    const match = this.data.match

    saveSelectedChatMatchId(match.id)

    addChatRequest({
      matchId: match.id,
      matchName: match.name,
      status: 'selected',
      messages: []
    })

    wx.showToast({
      title: this.data.text.requestCreated,
      icon: 'none'
    })

    setTimeout(() => {
      wx.switchTab({
        url: '/pages/chat/chat'
      })
    }, 500)
  },

  createRealConversation() {
    const match = this.data.match
    const targetId = match.candidateOpenid || match.id
    const targetName = match.name || 'Dorm User'

    if (!targetId) {
      wx.showToast({
        title: this.data.text.noMatch,
        icon: 'none'
      })
      return
    }

    if (!wx.cloud || !wx.cloud.callFunction) {
      wx.showToast({
        title: this.data.text.networkError,
        icon: 'none'
      })
      return
    }

    this.setData({
      creatingConversation: true
    })

    wx.cloud.callFunction({
      name: 'createConversation',
      data: {
        targetId,
        targetName,
        targetType: 'real_user'
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        saveSelectedChatMatchId(targetId)
        wx.setStorageSync('dh_selected_real_match', match)

        wx.showToast({
          title: this.data.text.conversationCreated,
          icon: 'success'
        })

        setTimeout(() => {
          wx.switchTab({
            url: '/pages/chat/chat'
          })
        }, 500)
      },
      fail: (err) => {
        console.error('createConversation real failed:', err)

        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          creatingConversation: false
        })
      }
    })
  },

  goAgreement() {
    if (!this.guardProfileAndQuestionnaire()) return
    if (!this.data.match) return

    const id = this.data.match.candidateOpenid || this.data.match.id

    if (this.data.mode === 'real') {
      wx.setStorageSync('dh_selected_real_match', this.data.match)

      wx.navigateTo({
        url: `/pages/agreement/agreement?id=${id}&mode=real`
      })

      return
    }

    wx.navigateTo({
      url: `/pages/agreement/agreement?id=${id}&mode=demo`
    })
  },

  goBack() {
    wx.switchTab({
      url: '/pages/matches/matches'
    })
  }
})