const app = getApp()

let auth = {}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const {
  getCurrentLang,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getQuestionnaire
} = require('../../utils/storage')

const {
  roommateCandidates
} = require('../../utils/mockData')

const {
  calculateAllMatches
} = require('../../utils/matching')

const pageText = {
  zh: {
    eyebrow: 'DormHarmony',
    title: '合住协议',
    desc: '基于双方生活习惯、匹配结果和潜在风险生成的合住前沟通清单。',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '这不是法律合同，而是合住前的沟通清单。重点是提前确认边界、作息、访客、费用和冲突处理方式。',

    matchScore: '匹配分',
    reputation: '信誉分',
    candidateType: '候选类型',
    realUserBadge: '真实用户',
    demoUserBadge: '演示候选人',

    academicProfile: '学术资料',
    campus: '校区',
    school: '学院',
    programme: '专业',
    fullProgramme: '完整专业名称',

    agreementPreview: '协议预览',
    keyTerms: '关键条款',
    riskNotes: '风险提醒',
    copy: '复制协议文本',
    copied: '已复制',
    back: '返回',

    quietHours: '安静时间',
    cleaning: '清洁分工',
    visitors: '访客规则',
    ac: '空调温度',
    sharedCosts: '公共费用',
    personalSpace: '个人空间',
    conflictHandling: '冲突处理',
    review: '定期复盘',
    livingScenario: '住宿场景',
    genderRule: '性别匹配规则',

    schoolDormRule: '学校宿舍场景遵循学校男女分宿舍规则，默认只进行同性舍友匹配。',
    offCampusRule: '校外合租场景基于双方性别偏好进行双向筛选，只有双方互相接受时才会进入匹配。',

    noRisk: '当前没有发现严重硬性冲突，但仍建议提前确认生活边界。',
    noQuestionnaire: '请先完成生活习惯问卷',
    noMatch: '暂无协议数据',
    emptyTitle: '暂无协议数据',
    emptyDesc: '请返回匹配详情页重新选择候选人。'
  },

  en: {
    eyebrow: 'DormHarmony',
    title: 'Roommate Agreement',
    desc: 'A pre-living communication checklist generated from lifestyle habits, match results and potential risks.',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'This is not a legal contract. It is a pre-living checklist for boundaries, schedules, visitors, costs and conflict handling.',

    matchScore: 'Match Score',
    reputation: 'Reputation',
    candidateType: 'Candidate Type',
    realUserBadge: 'Real User',
    demoUserBadge: 'Demo Candidate',

    academicProfile: 'Academic Profile',
    campus: 'Campus',
    school: 'School',
    programme: 'Programme',
    fullProgramme: 'Full Programme',

    agreementPreview: 'Agreement Preview',
    keyTerms: 'Key Terms',
    riskNotes: 'Risk Notes',
    copy: 'Copy Agreement',
    copied: 'Copied',
    back: 'Back',

    quietHours: 'Quiet Hours',
    cleaning: 'Cleaning',
    visitors: 'Visitors',
    ac: 'AC Temperature',
    sharedCosts: 'Shared Costs',
    personalSpace: 'Personal Space',
    conflictHandling: 'Conflict Handling',
    review: 'Regular Review',
    livingScenario: 'Living Scenario',
    genderRule: 'Gender Matching Rule',

    schoolDormRule: 'School dorm matching follows gender-separated accommodation rules and uses same-gender matching by default.',
    offCampusRule: 'Off-campus housing uses mutual gender preference. A match is shown only when both sides are compatible.',

    noRisk: 'No serious hard conflict is detected, but boundaries should still be confirmed in advance.',
    noQuestionnaire: 'Please complete the lifestyle questionnaire first',
    noMatch: 'No agreement data',
    emptyTitle: 'No agreement data',
    emptyDesc: 'Please return to the match detail page and select a candidate again.'
  }
}

function cleanText(value) {
  return String(value || '').trim()
}

function toNumber(value, fallback) {
  const n = Number(value)
  return Number.isNaN(n) ? fallback : n
}

function safeArray(value) {
  return Array.isArray(value) ? value : []
}

function timeToMinutes(time) {
  if (!time) return 0

  const parts = String(time).split(':')
  const hour = Number(parts[0])
  const minute = Number(parts[1])

  if (Number.isNaN(hour) || Number.isNaN(minute)) return 0

  return hour * 60 + minute
}

function minutesToTime(minutes) {
  const fixed = ((minutes % 1440) + 1440) % 1440
  const hour = String(Math.floor(fixed / 60)).padStart(2, '0')
  const minute = String(fixed % 60).padStart(2, '0')

  return `${hour}:${minute}`
}

function averageTime(timeA, timeB) {
  const a = timeToMinutes(timeA)
  const b = timeToMinutes(timeB)
  const diff = Math.abs(a - b)

  if (diff <= 720) {
    return minutesToTime(Math.round((a + b) / 2))
  }

  const adjustedA = a < b ? a + 1440 : a
  const adjustedB = b < a ? b + 1440 : b

  return minutesToTime(Math.round((adjustedA + adjustedB) / 2))
}

function normalizeAc(value) {
  const text = cleanText(value)
  const number = Number(text.replace(/[^0-9]/g, ''))

  return Number.isNaN(number) ? 24 : number
}

function getScoreClass(score) {
  const value = Number(score || 0)

  if (value >= 85) return 'high'
  if (value >= 70) return 'medium'
  return 'low'
}

function getReputationLevel(score, lang) {
  const value = Number(score || 0)

  if (lang === 'zh') {
    if (value >= 90) return '优秀'
    if (value >= 75) return '稳定'
    if (value >= 60) return '可信'
    return '需观察'
  }

  if (value >= 90) return 'Excellent'
  if (value >= 75) return 'Stable'
  if (value >= 60) return 'Reliable'
  return 'Needs review'
}

function getLivingTypeText(match, lang) {
  if (match.livingType === 'school_dorm') {
    return lang === 'zh' ? '学校宿舍' : 'School dorm'
  }

  if (match.livingType === 'off_campus') {
    return lang === 'zh' ? '校外合租' : 'Off-campus housing'
  }

  return lang === 'zh' ? '未说明' : 'Not specified'
}

function getGenderRuleText(match, text) {
  if (match.livingType === 'off_campus') {
    return text.offCampusRule
  }

  return text.schoolDormRule
}

function getAcRange(userAc, candidateAc, lang) {
  const userNumber = normalizeAc(userAc)
  const candidateNumber = normalizeAc(candidateAc)

  const low = Math.min(userNumber, candidateNumber)
  const high = Math.max(userNumber, candidateNumber)

  if (Math.abs(userNumber - candidateNumber) <= 2) {
    return lang === 'zh'
      ? `建议空调温度保持在 ${low}–${high}°C。`
      : `Suggested AC range: ${low}–${high}°C.`
  }

  return lang === 'zh'
    ? `你们偏好的空调温度差异较大，建议先协商 ${low}–${high}°C 内的折中方案。`
    : `Your AC preferences differ. Discuss a compromise within ${low}–${high}°C.`
}

function overlap(listA, listB) {
  const a = safeArray(listA)
  const b = safeArray(listB)
  const setB = new Set(b.map(item => String(item)))

  return a.filter(item => setB.has(String(item)))
}

function shortSchoolName(school, schoolCode) {
  const code = String(schoolCode || '')
  const value = String(school || '')

  const codeMap = {
    IBSS: 'IBSS',
    SAT: 'SAT',
    DESIGN: 'Design School',
    HSS: 'HSS',
    MATH_PHYSICS: 'Maths & Physics',
    SCIENCE: 'School of Science',
    AFCT_SIP: 'AFCT',
    WLAP: 'WLAP',
    AIAC: 'AI & Advanced Computing',
    CHIPS: 'CHIPS',
    SIFB: 'SIFB',
    SIME: 'SIME',
    IOT: 'IoT School',
    ROBOTICS: 'Robotics',
    AFCT_TC: 'AFCT',
    OTHER_SIP: 'Other',
    OTHER_TC: 'Other'
  }

  if (codeMap[code]) return codeMap[code]

  const nameMap = [
    ['International Business School Suzhou', 'IBSS'],
    ['Business School', 'Business School'],
    ['School of Advanced Technology', 'SAT'],
    ['School of Intelligent Finance and Business', 'SIFB'],
    ['School of Intelligent Manufacturing Ecosystem', 'SIME'],
    ['School of AI and Advanced Computing', 'AI & Advanced Computing'],
    ['School of Internet of Things', 'IoT School'],
    ['School of Humanities and Social Sciences', 'HSS'],
    ['School of Mathematics and Physics', 'Maths & Physics'],
    ['Academy of Film and Creative Technology', 'AFCT'],
    ['XJTLU Wisdom Lake Academy of Pharmacy', 'WLAP']
  ]

  const found = nameMap.find(item => value.indexOf(item[0]) > -1)

  return found ? found[1] : value || '-'
}

function shortProgrammeName(programme, programmeCode) {
  const code = String(programmeCode || '')
  const value = String(programme || '')

  const codeMap = {
    SUPPLY_CHAIN_MANAGEMENT: 'Supply Chain Management',
    INTELLIGENT_SUPPLY_CHAIN_CE: 'Intelligent Supply Chain',
    INTELLIGENT_MANUFACTURING_ENGINEERING_CE: 'Intelligent Manufacturing',
    INTERNET_OF_THINGS_ENGINEERING_CE: 'IoT Engineering',
    INTELLIGENT_ROBOTICS_ENGINEERING_CE: 'Intelligent Robotics',
    MICROELECTRONIC_SCIENCE_ENGINEERING_CE: 'Microelectronic Science',
    DATA_SCIENCE_BIG_DATA_CE: 'Data Science & Big Data',
    ARTIFICIAL_INTELLIGENCE_TC: 'Artificial Intelligence',
    ARTIFICIAL_INTELLIGENCE_SIP: 'Artificial Intelligence',

    ACCOUNTING: 'Accounting',
    BUSINESS_ADMINISTRATION: 'Business Administration',
    ECONOMICS: 'Economics',
    ECONOMICS_FINANCE: 'Economics & Finance',
    DIGITAL_INTELLIGENT_MARKETING: 'Digital & Intelligent Marketing',
    HRM_PEOPLE_ANALYTICS: 'HRM & People Analytics',
    IMIS: 'Information Management',
    INTERNATIONAL_BUSINESS_LANGUAGE: 'International Business',

    COMPUTER_SCIENCE_TECHNOLOGY: 'Computer Science',
    DIGITAL_MEDIA_TECHNOLOGY: 'Digital Media Technology',
    ELECTRICAL_ENGINEERING: 'Electrical Engineering',
    ELECTRONIC_SCIENCE_TECHNOLOGY: 'Electronic Science',
    INFORMATION_COMPUTING_SCIENCE: 'Information & Computing',
    MECHATRONICS_ROBOTIC_SYSTEMS: 'Mechatronics & Robotics',
    TELECOMMUNICATIONS_ENGINEERING: 'Telecommunications',

    ARCHITECTURE: 'Architecture',
    CIVIL_ENGINEERING: 'Civil Engineering',
    INDUSTRIAL_DESIGN: 'Industrial Design',
    URBAN_PLANNING_DESIGN: 'Urban Planning',

    MEDIA_COMMUNICATION_STUDIES: 'Media & Communication',
    TRANSLATION_INTERPRETING: 'Translation & Interpreting',
    INTERNATIONAL_RELATIONS: 'International Relations',

    FINANCIAL_MATHEMATICS: 'Financial Mathematics',
    ACTUARIAL_SCIENCE: 'Actuarial Science',
    APPLIED_MATHEMATICS: 'Applied Mathematics',

    MATERIALS_SCIENCE_ENGINEERING: 'Materials Science',
    BIOLOGICAL_SCIENCES: 'Biological Sciences',
    BIOMEDICAL_SCIENCES: 'Biomedical Sciences',
    ENVIRONMENTAL_SCIENCE: 'Environmental Science',
    APPLIED_CHEMISTRY: 'Applied Chemistry',

    OTHER_PROGRAMME_SIP: 'Other',
    OTHER_PROGRAMME_TC: 'Other'
  }

  if (codeMap[code]) return codeMap[code]

  return value
    .replace(' with Contemporary Entrepreneurialism', '')
    .replace(' BSc (Hons)', '')
    .replace(' BEng (Hons)', '')
    .replace(' BA (Hons)', '')
    .replace(' / Pharmacy-related programme', '')
    .trim() || '-'
}

function buildAcademicProfile(raw) {
  const campus = raw.campus || raw.displayCampus || ''
  const school = raw.school || raw.displaySchool || ''
  const programme = raw.programme || raw.major || raw.displayMajor || ''
  const schoolCode = raw.schoolCode || ''
  const programmeCode = raw.programmeCode || ''

  const schoolShort = raw.schoolShortText || shortSchoolName(school, schoolCode)
  const programmeShort = raw.programmeShortText || shortProgrammeName(programme, programmeCode)

  const academicLine = [
    raw.year || '',
    campus,
    schoolShort
  ].filter(Boolean).join(' · ')

  return {
    campus,
    school,
    schoolCode,
    schoolShort,
    programme,
    programmeCode,
    programmeShort,
    academicLine
  }
}

function buildPlainText(match, terms, riskNotes, lang) {
  const lines = []

  if (lang === 'zh') {
    lines.push('DormHarmony 合住协议草案')
    lines.push(`对象：${match.name}`)
    lines.push(`匹配分：${match.score}%`)
    lines.push(`住宿场景：${match.livingTypeText || '-'}`)
    lines.push(`校区：${match.academic.campus || '-'}`)
    lines.push(`学院：${match.academic.schoolShort || '-'}`)
    lines.push(`专业：${match.academic.programmeShort || '-'}`)
    lines.push('')
    lines.push('关键条款：')
  } else {
    lines.push('DormHarmony Roommate Agreement Draft')
    lines.push(`Candidate: ${match.name}`)
    lines.push(`Match Score: ${match.score}%`)
    lines.push(`Living Scenario: ${match.livingTypeText || '-'}`)
    lines.push(`Campus: ${match.academic.campus || '-'}`)
    lines.push(`School: ${match.academic.schoolShort || '-'}`)
    lines.push(`Programme: ${match.academic.programmeShort || '-'}`)
    lines.push('')
    lines.push('Key Terms:')
  }

  terms.forEach((item, index) => {
    lines.push(`${index + 1}. ${item.title}`)
    lines.push(item.content)
    lines.push('')
  })

  lines.push(lang === 'zh' ? '风险提醒：' : 'Risk Notes:')

  riskNotes.forEach(item => {
    lines.push(`- ${item}`)
  })

  return lines.join('\n')
}

function normalizeMatch(raw, lang, text, mode) {
  const score = toNumber(raw.score, 0)
  const academic = buildAcademicProfile(raw)

  const normalized = Object.assign({}, raw, {
    id: raw.id || raw.candidateOpenid,
    candidateOpenid: raw.candidateOpenid || raw.id,
    name: raw.name || 'Dorm User',

    year: raw.year || '',

    campus: academic.campus,
    school: academic.school,
    major: academic.programme,
    programme: academic.programme,

    schoolCode: academic.schoolCode,
    programmeCode: academic.programmeCode,

    displayCampus: academic.campus,
    displaySchool: academic.school,
    displayMajor: academic.programme,

    schoolShortText: academic.schoolShort,
    programmeShortText: academic.programmeShort,
    academicLine: academic.academicLine,
    academic,

    reputationScore: toNumber(raw.reputationScore, 100),
    displayReputationLevel: raw.displayReputationLevel || getReputationLevel(raw.reputationScore || 100, lang),

    score,
    scoreClass: raw.scoreClass || getScoreClass(score),

    profile: raw.profile || {},

    livingType: raw.livingType || 'school_dorm',
    matchMode: mode || 'demo',
    isRealUser: mode === 'real'
  })

  normalized.livingTypeText = getLivingTypeText(normalized, lang)
  normalized.genderRuleText = getGenderRuleText(normalized, text)

  return normalized
}

function buildAgreement(userQuestionnaire, match, lang, text) {
  const candidate = match.profile || {}

  const quietStart = averageTime(
    userQuestionnaire.lightsOffTime || userQuestionnaire.lightsOff || '23:45',
    candidate.lightsOffTime || candidate.lightsOff || '23:45'
  )

  const strictClean = toNumber(userQuestionnaire.cleanliness, 3) >= 4 ||
    toNumber(candidate.cleanliness, 3) >= 4

  const lowVisitor = toNumber(userQuestionnaire.visitorAcceptance, 3) <= 2 ||
    toNumber(candidate.visitorAcceptance, 3) <= 2

  const quietSensitive = toNumber(userQuestionnaire.noiseTolerance, 3) <= 2 ||
    toNumber(candidate.noiseTolerance, 3) <= 2

  const terms = [
    {
      key: 'livingScenario',
      title: text.livingScenario,
      content: lang === 'zh'
        ? `本次匹配场景为：${match.livingTypeText}。`
        : `This match is under: ${match.livingTypeText}.`
    },
    {
      key: 'genderRule',
      title: text.genderRule,
      content: match.genderRuleText
    },
    {
      key: 'quietHours',
      title: text.quietHours,
      content: lang === 'zh'
        ? `建议每天 ${quietStart} 后进入安静时段。若一方仍需学习、游戏或通话，应使用耳机并降低音量。`
        : `Suggested quiet hours start after ${quietStart}. If either roommate studies, games or calls after this time, headphones and low volume are expected.`
    },
    {
      key: 'cleaning',
      title: text.cleaning,
      content: strictClean
        ? lang === 'zh'
          ? '建议每周至少一次公共区域清洁，并提前明确谁负责地面、垃圾、桌面和卫生间。'
          : 'Clean shared areas at least once a week, with clear responsibility for floor, trash, desk area and bathroom.'
        : lang === 'zh'
          ? '建议保持基本公共区域整洁，并在垃圾、桌面和个人物品堆放方面设定最低标准。'
          : 'Maintain basic shared-space cleanliness and set minimum standards for trash, desk areas and personal items.'
    },
    {
      key: 'visitors',
      title: text.visitors,
      content: lowVisitor
        ? lang === 'zh'
          ? '访客来宿舍前应提前说明。过夜、深夜来访或频繁来访需要双方明确同意。'
          : 'Visitors should be mentioned in advance. Overnight, late-night or frequent visits require clear agreement from both.'
        : lang === 'zh'
          ? '访客可以接受，但仍建议提前说明，避免影响休息和隐私。'
          : 'Visitors are generally acceptable, but advance notice is still recommended to protect rest and privacy.'
    },
    {
      key: 'ac',
      title: text.ac,
      content: getAcRange(
        userQuestionnaire.acTemperature || userQuestionnaire.acTemp,
        candidate.acTemperature || candidate.acTemp,
        lang
      )
    },
    {
      key: 'sharedCosts',
      title: text.sharedCosts,
      content: lang === 'zh'
        ? '公共用品和公共费用应提前约定分摊方式。建议使用清单记录，避免事后争议。'
        : 'Shared items and shared costs should be agreed in advance. Use a simple list to avoid later disputes.'
    },
    {
      key: 'personalSpace',
      title: text.personalSpace,
      content: lang === 'zh'
        ? '未经同意不要使用或移动对方私人物品。公共区域物品应及时收纳。'
        : 'Do not use or move the other person’s belongings without permission. Shared areas should be kept organized.'
    },
    {
      key: 'conflictHandling',
      title: text.conflictHandling,
      content: lang === 'zh'
        ? '如果出现不适或冲突，建议在 24 小时内私下沟通，不使用冷暴力或公开指责。'
        : 'If discomfort or conflict occurs, discuss it privately within 24 hours. Avoid silent treatment or public blame.'
    },
    {
      key: 'review',
      title: text.review,
      content: lang === 'zh'
        ? '建议合住前两周进行一次复盘，确认作息、卫生、访客和费用规则是否需要调整。'
        : 'Review the agreement after the first two weeks to adjust rules on schedule, cleaning, visitors and expenses.'
    }
  ]

  const riskNotes = []

  if (quietSensitive) {
    riskNotes.push(lang === 'zh'
      ? '至少一方对噪音较敏感，建议明确耳机和安静时段规则。'
      : 'At least one person is noise-sensitive. Clarify headphone and quiet-hour rules.')
  }

  if (strictClean) {
    riskNotes.push(lang === 'zh'
      ? '至少一方对卫生要求较高，建议设置固定清洁频率。'
      : 'At least one person has high cleanliness expectations. Set a fixed cleaning routine.')
  }

  if (lowVisitor) {
    riskNotes.push(lang === 'zh'
      ? '至少一方对访客较敏感，访客规则应提前确认。'
      : 'At least one person is sensitive to visitors. Visitor rules should be confirmed in advance.')
  }

  const redOverlap = overlap(userQuestionnaire.redFlags, candidate.redFlags)

  if (redOverlap.length) {
    riskNotes.push(lang === 'zh'
      ? `共同敏感点包括：${redOverlap.slice(0, 3).join('、')}。`
      : `Shared sensitive points include: ${redOverlap.slice(0, 3).join(', ')}.`)
  }

  safeArray(match.risks).slice(0, 2).forEach(item => {
    if (item && riskNotes.indexOf(item) === -1) {
      riskNotes.push(item)
    }
  })

  if (!riskNotes.length) {
    riskNotes.push(text.noRisk)
  }

  return {
    terms,
    riskNotes,
    plainText: buildPlainText(match, terms, riskNotes, lang)
  }
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,
    matchId: '',
    mode: 'demo',
    match: null,
    agreement: null,
    loading: false
  },

  onLoad(options) {
    this.matchId = options.id || ''
    this.mode = options.mode || 'demo'

    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadAgreement()
  },

  onShow() {
    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadAgreement()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  guardProfileAndQuestionnaire() {
    if (!this.guardProfileCompleted()) {
      return false
    }

    const questionnaire = getQuestionnaire()
    const hasQuestionnaire = !!(questionnaire && Object.keys(questionnaire).length > 0)

    if (!hasQuestionnaire) {
      wx.showToast({
        title: pageText[getCurrentLang()].noQuestionnaire,
        icon: 'none'
      })

      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/questionnaire/questionnaire'
        })
      }, 400)

      return false
    }

    return true
  },

  loadAgreement() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    this.setData({
      lang,
      text
    })

    if (this.mode === 'real') {
      this.loadRealAgreement(lang, text)
      return
    }

    this.loadDemoAgreement(lang, text)
  },

  loadRealAgreement(lang, text) {
    const userQuestionnaire = getQuestionnaire()
    const selected = wx.getStorageSync('dh_selected_real_match') || null
    const cache = wx.getStorageSync('dh_real_matches_cache') || []

    let rawMatch = null

    if (selected && (selected.id === this.matchId || selected.candidateOpenid === this.matchId)) {
      rawMatch = selected
    }

    if (!rawMatch && Array.isArray(cache)) {
      rawMatch = cache.find(item => {
        return item.id === this.matchId || item.candidateOpenid === this.matchId
      })
    }

    if (rawMatch) {
      const match = normalizeMatch(rawMatch, lang, text, 'real')
      const agreement = buildAgreement(userQuestionnaire, match, lang, text)

      this.setData({
        match,
        agreement
      })

      return
    }

    this.fetchRealMatchFromCloud(lang, text)
  },

  fetchRealMatchFromCloud(lang, text) {
    if (!wx.cloud || !wx.cloud.callFunction) {
      wx.showToast({
        title: text.noMatch,
        icon: 'none'
      })
      return
    }

    this.setData({
      loading: true
    })

    wx.cloud.callFunction({
      name: 'getRealMatches',
      data: {
        lang,
        limit: 50
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || text.noMatch,
            icon: 'none'
          })
          return
        }

        const matches = result.matches || []
        const rawMatch = matches.find(item => {
          return item.id === this.matchId || item.candidateOpenid === this.matchId
        })

        if (!rawMatch) {
          wx.showToast({
            title: text.noMatch,
            icon: 'none'
          })

          this.setData({
            match: null,
            agreement: null
          })

          return
        }

        wx.setStorageSync('dh_selected_real_match', rawMatch)
        wx.setStorageSync('dh_real_matches_cache', matches)

        const userQuestionnaire = getQuestionnaire()
        const match = normalizeMatch(rawMatch, lang, text, 'real')
        const agreement = buildAgreement(userQuestionnaire, match, lang, text)

        this.setData({
          match,
          agreement
        })
      },
      fail: (err) => {
        console.error('getRealMatches for agreement failed:', err)

        wx.showToast({
          title: text.noMatch,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  loadDemoAgreement(lang, text) {
    const questionnaire = getQuestionnaire()
    const matches = calculateAllMatches(questionnaire, roommateCandidates, lang)
    const rawMatch = matches.find(item => item.id === this.matchId) || matches[0] || null

    if (!rawMatch) {
      this.setData({
        match: null,
        agreement: null
      })

      return
    }

    const match = normalizeMatch(
      Object.assign({}, rawMatch, {
        livingType: 'school_dorm'
      }),
      lang,
      text,
      'demo'
    )

    const agreement = buildAgreement(questionnaire, match, lang, text)

    this.setData({
      match,
      agreement
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.loadAgreement()
  },

  copyAgreement() {
    if (!this.guardProfileAndQuestionnaire()) return
    if (!this.data.agreement || !this.data.agreement.plainText) return

    wx.setClipboardData({
      data: this.data.agreement.plainText,
      success: () => {
        wx.showToast({
          title: this.data.text.copied,
          icon: 'success'
        })
      }
    })
  },

  goBack() {
    wx.navigateBack()
  }
})