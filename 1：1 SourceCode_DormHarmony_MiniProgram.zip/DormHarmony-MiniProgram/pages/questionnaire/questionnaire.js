const app = getApp()

let i18n = {}
let storage = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  storage = require('../../utils/storage')
} catch (e) {
  storage = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const saveQuestionnaireLocal =
  storage.saveQuestionnaire ||
  function (data) {
    wx.setStorageSync('dh_questionnaire', data)
  }

const getQuestionnaire =
  storage.getQuestionnaire ||
  function () {
    return wx.getStorageSync('dh_questionnaire') || {}
  }

const pageText = {
  zh: {
    eyebrow: '生活习惯问卷',
    title: '完善生活习惯画像',
    desc: '这份问卷会影响真实匹配结果、冲突雷达和建议沟通话题。',
    languageButton: 'EN',
    bearName: '哈米熊',
    bearSpeech: '问卷会同步到云端，用于真实用户匹配。学校宿舍先按同性筛选，校外合租会根据双方偏好筛选。',
    saveDraft: '保存问卷',
    saveAndMatch: '保存并查看匹配',
    saveSuccess: '问卷已保存',
    saveFailed: '保存失败，请稍后再试',
    maxHint: '已达可选上限',
    openQuestion: '你最不能接受的舍友行为是什么？',
    openQuestionPlaceholder: '例如：凌晨外放视频、未经同意带访客、长期不打扫公共区域……'
  },

  en: {
    eyebrow: 'Lifestyle Questionnaire',
    title: 'Complete Your Living Profile',
    desc: 'This questionnaire affects real-user matching, conflict radar and suggested communication topics.',
    languageButton: '中文',
    bearName: 'Harmony Bear',
    bearSpeech: 'Your questionnaire will be synced to the cloud for real-user matching. School dorms use same-gender filtering; off-campus housing uses mutual preference.',
    saveDraft: 'Save Questionnaire',
    saveAndMatch: 'Save & View Matches',
    saveSuccess: 'Questionnaire saved',
    saveFailed: 'Save failed. Please try again later.',
    maxHint: 'Maximum selection reached',
    openQuestion: 'What roommate behavior can you never accept?',
    openQuestionPlaceholder: 'For example: loud videos at night, unannounced visitors, never cleaning shared areas...'
  }
}

const OPTION_LIBRARY = {
  sleepOptions: [
    { value: '22:30', zh: '23:00 前睡', en: 'Sleep before 23:00' },
    { value: '23:30', zh: '23:00 - 00:00', en: 'Sleep at 23:00 - 00:00' },
    { value: '00:30', zh: '00:00 - 01:00', en: 'Sleep at 00:00 - 01:00' },
    { value: '01:30', zh: '01:00 后', en: 'Sleep after 01:00' }
  ],

  wakeOptions: [
    { value: '06:30', zh: '07:00 前', en: 'Wake before 07:00' },
    { value: '07:30', zh: '07:00 - 08:00', en: 'Wake at 07:00 - 08:00' },
    { value: '08:30', zh: '08:00 - 09:00', en: 'Wake at 08:00 - 09:00' },
    { value: '09:30', zh: '09:00 后', en: 'Wake after 09:00' }
  ],

  lightsOffOptions: [
    { value: '22:45', zh: '23:00 前熄灯', en: 'Lights off before 23:00' },
    { value: '23:45', zh: '23:00 - 00:00', en: 'Lights off at 23:00 - 00:00' },
    { value: '00:45', zh: '00:00 - 01:00', en: 'Lights off at 00:00 - 01:00' },
    { value: '01:30', zh: '01:00 后也可接受', en: 'Can accept after 01:00' }
  ],

  noiseOptions: [
    { value: '1', zh: '非常敏感', en: 'Very sensitive' },
    { value: '2', zh: '比较敏感', en: 'Quite sensitive' },
    { value: '3', zh: '一般', en: 'Neutral' },
    { value: '4', zh: '比较能接受', en: 'Fairly tolerant' },
    { value: '5', zh: '完全不介意', en: 'Very tolerant' }
  ],

  hygieneOptions: [
    { value: '1', zh: '随性即可', en: 'Quite relaxed' },
    { value: '2', zh: '基本整洁', en: 'Basically tidy' },
    { value: '3', zh: '希望比较整洁', en: 'Prefer fairly tidy' },
    { value: '4', zh: '很在意整洁', en: 'Care a lot about cleanliness' },
    { value: '5', zh: '非常严格', en: 'Very strict' }
  ],

  acOptions: [
    { value: '20', zh: '20℃', en: '20℃' },
    { value: '22', zh: '22℃', en: '22℃' },
    { value: '24', zh: '24℃', en: '24℃' },
    { value: '26', zh: '26℃', en: '26℃' },
    { value: '28', zh: '28℃ / 更少开空调', en: '28℃ / Less AC' }
  ],

  visitorOptions: [
    { value: '1', zh: '基本不接受', en: 'Rarely accept visitors' },
    { value: '2', zh: '需要提前说明', en: 'Need prior notice' },
    { value: '3', zh: '偶尔可以', en: 'Occasionally okay' },
    { value: '4', zh: '比较开放', en: 'Quite open' },
    { value: '5', zh: '非常开放', en: 'Very open' }
  ],

  socialOptions: [
    { value: '1', zh: '非常安静独处型', en: 'Very private' },
    { value: '2', zh: '偏安静型', en: 'Quite quiet' },
    { value: '3', zh: '平衡型', en: 'Balanced' },
    { value: '4', zh: '偏社交型', en: 'Quite social' },
    { value: '5', zh: '非常外向热闹型', en: 'Very social' }
  ],

  studyOptions: [
    { value: '2', zh: '希望宿舍以安静学习为主', en: 'Prefer a quiet study-oriented room' },
    { value: '3', zh: '希望学习与娱乐区分清楚', en: 'Prefer separating study and entertainment' },
    { value: '4', zh: '比较灵活', en: 'Flexible' },
    { value: '5', zh: '更偏轻松娱乐', en: 'More relaxed / entertainment-oriented' }
  ],

  mbtiOptions: [
    { value: 'INTJ', zh: 'INTJ', en: 'INTJ' },
    { value: 'INTP', zh: 'INTP', en: 'INTP' },
    { value: 'ENTJ', zh: 'ENTJ', en: 'ENTJ' },
    { value: 'ENTP', zh: 'ENTP', en: 'ENTP' },
    { value: 'INFJ', zh: 'INFJ', en: 'INFJ' },
    { value: 'INFP', zh: 'INFP', en: 'INFP' },
    { value: 'ENFJ', zh: 'ENFJ', en: 'ENFJ' },
    { value: 'ENFP', zh: 'ENFP', en: 'ENFP' },
    { value: 'ISTJ', zh: 'ISTJ', en: 'ISTJ' },
    { value: 'ISFJ', zh: 'ISFJ', en: 'ISFJ' },
    { value: 'ESTJ', zh: 'ESTJ', en: 'ESTJ' },
    { value: 'ESFJ', zh: 'ESFJ', en: 'ESFJ' },
    { value: 'ISTP', zh: 'ISTP', en: 'ISTP' },
    { value: 'ISFP', zh: 'ISFP', en: 'ISFP' },
    { value: 'ESTP', zh: 'ESTP', en: 'ESTP' },
    { value: 'ESFP', zh: 'ESFP', en: 'ESFP' }
  ],

  dormVibeOptions: [
    { value: '安静学习型', zh: '安静学习型', en: 'Quiet Study Dorm' },
    { value: '整洁极简型', zh: '整洁极简型', en: 'Clean & Minimal Dorm' },
    { value: '社交活力型', zh: '社交活力型', en: 'Social Dorm' },
    { value: '自由随和型', zh: '自由随和型', en: 'Flexible Dorm' },
    { value: '自律规律型', zh: '自律规律型', en: 'Gym & Routine Dorm' }
  ],

  lifestyleTagOptions: [
    { value: '夜猫子', zh: '夜猫子', en: 'Night Owl' },
    { value: '早睡党', zh: '早睡党', en: 'Early Sleeper' },
    { value: '健身党', zh: '健身党', en: 'Gym Person' },
    { value: '咖啡党', zh: '咖啡党', en: 'Coffee Lover' },
    { value: '游戏党', zh: '游戏党', en: 'Gamer' },
    { value: '追剧党', zh: '追剧党', en: 'Drama Fan' },
    { value: '图书馆型', zh: '图书馆型', en: 'Library Type' },
    { value: '宿舍学习型', zh: '宿舍学习型', en: 'Study-in-room Type' },
    { value: '外卖频繁', zh: '外卖频繁', en: 'Frequent Takeout' },
    { value: '气味敏感', zh: '气味敏感', en: 'Sensitive to Smell' },
    { value: '噪音敏感', zh: '噪音敏感', en: 'Sensitive to Noise' },
    { value: '收纳控', zh: '收纳控', en: 'Organised Person' }
  ],

  redFlagOptions: [
    { value: '凌晨外放视频', zh: '凌晨外放视频', en: 'Playing videos loudly at night' },
    { value: '公共区域长期脏乱', zh: '公共区域长期脏乱', en: 'Leaving shared area messy' },
    { value: '未经同意带访客', zh: '未经同意带访客', en: 'Bringing visitors without notice' },
    { value: '乱动他人物品', zh: '乱动他人物品', en: 'Touching others’ belongings' },
    { value: '拖欠公共费用', zh: '拖欠公共费用', en: 'Delaying shared payments' },
    { value: '冷暴力不沟通', zh: '冷暴力不沟通', en: 'Avoiding communication' },
    { value: '抽烟/异味严重', zh: '抽烟/异味严重', en: 'Smoking / strong odor' }
  ],

  greenFlagOptions: [
    { value: '主动沟通', zh: '主动沟通', en: 'Communicates proactively' },
    { value: '按时打扫', zh: '按时打扫', en: 'Cleans regularly' },
    { value: '尊重安静时间', zh: '尊重安静时间', en: 'Respects quiet time' },
    { value: '访客提前说明', zh: '访客提前说明', en: 'Gives notice before visitors' },
    { value: '公共区域整洁', zh: '公共区域整洁', en: 'Keeps shared space tidy' },
    { value: '费用分摊清楚', zh: '费用分摊清楚', en: 'Clear about cost sharing' },
    { value: '边界感清晰', zh: '边界感清晰', en: 'Has clear boundaries' }
  ]
}

function buildLocalizedOptions(key, lang, selectedValues) {
  const selected = Array.isArray(selectedValues)
    ? selectedValues.map(item => String(item))
    : [String(selectedValues || '')]

  return (OPTION_LIBRARY[key] || []).map(item => {
    const value = String(item.value)

    return {
      value,
      label: lang === 'zh' ? item.zh : item.en,
      selected: selected.indexOf(value) > -1
    }
  })
}

function getLabel(key, value, lang) {
  const list = OPTION_LIBRARY[key] || []
  const target = String(value || '')

  for (let i = 0; i < list.length; i++) {
    const item = list[i]
    if (String(item.value) === target) {
      return lang === 'zh' ? item.zh : item.en
    }
  }

  return target
}

function getZhLabel(key, value) {
  const list = OPTION_LIBRARY[key] || []
  const target = String(value || '')

  for (let i = 0; i < list.length; i++) {
    const item = list[i]
    if (String(item.value) === target) {
      return item.zh
    }
  }

  return target
}

function findValueFromSaved(key, raw) {
  if (raw === undefined || raw === null || raw === '') return ''

  const list = OPTION_LIBRARY[key] || []
  const text = String(raw)

  for (let i = 0; i < list.length; i++) {
    const item = list[i]
    const value = String(item.value)

    if (
      value === text ||
      String(item.zh) === text ||
      String(item.en) === text ||
      text.indexOf(value) > -1
    ) {
      return value
    }
  }

  return ''
}

function findArrayValuesFromSaved(key, rawList) {
  if (!Array.isArray(rawList)) return []

  return rawList
    .map(item => findValueFromSaved(key, item))
    .filter(Boolean)
}

function getDefaultForm() {
  return {
    sleepTime: '23:30',
    wakeTime: '07:30',
    lightsOffTime: '23:45',
    noiseTolerance: '2',
    cleanliness: '4',
    acTemp: '24',
    visitorAcceptance: '2',
    socialTendency: '2',
    studySpacePreference: '3',
    mbti: 'INTJ',
    dormVibe: '安静学习型',
    lifestyleTags: [],
    redFlags: [],
    greenFlags: [],
    unacceptableBehavior: ''
  }
}

function buildOptionsData(form, lang) {
  return {
    sleepOptions: buildLocalizedOptions('sleepOptions', lang, form.sleepTime),
    wakeOptions: buildLocalizedOptions('wakeOptions', lang, form.wakeTime),
    lightsOffOptions: buildLocalizedOptions('lightsOffOptions', lang, form.lightsOffTime),
    noiseOptions: buildLocalizedOptions('noiseOptions', lang, form.noiseTolerance),
    hygieneOptions: buildLocalizedOptions('hygieneOptions', lang, form.cleanliness),
    acOptions: buildLocalizedOptions('acOptions', lang, form.acTemp),
    visitorOptions: buildLocalizedOptions('visitorOptions', lang, form.visitorAcceptance),
    socialOptions: buildLocalizedOptions('socialOptions', lang, form.socialTendency),
    studyOptions: buildLocalizedOptions('studyOptions', lang, form.studySpacePreference),
    mbtiOptions: buildLocalizedOptions('mbtiOptions', lang, form.mbti),
    dormVibeOptions: buildLocalizedOptions('dormVibeOptions', lang, form.dormVibe),
    lifestyleTagOptions: buildLocalizedOptions('lifestyleTagOptions', lang, form.lifestyleTags),
    redFlagOptions: buildLocalizedOptions('redFlagOptions', lang, form.redFlags),
    greenFlagOptions: buildLocalizedOptions('greenFlagOptions', lang, form.greenFlags)
  }
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    sleepOptions: [],
    wakeOptions: [],
    lightsOffOptions: [],
    noiseOptions: [],
    hygieneOptions: [],
    acOptions: [],
    visitorOptions: [],
    socialOptions: [],
    studyOptions: [],
    mbtiOptions: [],
    dormVibeOptions: [],
    lifestyleTagOptions: [],
    redFlagOptions: [],
    greenFlagOptions: [],

    form: getDefaultForm(),
    saving: false
  },

  onLoad() {
    if (!this.guardProfileCompleted()) {
      return
    }

    this.refreshPage(true)
  },

  onShow() {
    if (!this.guardProfileCompleted()) {
      return
    }

    this.refreshPage(false)

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  refreshPage(loadSaved) {
    const lang = getCurrentLang()
    const text = pageText[lang]
    let form = this.data.form || getDefaultForm()

    if (loadSaved) {
      const saved = getQuestionnaire() || {}

      form = Object.assign(getDefaultForm(), {
        sleepTime: findValueFromSaved('sleepOptions', saved.sleepTimeCode || saved.sleepTime) || '23:30',
        wakeTime: findValueFromSaved('wakeOptions', saved.wakeTimeCode || saved.wakeTime) || '07:30',
        lightsOffTime: findValueFromSaved('lightsOffOptions', saved.lightsOffCode || saved.lightsOffTime || saved.lightsOff) || '23:45',
        noiseTolerance: findValueFromSaved('noiseOptions', saved.noiseTolerance) || '2',
        cleanliness: findValueFromSaved('hygieneOptions', saved.cleanliness) || '4',
        acTemp: findValueFromSaved('acOptions', saved.acTemp || saved.acTemperature) || '24',
        visitorAcceptance: findValueFromSaved('visitorOptions', saved.visitorAcceptance || saved.visitorBoundary) || '2',
        socialTendency: findValueFromSaved('socialOptions', saved.socialTendency || saved.socialStyle) || '2',
        studySpacePreference: findValueFromSaved('studyOptions', saved.studySpacePreference || saved.spacePreference || saved.studySpace) || '3',
        mbti: findValueFromSaved('mbtiOptions', saved.mbti) || 'INTJ',
        dormVibe: findValueFromSaved('dormVibeOptions', saved.dormVibe) || '安静学习型',
        lifestyleTags: findArrayValuesFromSaved('lifestyleTagOptions', saved.lifestyleTags || []),
        redFlags: findArrayValuesFromSaved('redFlagOptions', saved.redFlags || []),
        greenFlags: findArrayValuesFromSaved('greenFlagOptions', saved.greenFlags || []),
        unacceptableBehavior: saved.unacceptableBehavior || ''
      })
    }

    this.setData(
      Object.assign(
        {
          lang,
          text,
          form
        },
        buildOptionsData(form, lang)
      )
    )
  },

  updateFormAndOptions(nextForm) {
    const lang = this.data.lang

    this.setData(
      Object.assign(
        {
          form: nextForm
        },
        buildOptionsData(nextForm, lang)
      )
    )
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'
    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    const text = pageText[nextLang]
    const form = this.data.form

    this.setData(
      Object.assign(
        {
          lang: nextLang,
          text
        },
        buildOptionsData(form, nextLang)
      )
    )
  },

  selectSingle(e) {
    const dataset = e.currentTarget.dataset
    const field = dataset.fieldName || dataset.fieldname || dataset.field
    const value = String(dataset.value)

    if (!field) return

    const nextForm = Object.assign({}, this.data.form, {
      [field]: value
    })

    this.updateFormAndOptions(nextForm)
  },

  toggleMulti(e) {
    const dataset = e.currentTarget.dataset
    const field = dataset.fieldName || dataset.fieldname || dataset.field
    const value = String(dataset.value)
    const max = Number(dataset.max || 99)

    if (!field) return

    const current = Array.isArray(this.data.form[field])
      ? this.data.form[field].map(item => String(item))
      : []

    const nextList = current.slice()
    const index = nextList.indexOf(value)

    if (index > -1) {
      nextList.splice(index, 1)
    } else {
      if (nextList.length >= max) {
        wx.showToast({
          title: this.data.text.maxHint,
          icon: 'none'
        })
        return
      }

      nextList.push(value)
    }

    const nextForm = Object.assign({}, this.data.form, {
      [field]: nextList
    })

    this.updateFormAndOptions(nextForm)
  },

  onInput(e) {
    const dataset = e.currentTarget.dataset
    const field = dataset.fieldName || dataset.fieldname || dataset.field
    const value = e.detail.value

    if (!field) return

    const nextForm = Object.assign({}, this.data.form, {
      [field]: value
    })

    this.updateFormAndOptions(nextForm)
  },

  buildPayload() {
    const form = this.data.form
    const lang = this.data.lang

    return {
      sleepTimeCode: form.sleepTime,
      sleepTime: form.sleepTime,

      wakeTimeCode: form.wakeTime,
      wakeTime: form.wakeTime,

      lightsOffCode: form.lightsOffTime,
      lightsOffTime: form.lightsOffTime,
      lightsOff: form.lightsOffTime,

      noiseTolerance: Number(form.noiseTolerance),
      noiseToleranceLabel: getLabel('noiseOptions', form.noiseTolerance, lang),

      cleanliness: Number(form.cleanliness),
      cleanlinessLabel: getLabel('hygieneOptions', form.cleanliness, lang),

      acTemp: form.acTemp,
      acTemperature: `${form.acTemp}°C`,

      visitorAcceptance: Number(form.visitorAcceptance),
      visitorBoundary: getLabel('visitorOptions', form.visitorAcceptance, lang),

      socialTendency: Number(form.socialTendency),
      socialStyle: Number(form.socialTendency),

      studySpacePreference: getLabel('studyOptions', form.studySpacePreference, lang),
      studySpace: getLabel('studyOptions', form.studySpacePreference, lang),
      spacePreference: Number(form.studySpacePreference),

      mbti: form.mbti,
      dormVibe: form.dormVibe,

      lifestyleTags: form.lifestyleTags,
      lifestyleTagLabels: form.lifestyleTags.map(item => getLabel('lifestyleTagOptions', item, lang)),

      redFlags: form.redFlags,
      redFlagLabels: form.redFlags.map(item => getLabel('redFlagOptions', item, lang)),

      greenFlags: form.greenFlags,
      greenFlagLabels: form.greenFlags.map(item => getLabel('greenFlagOptions', item, lang)),

      unacceptableBehavior: form.unacceptableBehavior,

      display: {
        sleepTime: getZhLabel('sleepOptions', form.sleepTime),
        wakeTime: getZhLabel('wakeOptions', form.wakeTime),
        lightsOffTime: getZhLabel('lightsOffOptions', form.lightsOffTime),
        noiseTolerance: getZhLabel('noiseOptions', form.noiseTolerance),
        cleanliness: getZhLabel('hygieneOptions', form.cleanliness),
        acTemperature: getZhLabel('acOptions', form.acTemp),
        visitorAcceptance: getZhLabel('visitorOptions', form.visitorAcceptance),
        socialStyle: getZhLabel('socialOptions', form.socialTendency),
        spacePreference: getZhLabel('studyOptions', form.studySpacePreference)
      }
    }
  },

  saveQuestionnaireToCloud(payload, callback) {
    if (!wx.cloud || !wx.cloud.callFunction) {
      if (typeof callback === 'function') {
        callback(false, {
          message: this.data.text.saveFailed
        })
      }

      return
    }

    this.setData({
      saving: true
    })

    wx.cloud.callFunction({
      name: 'saveQuestionnaire',
      data: {
        questionnaire: payload
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          if (typeof callback === 'function') {
            callback(false, result)
          }

          return
        }

        if (result.questionnaire) {
          saveQuestionnaireLocal(result.questionnaire)
        }

        if (typeof callback === 'function') {
          callback(true, result)
        }
      },
      fail: (err) => {
        console.error('saveQuestionnaire failed:', err)

        if (typeof callback === 'function') {
          callback(false, err)
        }
      },
      complete: () => {
        this.setData({
          saving: false
        })
      }
    })
  },

  saveDraft() {
    if (!this.guardProfileCompleted()) return

    const payload = this.buildPayload()

    saveQuestionnaireLocal(payload)

    this.saveQuestionnaireToCloud(payload, (success, result) => {
      if (!success) {
        wx.showToast({
          title: result.message || this.data.text.saveFailed,
          icon: 'none'
        })
        return
      }

      wx.showToast({
        title: this.data.text.saveSuccess,
        icon: 'success'
      })
    })
  },

  saveAndMatch() {
    if (!this.guardProfileCompleted()) return

    const payload = this.buildPayload()

    saveQuestionnaireLocal(payload)

    this.saveQuestionnaireToCloud(payload, (success, result) => {
      if (!success) {
        wx.showToast({
          title: result.message || this.data.text.saveFailed,
          icon: 'none'
        })
        return
      }

      wx.showToast({
        title: this.data.text.saveSuccess,
        icon: 'success'
      })

      setTimeout(() => {
        wx.switchTab({
          url: '/pages/matches/matches'
        })
      }, 300)
    })
  }
})