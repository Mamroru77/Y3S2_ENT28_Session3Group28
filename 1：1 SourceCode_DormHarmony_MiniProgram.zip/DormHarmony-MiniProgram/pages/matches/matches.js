const app = getApp()

let auth = {}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const {
  getCurrentLang,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getQuestionnaire
} = require('../../utils/storage')

const {
  roommateCandidates
} = require('../../utils/mockData')

const {
  defaultAnswers,
  calculateAllMatches
} = require('../../utils/matching')

const pageText = {
  zh: {
    eyebrow: '舍友匹配',
    title: '匹配',
    desc: '根据你的生活习惯、边界偏好、住宿场景、性别规则和信誉机制生成推荐。',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '真实匹配会优先从已完成资料和问卷的用户中筛选。学校宿舍默认同性匹配；校外合租则使用双方都接受的性别偏好。',

    realModeTitle: '真实用户匹配',
    demoModeTitle: '演示候选人',
    realModeDesc: '以下候选人来自真实用户池。',
    demoModeDesc: '当前真实用户池不足，系统暂时展示演示候选人，便于体验完整流程。',

    bestMatch: '推荐匹配',
    reputation: '信誉分',
    viewDetail: '查看详情',
    noQuestionnaireTitle: '还没有问卷数据',
    noQuestionnaireDesc: '请先完成生活习惯问卷，系统才能进行真实用户匹配。',
    updateQuestionnaire: '更新问卷',
    score: '匹配分',
    riskHint: '风险提示',
    strengthHint: '优势提示',
    needQuestionnaire: '请先完成生活习惯问卷',

    loading: '正在计算匹配...',
    realEmptyTitle: '暂无兼容的真实用户',
    realEmptyDesc: '可能是当前真实用户不足，或住宿场景 / 性别偏好暂未互相兼容。你可以邀请队友填写资料和问卷后再测试。',

    realBadge: '真实',
    demoBadge: '演示',
    networkError: '真实匹配加载失败，已切换到演示模式'
  },

  en: {
    eyebrow: 'Roommate Matching',
    title: 'Matches',
    desc: 'Recommendations are generated from lifestyle habits, boundaries, living scenario, gender rules and reputation signals.',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'Real matching first searches users with completed profiles and questionnaires. School dorms use same-gender matching; off-campus housing uses mutual gender preference.',

    realModeTitle: 'Real User Matches',
    demoModeTitle: 'Demo Candidates',
    realModeDesc: 'The following candidates come from the real user pool.',
    demoModeDesc: 'The real user pool is currently insufficient, so demo candidates are shown to support full product testing.',

    bestMatch: 'Recommended Match',
    reputation: 'Reputation',
    viewDetail: 'View Detail',
    noQuestionnaireTitle: 'No questionnaire yet',
    noQuestionnaireDesc: 'Please complete the lifestyle questionnaire before real-user matching.',
    updateQuestionnaire: 'Update Questionnaire',
    score: 'Match Score',
    riskHint: 'Risk Hint',
    strengthHint: 'Strength Hint',
    needQuestionnaire: 'Please complete the lifestyle questionnaire first',

    loading: 'Calculating matches...',
    realEmptyTitle: 'No compatible real users yet',
    realEmptyDesc: 'The real user pool may be too small, or living scenario / gender preferences may not be mutually compatible. Invite teammates to complete profiles and questionnaires, then test again.',

    realBadge: 'Real',
    demoBadge: 'Demo',
    networkError: 'Real matching failed. Demo mode is used instead.'
  }
}

function hasValidQuestionnaire() {
  const questionnaire = getQuestionnaire()
  return !!(questionnaire && Object.keys(questionnaire).length > 0)
}

function shortSchoolName(school) {
  const value = String(school || '')

  const map = [
    ['International Business School Suzhou', 'IBSS'],
    ['School of Advanced Technology', 'SAT'],
    ['School of Intelligent Finance and Business', 'SIFB'],
    ['School of Intelligent Manufacturing Ecosystem', 'SIME'],
    ['School of AI and Advanced Computing', 'AI & Advanced Computing'],
    ['School of Internet of Things', 'IoT'],
    ['School of Humanities and Social Sciences', 'HSS'],
    ['School of Mathematics and Physics', 'Maths & Physics'],
    ['Academy of Film and Creative Technology', 'AFCT'],
    ['XJTLU Wisdom Lake Academy of Pharmacy', 'Wisdom Lake Pharmacy']
  ]

  const found = map.find(item => value.indexOf(item[0]) > -1)

  return found ? found[1] : value
}

function shortProgrammeName(programme, programmeCode) {
  const value = String(programme || '')
  const code = String(programmeCode || '')

  const codeMap = {
    INTELLIGENT_SUPPLY_CHAIN_CE: 'Intelligent Supply Chain',
    INTELLIGENT_MANUFACTURING_ENGINEERING_CE: 'Intelligent Manufacturing',
    INTERNET_OF_THINGS_ENGINEERING_CE: 'IoT Engineering',
    INTELLIGENT_ROBOTICS_ENGINEERING_CE: 'Intelligent Robotics',
    MICROELECTRONIC_SCIENCE_ENGINEERING_CE: 'Microelectronic Science',
    DATA_SCIENCE_BIG_DATA_CE: 'Data Science & Big Data',
    ARTIFICIAL_INTELLIGENCE_TC: 'Artificial Intelligence',
    ARTIFICIAL_INTELLIGENCE_SIP: 'Artificial Intelligence',

    ACCOUNTING: 'Accounting',
    BUSINESS_ADMINISTRATION: 'Business Administration',
    ECONOMICS: 'Economics',
    ECONOMICS_FINANCE: 'Economics & Finance',
    DIGITAL_INTELLIGENT_MARKETING: 'Digital & Intelligent Marketing',
    HRM_PEOPLE_ANALYTICS: 'HRM & People Analytics',
    IMIS: 'Information Management',
    INTERNATIONAL_BUSINESS_LANGUAGE: 'International Business',

    COMPUTER_SCIENCE_TECHNOLOGY: 'Computer Science',
    DIGITAL_MEDIA_TECHNOLOGY: 'Digital Media Technology',
    ELECTRICAL_ENGINEERING: 'Electrical Engineering',
    ELECTRONIC_SCIENCE_TECHNOLOGY: 'Electronic Science',
    INFORMATION_COMPUTING_SCIENCE: 'Information & Computing',
    MECHATRONICS_ROBOTIC_SYSTEMS: 'Mechatronics & Robotics',
    TELECOMMUNICATIONS_ENGINEERING: 'Telecommunications',

    ARCHITECTURE: 'Architecture',
    CIVIL_ENGINEERING: 'Civil Engineering',
    INDUSTRIAL_DESIGN: 'Industrial Design',
    URBAN_PLANNING_DESIGN: 'Urban Planning',

    MEDIA_COMMUNICATION_STUDIES: 'Media & Communication',
    TRANSLATION_INTERPRETING: 'Translation & Interpreting',
    INTERNATIONAL_RELATIONS: 'International Relations',

    FINANCIAL_MATHEMATICS: 'Financial Mathematics',
    ACTUARIAL_SCIENCE: 'Actuarial Science',
    APPLIED_MATHEMATICS: 'Applied Mathematics',

    MATERIALS_SCIENCE_ENGINEERING: 'Materials Science',
    BIOLOGICAL_SCIENCES: 'Biological Sciences',
    BIOMEDICAL_SCIENCES: 'Biomedical Sciences',
    ENVIRONMENTAL_SCIENCE: 'Environmental Science',
    APPLIED_CHEMISTRY: 'Applied Chemistry'
  }

  if (codeMap[code]) return codeMap[code]

  return value
    .replace(' with Contemporary Entrepreneurialism', '')
    .replace(' BSc (Hons)', '')
    .replace(' BEng (Hons)', '')
    .replace(' BA (Hons)', '')
    .replace(' / Pharmacy-related programme', '')
}

function normalizeAcademicFields(item) {
  const campus = item.displayCampus || item.campus || ''
  const school = item.school || item.displaySchool || ''
  const programme = item.programme || item.major || item.displayMajor || ''
  const programmeCode = item.programmeCode || ''

  const schoolShort = shortSchoolName(school)
  const programmeShort = shortProgrammeName(programme, programmeCode)

  const academicLine = [
    item.year || '',
    campus,
    schoolShort
  ].filter(Boolean).join(' · ')

  const programmeLine = programmeShort || programme || ''

  return {
    campus,
    school,
    programme,
    programmeCode,
    schoolShort,
    programmeShort,
    academicLine,
    programmeLine
  }
}

function decorateMatches(matches, mode, lang) {
  return (matches || []).map(item => {
    const score = Number(item.score || 0)
    const academic = normalizeAcademicFields(item)

    return Object.assign({}, item, {
      matchMode: mode,
      isRealUser: mode === 'real',
      modeLabel: mode === 'real'
        ? pageText[lang].realBadge
        : pageText[lang].demoBadge,

      scoreClass: item.scoreClass || (score >= 85 ? 'high' : score >= 70 ? 'medium' : 'low'),
      scoreStyle: item.scoreStyle || `width: ${score}%;`,

      displayCampus: academic.campus,
      displaySchool: academic.school,
      displayMajor: academic.programme,
      schoolShortText: academic.schoolShort,
      programmeShortText: academic.programmeShort,
      academicLine: academic.academicLine,
      programmeLine: academic.programmeLine,

      displayTags: Array.isArray(item.displayTags) ? item.displayTags : [],

      strengths: Array.isArray(item.strengths) && item.strengths.length
        ? item.strengths
        : [lang === 'zh' ? '该候选人资料较完整，可进一步沟通。' : 'This candidate has a complete profile and is worth discussing.'],

      risks: Array.isArray(item.risks) && item.risks.length
        ? item.risks
        : [lang === 'zh' ? '建议进一步沟通作息、卫生和访客规则。' : 'Further discussion on schedule, cleaning and visitors is recommended.']
    })
  })
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    matches: [],
    hasQuestionnaire: false,

    loading: false,
    mode: 'demo',
    modeTitle: '',
    modeDesc: '',

    realEmpty: false
  },

  onLoad() {
    if (!this.guardProfileCompleted()) {
      return
    }

    this.loadMatches()
  },

  onShow() {
    if (!this.guardProfileCompleted()) {
      return
    }

    this.loadMatches()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  loadMatches() {
    const lang = getCurrentLang()
    const text = pageText[lang]
    const validQuestionnaire = hasValidQuestionnaire()

    this.setData({
      lang,
      text,
      hasQuestionnaire: validQuestionnaire
    })

    if (!validQuestionnaire) {
      this.loadDemoMatches(true)
      return
    }

    this.loadRealMatches()
  },

  loadRealMatches() {
    if (!wx.cloud || !wx.cloud.callFunction) {
      this.loadDemoMatches(true)
      return
    }

    const lang = getCurrentLang()

    this.setData({
      loading: true,
      realEmpty: false
    })

    wx.cloud.callFunction({
      name: 'getRealMatches',
      data: {
        lang,
        limit: 20
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          console.warn('getRealMatches returned not ok:', result)
          this.loadDemoMatches(true)
          return
        }

        const realMatches = decorateMatches(result.matches || [], 'real', lang)

        if (realMatches.length > 0) {
          wx.setStorageSync('dh_real_matches_cache', realMatches)

          this.setData({
            matches: realMatches,
            mode: 'real',
            modeTitle: pageText[lang].realModeTitle,
            modeDesc: pageText[lang].realModeDesc,
            realEmpty: false
          })

          return
        }

        this.setData({
          realEmpty: true
        })

        this.loadDemoMatches(false)
      },
      fail: (err) => {
        console.error('getRealMatches failed:', err)

        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })

        this.loadDemoMatches(true)
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  loadDemoMatches(fromError) {
    const lang = getCurrentLang()
    const text = pageText[lang]
    const questionnaire = getQuestionnaire()
    const userAnswers = questionnaire && Object.keys(questionnaire).length > 0
      ? questionnaire
      : defaultAnswers

    const demoMatches = calculateAllMatches(userAnswers, roommateCandidates, lang)
    const decoratedDemoMatches = decorateMatches(demoMatches, 'demo', lang)

    this.setData({
      lang,
      text,
      matches: decoratedDemoMatches,
      hasQuestionnaire: !!(questionnaire && Object.keys(questionnaire).length > 0),
      mode: 'demo',
      modeTitle: text.demoModeTitle,
      modeDesc: text.demoModeDesc,
      realEmpty: !fromError && !!(questionnaire && Object.keys(questionnaire).length > 0)
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.loadMatches()
  },

  goQuestionnaire() {
    if (!this.guardProfileCompleted()) return

    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  },

  goDetail(event) {
    if (!this.guardProfileCompleted()) return

    if (!hasValidQuestionnaire()) {
      wx.showToast({
        title: this.data.text.needQuestionnaire,
        icon: 'none'
      })

      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/questionnaire/questionnaire'
        })
      }, 400)

      return
    }

    const id = event.currentTarget.dataset.id
    const mode = event.currentTarget.dataset.mode || this.data.mode || 'demo'

    if (!id) return

    const selected = this.data.matches.find(item => item.id === id || item.candidateOpenid === id)

    if (mode === 'real' && selected) {
      wx.setStorageSync('dh_selected_real_match', selected)

      wx.navigateTo({
        url: `/pages/matchDetail/matchDetail?id=${id}&mode=real`
      })

      return
    }

    wx.navigateTo({
      url: `/pages/matchDetail/matchDetail?id=${id}&mode=demo`
    })
  }
})