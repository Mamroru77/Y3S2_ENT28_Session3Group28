const app = getApp()

let auth = {}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const {
  getCurrentLang,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getUser,
  getProfile,
  getQuestionnaire
} = require('../../utils/storage')

const {
  getReputationSummary
} = require('../../utils/reputation')

const pageText = {
  zh: {
    eyebrow: 'DormHarmony',
    title: 'Boundary Card',
    desc: '这张卡片用于快速说明你的合住边界，适合截图、复制或发送给潜在舍友。',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '边界卡不是为了显得挑剔，而是为了提前减少误解。作息、卫生、访客和空间规则越清楚，合住越稳定。',

    noDataTitle: '资料还不完整',
    noDataDesc: '请先完成登录、基础资料和生活习惯问卷，再生成边界卡。',
    goQuestionnaire: '去填写问卷',

    profileId: 'Profile ID',
    student: '学生',
    verified: '已认证',
    unverified: '未认证',
    reputation: '信誉分',
    profileStatus: '资料状态',
    completed: '已完善',

    academicProfile: '学术资料',
    campus: '校区',
    school: '学院',
    programme: '专业',
    fullProgramme: '完整专业名称',
    year: '年级',

    livingScenario: '住宿场景',
    genderRule: '性别匹配规则',
    schoolDorm: '学校宿舍',
    offCampus: '校外合租',
    schoolDormRule: '学校宿舍通常遵循学校男女分宿舍规则，默认只匹配同性舍友。',
    offCampusRule: '校外合租根据双方性别偏好进行双向筛选，只有互相接受时才进入匹配。',

    dormVibe: '理想宿舍氛围',
    mbti: 'MBTI',
    quietHours: '安静时间',
    sleepRoutine: '作息偏好',
    cleaning: '卫生要求',
    visitors: '访客边界',
    ac: '空调偏好',
    social: '社交倾向',
    space: '空间使用',
    noise: '噪音接受度',

    lifestyleTags: '生活方式标签',
    redFlags: '不能接受',
    greenFlags: '欣赏行为',
    unacceptable: '最不能接受的行为',

    cardGuide: '使用建议',
    cardGuideText: '你可以把这张卡发给潜在舍友，用来快速确认作息、卫生、访客、空调和公共空间规则。',

    copyCard: '复制文字版边界卡',
    copied: '已复制',
    back: '返回我的'
  },

  en: {
    eyebrow: 'DormHarmony',
    title: 'Boundary Card',
    desc: 'This card explains your shared-living boundaries. It is suitable for screenshots, copying or sending to a potential roommate.',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'A boundary card is not about being difficult. It reduces misunderstanding by making schedules, cleaning, visitors and space rules clear.',

    noDataTitle: 'Incomplete profile',
    noDataDesc: 'Please finish login, basic profile and lifestyle questionnaire before generating your card.',
    goQuestionnaire: 'Fill Questionnaire',

    profileId: 'Profile ID',
    student: 'Student',
    verified: 'Verified',
    unverified: 'Unverified',
    reputation: 'Reputation',
    profileStatus: 'Profile Status',
    completed: 'Completed',

    academicProfile: 'Academic Profile',
    campus: 'Campus',
    school: 'School',
    programme: 'Programme',
    fullProgramme: 'Full Programme',
    year: 'Year',

    livingScenario: 'Living Scenario',
    genderRule: 'Gender Matching Rule',
    schoolDorm: 'School dorm',
    offCampus: 'Off-campus housing',
    schoolDormRule: 'School dorm matching usually follows gender-separated accommodation rules and uses same-gender matching by default.',
    offCampusRule: 'Off-campus matching uses mutual gender preferences. A candidate is shown only when both sides are compatible.',

    dormVibe: 'Ideal Dorm Vibe',
    mbti: 'MBTI',
    quietHours: 'Quiet Hours',
    sleepRoutine: 'Sleep Routine',
    cleaning: 'Cleanliness',
    visitors: 'Visitor Boundary',
    ac: 'AC Preference',
    social: 'Social Style',
    space: 'Space Use',
    noise: 'Noise Tolerance',

    lifestyleTags: 'Lifestyle Tags',
    redFlags: 'Red Flags',
    greenFlags: 'Green Flags',
    unacceptable: 'Unacceptable Behavior',

    cardGuide: 'How to Use',
    cardGuideText: 'Share this card with potential roommates to quickly confirm schedule, cleanliness, visitors, AC and shared-space rules.',

    copyCard: 'Copy Text Version',
    copied: 'Copied',
    back: 'Back to Profile'
  }
}

function getStoredUser() {
  return wx.getStorageSync('dh_current_user') || null
}

function getProfileId(user) {
  if (!user) return ''

  return (
    user.profileId ||
    user.dormProfileId ||
    user.studentProfileId ||
    user.publicProfileId ||
    ''
  )
}

function shortSchoolName(school, schoolCode) {
  const code = String(schoolCode || '')
  const value = String(school || '')

  const codeMap = {
    IBSS: 'IBSS',
    SAT: 'SAT',
    DESIGN: 'Design School',
    HSS: 'HSS',
    MATH_PHYSICS: 'Maths & Physics',
    SCIENCE: 'School of Science',
    AFCT_SIP: 'AFCT',
    WLAP: 'WLAP',
    AIAC: 'AI & Advanced Computing',
    CHIPS: 'CHIPS',
    SIFB: 'SIFB',
    SIME: 'SIME',
    IOT: 'IoT School',
    ROBOTICS: 'Robotics',
    AFCT_TC: 'AFCT',
    OTHER_SIP: 'Other',
    OTHER_TC: 'Other'
  }

  if (codeMap[code]) return codeMap[code]

  const nameMap = [
    ['International Business School Suzhou', 'IBSS'],
    ['Business School', 'Business School'],
    ['School of Advanced Technology', 'SAT'],
    ['School of Intelligent Finance and Business', 'SIFB'],
    ['School of Intelligent Manufacturing Ecosystem', 'SIME'],
    ['School of AI and Advanced Computing', 'AI & Advanced Computing'],
    ['School of Internet of Things', 'IoT School'],
    ['School of Humanities and Social Sciences', 'HSS'],
    ['School of Mathematics and Physics', 'Maths & Physics'],
    ['Academy of Film and Creative Technology', 'AFCT'],
    ['XJTLU Wisdom Lake Academy of Pharmacy', 'WLAP']
  ]

  const found = nameMap.find(item => value.indexOf(item[0]) > -1)

  return found ? found[1] : value || '-'
}

function shortProgrammeName(programme, programmeCode) {
  const code = String(programmeCode || '')
  const value = String(programme || '')

  const codeMap = {
    SUPPLY_CHAIN_MANAGEMENT: 'Supply Chain Management',
    INTELLIGENT_SUPPLY_CHAIN_CE: 'Intelligent Supply Chain',
    INTELLIGENT_MANUFACTURING_ENGINEERING_CE: 'Intelligent Manufacturing',
    INTERNET_OF_THINGS_ENGINEERING_CE: 'IoT Engineering',
    INTELLIGENT_ROBOTICS_ENGINEERING_CE: 'Intelligent Robotics',
    MICROELECTRONIC_SCIENCE_ENGINEERING_CE: 'Microelectronic Science',
    DATA_SCIENCE_BIG_DATA_CE: 'Data Science & Big Data',
    ARTIFICIAL_INTELLIGENCE_TC: 'Artificial Intelligence',
    ARTIFICIAL_INTELLIGENCE_SIP: 'Artificial Intelligence',

    ACCOUNTING: 'Accounting',
    BUSINESS_ADMINISTRATION: 'Business Administration',
    ECONOMICS: 'Economics',
    ECONOMICS_FINANCE: 'Economics & Finance',
    DIGITAL_INTELLIGENT_MARKETING: 'Digital & Intelligent Marketing',
    HRM_PEOPLE_ANALYTICS: 'HRM & People Analytics',
    IMIS: 'Information Management',
    INTERNATIONAL_BUSINESS_LANGUAGE: 'International Business',

    COMPUTER_SCIENCE_TECHNOLOGY: 'Computer Science',
    DIGITAL_MEDIA_TECHNOLOGY: 'Digital Media Technology',
    ELECTRICAL_ENGINEERING: 'Electrical Engineering',
    ELECTRONIC_SCIENCE_TECHNOLOGY: 'Electronic Science',
    INFORMATION_COMPUTING_SCIENCE: 'Information & Computing',
    MECHATRONICS_ROBOTIC_SYSTEMS: 'Mechatronics & Robotics',
    TELECOMMUNICATIONS_ENGINEERING: 'Telecommunications',

    ARCHITECTURE: 'Architecture',
    CIVIL_ENGINEERING: 'Civil Engineering',
    INDUSTRIAL_DESIGN: 'Industrial Design',
    URBAN_PLANNING_DESIGN: 'Urban Planning',

    MEDIA_COMMUNICATION_STUDIES: 'Media & Communication',
    TRANSLATION_INTERPRETING: 'Translation & Interpreting',
    INTERNATIONAL_RELATIONS: 'International Relations',

    FINANCIAL_MATHEMATICS: 'Financial Mathematics',
    ACTUARIAL_SCIENCE: 'Actuarial Science',
    APPLIED_MATHEMATICS: 'Applied Mathematics',

    MATERIALS_SCIENCE_ENGINEERING: 'Materials Science',
    BIOLOGICAL_SCIENCES: 'Biological Sciences',
    BIOMEDICAL_SCIENCES: 'Biomedical Sciences',
    ENVIRONMENTAL_SCIENCE: 'Environmental Science',
    APPLIED_CHEMISTRY: 'Applied Chemistry',

    OTHER_PROGRAMME_SIP: 'Other',
    OTHER_PROGRAMME_TC: 'Other'
  }

  if (codeMap[code]) return codeMap[code]

  return value
    .replace(' with Contemporary Entrepreneurialism', '')
    .replace(' BSc (Hons)', '')
    .replace(' BEng (Hons)', '')
    .replace(' BA (Hons)', '')
    .replace(' / Pharmacy-related programme', '')
    .trim() || '-'
}

function getStoredProfile() {
  const user = getStoredUser()

  if (!user) return null

  return {
    nickname: user.nickname || '',
    university: 'XJTLU',

    campus: user.campus || '',
    campusCode: user.campusCode || '',

    school: user.school || '',
    schoolCode: user.schoolCode || '',

    programme: user.programme || user.major || '',
    programmeCode: user.programmeCode || '',

    year: user.year || '',
    major: user.programme || user.major || '',
    mbti: user.mbti || ''
  }
}

function getLivingTypeText(livingType, text) {
  if (livingType === 'off_campus') return text.offCampus
  return text.schoolDorm
}

function getGenderRuleText(livingType, text) {
  if (livingType === 'off_campus') return text.offCampusRule
  return text.schoolDormRule
}

function levelText(value, lang, type) {
  const number = Number(value)

  if (type === 'cleaning') {
    if (number >= 4) {
      return lang === 'zh'
        ? '较高，需要保持公共区域整洁'
        : 'High; shared space should stay clean'
    }

    if (number === 3) {
      return lang === 'zh'
        ? '中等，接受基本整洁'
        : 'Medium; basic cleanliness is expected'
    }

    return lang === 'zh'
      ? '较随意，但不接受长期脏乱'
      : 'Relaxed, but long-term mess is not acceptable'
  }

  if (type === 'visitor') {
    if (number >= 4) {
      return lang === 'zh'
        ? '较开放，但最好提前说明'
        : 'Flexible, but notice is preferred'
    }

    if (number === 3) {
      return lang === 'zh'
        ? '偶尔可以，需要提前沟通'
        : 'Occasionally acceptable with notice'
    }

    return lang === 'zh'
      ? '较敏感，需要提前确认'
      : 'Sensitive; confirm in advance'
  }

  if (type === 'social') {
    if (number >= 4) {
      return lang === 'zh'
        ? '偏互动型，喜欢适度交流'
        : 'Interactive; enjoys moderate communication'
    }

    if (number === 3) {
      return lang === 'zh'
        ? '中间型，可交流也需要空间'
        : 'Balanced; social but needs space'
    }

    return lang === 'zh'
      ? '偏独立，重视个人空间'
      : 'Independent; values personal space'
  }

  if (type === 'space') {
    if (number >= 4) {
      return lang === 'zh'
        ? '宿舍可适度娱乐，但需控制时间'
        : 'Entertainment is acceptable with time control'
    }

    if (number === 3) {
      return lang === 'zh'
        ? '学习和娱乐需要平衡'
        : 'Study and leisure should be balanced'
    }

    return lang === 'zh'
      ? '更偏安静学习环境'
      : 'Prefers a quiet study environment'
  }

  if (type === 'noise') {
    if (number >= 4) {
      return lang === 'zh'
        ? '对噪音较宽容'
        : 'Relatively tolerant of noise'
    }

    if (number === 3) {
      return lang === 'zh'
        ? '中等敏感'
        : 'Moderately sensitive'
    }

    return lang === 'zh'
      ? '需要较安静的环境'
      : 'Needs a quiet environment'
  }

  return '-'
}

function buildPlainText(card, text, lang) {
  const lines = []

  if (lang === 'zh') {
    lines.push('DormHarmony 宿舍边界卡')
    lines.push(`昵称：${card.nickname}`)
    lines.push(`Profile ID：${card.profileId || '-'}`)
    lines.push(`学校：${card.university}`)
    lines.push(`校区：${card.campus}`)
    lines.push(`学院：${card.schoolShort}`)
    lines.push(`专业：${card.programmeShort}`)
    lines.push(`年级：${card.year}`)
    lines.push(`住宿场景：${card.livingTypeText}`)
    lines.push(`性别匹配规则：${card.genderRuleText}`)
    lines.push(`认证状态：${card.verifiedText}`)
    lines.push(`信誉分：${card.reputationScore}/100`)
    lines.push('')
  } else {
    lines.push('DormHarmony Boundary Card')
    lines.push(`Nickname: ${card.nickname}`)
    lines.push(`Profile ID: ${card.profileId || '-'}`)
    lines.push(`University: ${card.university}`)
    lines.push(`Campus: ${card.campus}`)
    lines.push(`School: ${card.schoolShort}`)
    lines.push(`Programme: ${card.programmeShort}`)
    lines.push(`Year: ${card.year}`)
    lines.push(`Living Scenario: ${card.livingTypeText}`)
    lines.push(`Gender Matching Rule: ${card.genderRuleText}`)
    lines.push(`Verification: ${card.verifiedText}`)
    lines.push(`Reputation: ${card.reputationScore}/100`)
    lines.push('')
  }

  lines.push(`${text.dormVibe}: ${card.dormVibe}`)
  lines.push(`${text.mbti}: ${card.mbti}`)
  lines.push(`${text.quietHours}: ${card.quietHours}`)
  lines.push(`${text.sleepRoutine}: ${card.sleepRoutine}`)
  lines.push(`${text.cleaning}: ${card.cleaning}`)
  lines.push(`${text.visitors}: ${card.visitors}`)
  lines.push(`${text.ac}: ${card.ac}`)
  lines.push(`${text.social}: ${card.social}`)
  lines.push(`${text.space}: ${card.space}`)
  lines.push(`${text.noise}: ${card.noise}`)
  lines.push(`${text.lifestyleTags}: ${card.lifestyleTags.join(', ') || '-'}`)
  lines.push(`${text.greenFlags}: ${card.greenFlags.join(', ') || '-'}`)
  lines.push(`${text.redFlags}: ${card.redFlags.join(', ') || '-'}`)
  lines.push(`${text.unacceptable}: ${card.unacceptableBehavior || '-'}`)

  return lines.join('\n')
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,
    user: null,
    profile: null,
    questionnaire: null,
    card: null
  },

  onLoad() {
    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadCard()
  },

  onShow() {
    if (!this.guardProfileAndQuestionnaire()) {
      return
    }

    this.loadCard()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  guardProfileCompleted() {
    if (auth.requireProfileCompleted) {
      return auth.requireProfileCompleted()
    }

    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return false
    }

    return true
  },

  guardProfileAndQuestionnaire() {
    if (!this.guardProfileCompleted()) {
      return false
    }

    const questionnaire = getQuestionnaire()
    const hasQuestionnaire = !!(questionnaire && Object.keys(questionnaire).length > 0)

    if (!hasQuestionnaire) {
      wx.navigateTo({
        url: '/pages/questionnaire/questionnaire'
      })
      return false
    }

    return true
  },

  loadCard() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    const storedUser = getStoredUser()
    const oldUser = typeof getUser === 'function' ? getUser() : null
    const oldProfile = typeof getProfile === 'function' ? getProfile() : null

    const user = storedUser || oldUser || null
    const profile = oldProfile || getStoredProfile()
    const questionnaire = getQuestionnaire()
    const reputation = getReputationSummary(lang)

    let card = null

    if (user && profile && questionnaire) {
      const verifiedText = user.emailVerified || user.verified
        ? text.verified
        : text.unverified

      const profileId = getProfileId(user)
      const schoolShort = shortSchoolName(user.school || profile.school, user.schoolCode || profile.schoolCode)
      const programmeFull = user.programme || user.major || profile.programme || profile.major || ''
      const programmeShort = shortProgrammeName(programmeFull, user.programmeCode || profile.programmeCode)

      const livingType = user.livingType || 'school_dorm'
      const livingTypeText = getLivingTypeText(livingType, text)
      const genderRuleText = getGenderRuleText(livingType, text)

      card = {
        nickname: user.nickname || profile.nickname || text.student,
        profileId,
        email: user.email || '',
        verifiedText,
        reputationScore: user.reputationScore || reputation.score || 85,

        profileStatusText: text.completed,

        university: profile.university || 'XJTLU',
        campus: user.campus || profile.campus || '',
        campusCode: user.campusCode || profile.campusCode || '',

        school: user.school || profile.school || '',
        schoolCode: user.schoolCode || profile.schoolCode || '',
        schoolShort,

        programme: programmeFull,
        programmeCode: user.programmeCode || profile.programmeCode || '',
        programmeShort,

        year: profile.year || user.year || '',
        major: programmeFull,

        livingType,
        livingTypeText,
        genderRuleText,

        dormVibe: questionnaire.dormVibe || '-',
        mbti: questionnaire.mbti || user.mbti || '-',

        quietHours: lang === 'zh'
          ? `${questionnaire.lightsOffTime || '23:30'} 后尽量保持安静`
          : `Keep quiet after ${questionnaire.lightsOffTime || '23:30'}`,

        sleepRoutine: lang === 'zh'
          ? `通常 ${questionnaire.sleepTime || '-'} 睡，${questionnaire.wakeTime || '-'} 起`
          : `Usually sleeps at ${questionnaire.sleepTime || '-'} and wakes up at ${questionnaire.wakeTime || '-'}`,

        cleaning: levelText(questionnaire.cleanliness, lang, 'cleaning'),
        visitors: levelText(questionnaire.visitorAcceptance, lang, 'visitor'),
        ac: questionnaire.acTemperature || '-',
        social: levelText(questionnaire.socialStyle || questionnaire.socialTendency, lang, 'social'),
        space: levelText(questionnaire.spacePreference, lang, 'space'),
        noise: levelText(questionnaire.noiseTolerance, lang, 'noise'),

        lifestyleTags: questionnaire.lifestyleTags || [],
        redFlags: questionnaire.redFlags || [],
        greenFlags: questionnaire.greenFlags || [],
        unacceptableBehavior: questionnaire.unacceptableBehavior || ''
      }

      card.plainText = buildPlainText(card, text, lang)
    }

    this.setData({
      lang,
      text,
      user,
      profile,
      questionnaire,
      card
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.loadCard()
  },

  goQuestionnaire() {
    if (!this.guardProfileCompleted()) return

    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  },

  copyCard() {
    if (!this.guardProfileAndQuestionnaire()) return
    if (!this.data.card) return

    wx.setClipboardData({
      data: this.data.card.plainText,
      success: () => {
        wx.showToast({
          title: this.data.text.copied,
          icon: 'success'
        })
      }
    })
  },

  goBack() {
    wx.switchTab({
      url: '/pages/profile/profile'
    })
  }
})