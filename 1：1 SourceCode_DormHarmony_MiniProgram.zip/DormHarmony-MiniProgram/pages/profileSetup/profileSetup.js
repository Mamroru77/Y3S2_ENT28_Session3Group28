const app = getApp()

let i18n = {}
let auth = {}
let xjtluOptions = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

try {
  xjtluOptions = require('../../utils/xjtluProfileOptions')
} catch (e) {
  xjtluOptions = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const {
  campusOptions,
  getDisplayName,
  getSchoolsByCampus,
  getSchoolByCode,
  getProgrammesBySchool,
  getProgrammeByCode,
  getCampusLabels,
  getSchoolLabels,
  getProgrammeLabels
} = xjtluOptions

const pageText = {
  zh: {
    eyebrow: '基础资料',
    title: '完善你的合住画像',
    desc: '资料页已按 XJTLU 结构重构。请先选择校区，再选择对应学院和专业，系统会用于真实匹配、社区展示和沟通识别。',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: 'Campus、School 和 Programme 会严格联动。TC Campus 与 SIP Campus 的学院体系不同，不能混选。',

    nicknameLabel: '昵称',
    nicknamePlaceholder: '例如：Alex',

    genderLabel: '性别',
    livingTypeLabel: '住宿场景',
    matchGenderPreferenceLabel: '匹配性别偏好',
    schoolDormHint: '学校宿舍通常由学校按性别分配，本场景默认只匹配同性舍友。',
    offCampusHint: '校外合租会根据你和对方的性别偏好进行双向筛选，只有双方都接受时才会展示为候选人。',

    yearLabel: '年级',
    campusLabel: '校区',
    schoolLabel: '学院 / 学院体系',
    programmeLabel: '专业 / Programme',

    mbtiLabel: 'MBTI',
    bioLabel: '简单介绍',
    bioPlaceholder: '例如：作息稳定，重视边界，喜欢提前沟通规则。',

    save: '保存并继续',
    skip: '资料已保存后进入问卷',
    nicknameEmpty: '请输入昵称',
    profileRequired: '请先保存基础资料',
    saveSuccess: '资料已保存',
    saveFailed: '保存失败，请稍后再试'
  },

  en: {
    eyebrow: 'Basic Profile',
    title: 'Complete Your Living Profile',
    desc: 'The profile form now follows the XJTLU structure. Choose campus first, then the corresponding school and programme for real matching, community display and chat identification.',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'Campus, School and Programme are strictly connected. TC Campus and SIP Campus have different school structures and cannot be mixed.',

    nicknameLabel: 'Nickname',
    nicknamePlaceholder: 'e.g. Alex',

    genderLabel: 'Gender',
    livingTypeLabel: 'Living Scenario',
    matchGenderPreferenceLabel: 'Matching Gender Preference',
    schoolDormHint: 'School dorms are usually allocated by gender, so this scenario only matches same-gender roommates by default.',
    offCampusHint: 'Off-campus matching uses both users’ gender preferences. A candidate is shown only when both sides are compatible.',

    yearLabel: 'Year',
    campusLabel: 'Campus',
    schoolLabel: 'School / Academy',
    programmeLabel: 'Programme',

    mbtiLabel: 'MBTI',
    bioLabel: 'Short Bio',
    bioPlaceholder: 'e.g. Stable schedule, clear boundaries, prefer discussing rules early.',

    save: 'Save & Continue',
    skip: 'Enter Questionnaire After Saving',
    nicknameEmpty: 'Please enter your nickname',
    profileRequired: 'Please save your basic profile first',
    saveSuccess: 'Profile saved',
    saveFailed: 'Save failed. Please try again later.'
  }
}

const yearOptions = ['Year 1', 'Year 2', 'Year 3', 'Year 4', 'Master', 'PhD']

const mbtiOptions = [
  'Not sure',
  'INTJ', 'INTP', 'ENTJ', 'ENTP',
  'INFJ', 'INFP', 'ENFJ', 'ENFP',
  'ISTJ', 'ISFJ', 'ESTJ', 'ESFJ',
  'ISTP', 'ISFP', 'ESTP', 'ESFP'
]

const genderOptions = [
  {
    value: 'male',
    zh: '男',
    en: 'Male'
  },
  {
    value: 'female',
    zh: '女',
    en: 'Female'
  },
  {
    value: 'prefer_not_to_say',
    zh: '暂不说明',
    en: 'Prefer not to say'
  }
]

const livingTypeOptions = [
  {
    value: 'school_dorm',
    zh: '学校宿舍',
    en: 'School dorm'
  },
  {
    value: 'off_campus',
    zh: '校外合租',
    en: 'Off-campus housing'
  }
]

const matchGenderPreferenceOptions = [
  {
    value: 'same',
    zh: '只匹配同性',
    en: 'Same gender only'
  },
  {
    value: 'male',
    zh: '只匹配男生',
    en: 'Male only'
  },
  {
    value: 'female',
    zh: '只匹配女生',
    en: 'Female only'
  },
  {
    value: 'any',
    zh: '不限',
    en: 'No preference'
  }
]

function buildLabels(options, lang) {
  return options.map(item => lang === 'zh' ? item.zh : item.en)
}

function getOptionIndex(options, value, fallbackIndex) {
  const index = options.findIndex(item => item.value === value)
  return index >= 0 ? index : fallbackIndex
}

function getOptionValue(options, index, fallbackValue) {
  const item = options[Number(index)]
  return item ? item.value : fallbackValue
}

function getIndexByCode(list, code) {
  const index = list.findIndex(item => item.code === code)
  return index >= 0 ? index : 0
}

function normalizeCampusCode(user) {
  if (user && user.campusCode) {
    return user.campusCode
  }

  const campusText = String((user && user.campus) || '').toLowerCase()

  if (campusText.indexOf('tc') > -1 || campusText.indexOf('taicang') > -1) {
    return 'TC'
  }

  if (campusText.indexOf('sip') > -1 || campusText.indexOf('dushu') > -1 || campusText.indexOf('suzhou industrial') > -1) {
    return 'SIP'
  }

  return 'SIP'
}

function normalizeSchoolCode(user, campusCode) {
  if (user && user.schoolCode) {
    const schools = getSchoolsByCampus(campusCode)
    const exists = schools.find(item => item.code === user.schoolCode)

    if (exists) return user.schoolCode
  }

  const schoolText = String((user && user.school) || '').toLowerCase()

  if (campusCode === 'TC') {
    if (schoolText.indexOf('intelligent finance') > -1 || schoolText.indexOf('sifb') > -1) return 'SIFB'
    if (schoolText.indexOf('manufacturing') > -1 || schoolText.indexOf('sime') > -1) return 'SIME'
    if (schoolText.indexOf('robotics') > -1) return 'ROBOTICS'
    if (schoolText.indexOf('internet of things') > -1 || schoolText.indexOf('iot') > -1) return 'IOT'
    if (schoolText.indexOf('chips') > -1) return 'CHIPS'
    if (schoolText.indexOf('ai') > -1 || schoolText.indexOf('advanced computing') > -1) return 'AIAC'
    if (schoolText.indexOf('film') > -1 || schoolText.indexOf('creative') > -1) return 'AFCT_TC'

    return 'SIFB'
  }

  if (schoolText.indexOf('business') > -1 || schoolText.indexOf('ibss') > -1) return 'IBSS'
  if (schoolText.indexOf('advanced technology') > -1) return 'SAT'
  if (schoolText.indexOf('design') > -1) return 'DESIGN'
  if (schoolText.indexOf('humanities') > -1 || schoolText.indexOf('social sciences') > -1) return 'HSS'
  if (schoolText.indexOf('mathematics') > -1 || schoolText.indexOf('physics') > -1) return 'MATH_PHYSICS'
  if (schoolText.indexOf('science') > -1) return 'SCIENCE'
  if (schoolText.indexOf('film') > -1 || schoolText.indexOf('creative') > -1) return 'AFCT_SIP'
  if (schoolText.indexOf('pharmacy') > -1) return 'WLAP'

  return 'IBSS'
}

function normalizeProgrammeCode(user, schoolCode) {
  const programmes = getProgrammesBySchool(schoolCode)

  if (user && user.programmeCode) {
    const exists = programmes.find(item => item.code === user.programmeCode)

    if (exists) return user.programmeCode
  }

  const programmeText = String((user && (user.programme || user.major)) || '').toLowerCase()

  if (schoolCode === 'SIFB') {
    return 'INTELLIGENT_SUPPLY_CHAIN_CE'
  }

  if (schoolCode === 'IBSS') {
    if (programmeText.indexOf('accounting') > -1) return 'ACCOUNTING'
    if (programmeText.indexOf('economics and finance') > -1) return 'ECONOMICS_FINANCE'
    if (programmeText.indexOf('economics') > -1) return 'ECONOMICS'
    if (programmeText.indexOf('marketing') > -1) return 'DIGITAL_INTELLIGENT_MARKETING'
    if (programmeText.indexOf('human resource') > -1 || programmeText.indexOf('people analytics') > -1) return 'HRM_PEOPLE_ANALYTICS'
    if (programmeText.indexOf('information management') > -1) return 'IMIS'
    if (programmeText.indexOf('international business') > -1) return 'INTERNATIONAL_BUSINESS_LANGUAGE'
    return 'BUSINESS_ADMINISTRATION'
  }

  if (programmes && programmes.length > 0) {
    return programmes[0].code
  }

  return ''
}

function getCampusNameByCode(campusCode, lang) {
  const list = campusOptions || []
  const target = list.find(item => item.code === campusCode) || list[0]
  return getDisplayName(target, lang)
}

function getSchoolNameByCode(campusCode, schoolCode, lang) {
  const target = getSchoolByCode(campusCode, schoolCode)
  return getDisplayName(target, lang)
}

function getProgrammeNameByCode(schoolCode, programmeCode, lang) {
  const target = getProgrammeByCode(schoolCode, programmeCode)
  return getDisplayName(target, lang)
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    nickname: '',

    gender: 'male',
    livingType: 'school_dorm',
    matchGenderPreference: 'same',

    year: 'Year 3',

    campusCode: 'SIP',
    schoolCode: 'IBSS',
    programmeCode: 'BUSINESS_ADMINISTRATION',

    campus: 'SIP Campus',
    school: 'International Business School Suzhou',
    programme: 'Business Administration BA (Hons)',
    major: 'Business Administration BA (Hons)',

    mbti: 'Not sure',
    bio: '',

    yearOptions,
    mbtiOptions,

    genderOptionLabels: [],
    livingTypeOptionLabels: [],
    matchGenderPreferenceOptionLabels: [],

    campusOptionLabels: [],
    schoolOptionLabels: [],
    programmeOptionLabels: [],

    genderIndex: 0,
    livingTypeIndex: 0,
    matchGenderPreferenceIndex: 0,

    yearIndex: 2,
    campusIndex: 0,
    schoolIndex: 0,
    programmeIndex: 0,
    mbtiIndex: 0,

    loading: false
  },

  onLoad() {
    this.refreshLanguage()

    if (!this.guardLogin()) {
      return
    }

    this.loadCurrentUser()
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }

    if (!this.guardLogin()) {
      return
    }

    this.loadCurrentUser()
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  refreshLanguage() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    const campusCode = this.data.campusCode || 'SIP'
    const schoolCode = this.data.schoolCode || normalizeSchoolCode({}, campusCode)

    this.setData({
      lang,
      text,
      genderOptionLabels: buildLabels(genderOptions, lang),
      livingTypeOptionLabels: buildLabels(livingTypeOptions, lang),
      matchGenderPreferenceOptionLabels: buildLabels(matchGenderPreferenceOptions, lang),
      campusOptionLabels: getCampusLabels(lang),
      schoolOptionLabels: getSchoolLabels(campusCode, lang),
      programmeOptionLabels: getProgrammeLabels(schoolCode, lang),
      campus: getCampusNameByCode(campusCode, lang),
      school: getSchoolNameByCode(campusCode, schoolCode, lang),
      programme: getProgrammeNameByCode(schoolCode, this.data.programmeCode, lang),
      major: getProgrammeNameByCode(schoolCode, this.data.programmeCode, lang)
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.refreshLanguage()
  },

  loadCurrentUser() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getCurrentUser',
      success: (res) => {
        const result = res.result || {}
        const user = result.user || null

        if (!user) return

        const lang = getCurrentLang()

        const gender = user.gender || 'male'
        const livingType = user.livingType || 'school_dorm'
        const matchGenderPreference = livingType === 'school_dorm'
          ? 'same'
          : user.matchGenderPreference || 'same'

        const campusCode = normalizeCampusCode(user)
        const schoolCode = normalizeSchoolCode(user, campusCode)
        const programmeCode = normalizeProgrammeCode(user, schoolCode)

        const campusList = campusOptions || []
        const schoolList = getSchoolsByCampus(campusCode)
        const programmeList = getProgrammesBySchool(schoolCode)

        const genderIndex = getOptionIndex(genderOptions, gender, 0)
        const livingTypeIndex = getOptionIndex(livingTypeOptions, livingType, 0)
        const matchGenderPreferenceIndex = getOptionIndex(
          matchGenderPreferenceOptions,
          matchGenderPreference,
          0
        )

        const yearIndex = Math.max(yearOptions.indexOf(user.year || 'Year 3'), 0)
        const mbtiIndex = Math.max(mbtiOptions.indexOf(user.mbti || 'Not sure'), 0)

        const campusIndex = getIndexByCode(campusList, campusCode)
        const schoolIndex = getIndexByCode(schoolList, schoolCode)
        const programmeIndex = getIndexByCode(programmeList, programmeCode)

        const campus = getCampusNameByCode(campusCode, lang)
        const school = getSchoolNameByCode(campusCode, schoolCode, lang)
        const programme = getProgrammeNameByCode(schoolCode, programmeCode, lang)

        this.setData({
          nickname: user.nickname || '',

          gender,
          livingType,
          matchGenderPreference,

          genderIndex,
          livingTypeIndex,
          matchGenderPreferenceIndex,

          year: yearOptions[yearIndex],
          yearIndex,

          campusCode,
          schoolCode,
          programmeCode,

          campus,
          school,
          programme,
          major: programme,

          campusIndex,
          schoolIndex,
          programmeIndex,

          campusOptionLabels: getCampusLabels(lang),
          schoolOptionLabels: getSchoolLabels(campusCode, lang),
          programmeOptionLabels: getProgrammeLabels(schoolCode, lang),

          mbti: mbtiOptions[mbtiIndex],
          mbtiIndex,

          bio: user.bio || ''
        })

        wx.setStorageSync('dh_current_user', user)

        if (auth.updateUser) {
          auth.updateUser(user)
        } else if (app.setUserProfile) {
          app.setUserProfile(user)
        }
      },
      fail: (err) => {
        console.error('getCurrentUser failed:', err)
      }
    })
  },

  onNicknameInput(e) {
    this.setData({
      nickname: e.detail.value
    })
  },

  onGenderChange(e) {
    const index = Number(e.detail.value)
    const gender = getOptionValue(genderOptions, index, 'male')

    this.setData({
      genderIndex: index,
      gender
    })
  },

  onLivingTypeChange(e) {
    const index = Number(e.detail.value)
    const livingType = getOptionValue(livingTypeOptions, index, 'school_dorm')

    const nextData = {
      livingTypeIndex: index,
      livingType
    }

    if (livingType === 'school_dorm') {
      nextData.matchGenderPreference = 'same'
      nextData.matchGenderPreferenceIndex = 0
    }

    this.setData(nextData)
  },

  onMatchGenderPreferenceChange(e) {
    const index = Number(e.detail.value)
    const matchGenderPreference = getOptionValue(matchGenderPreferenceOptions, index, 'same')

    this.setData({
      matchGenderPreferenceIndex: index,
      matchGenderPreference
    })
  },

  onYearChange(e) {
    const index = Number(e.detail.value)

    this.setData({
      yearIndex: index,
      year: yearOptions[index]
    })
  },

  onCampusChange(e) {
    const lang = this.data.lang
    const index = Number(e.detail.value)
    const campus = (campusOptions || [])[index] || (campusOptions || [])[0]
    const campusCode = campus.code

    const schools = getSchoolsByCampus(campusCode)
    const firstSchool = schools[0]
    const schoolCode = firstSchool.code

    const programmes = getProgrammesBySchool(schoolCode)
    const firstProgramme = programmes[0]
    const programmeCode = firstProgramme.code

    const campusName = getDisplayName(campus, lang)
    const schoolName = getDisplayName(firstSchool, lang)
    const programmeName = getDisplayName(firstProgramme, lang)

    this.setData({
      campusIndex: index,
      campusCode,
      campus: campusName,

      schoolIndex: 0,
      schoolCode,
      school: schoolName,
      schoolOptionLabels: getSchoolLabels(campusCode, lang),

      programmeIndex: 0,
      programmeCode,
      programme: programmeName,
      major: programmeName,
      programmeOptionLabels: getProgrammeLabels(schoolCode, lang)
    })
  },

  onSchoolChange(e) {
    const lang = this.data.lang
    const index = Number(e.detail.value)
    const campusCode = this.data.campusCode

    const schools = getSchoolsByCampus(campusCode)
    const school = schools[index] || schools[0]
    const schoolCode = school.code

    const programmes = getProgrammesBySchool(schoolCode)
    const firstProgramme = programmes[0]
    const programmeCode = firstProgramme.code

    const schoolName = getDisplayName(school, lang)
    const programmeName = getDisplayName(firstProgramme, lang)

    this.setData({
      schoolIndex: index,
      schoolCode,
      school: schoolName,

      programmeIndex: 0,
      programmeCode,
      programme: programmeName,
      major: programmeName,
      programmeOptionLabels: getProgrammeLabels(schoolCode, lang)
    })
  },

  onProgrammeChange(e) {
    const lang = this.data.lang
    const index = Number(e.detail.value)
    const schoolCode = this.data.schoolCode

    const programmes = getProgrammesBySchool(schoolCode)
    const programme = programmes[index] || programmes[0]
    const programmeCode = programme.code
    const programmeName = getDisplayName(programme, lang)

    this.setData({
      programmeIndex: index,
      programmeCode,
      programme: programmeName,
      major: programmeName
    })
  },

  onMbtiChange(e) {
    const index = Number(e.detail.value)

    this.setData({
      mbtiIndex: index,
      mbti: mbtiOptions[index]
    })
  },

  onBioInput(e) {
    this.setData({
      bio: e.detail.value
    })
  },

  saveProfile() {
    if (!this.guardLogin()) return

    const text = this.data.text
    const nickname = String(this.data.nickname || '').trim()

    if (!nickname) {
      wx.showToast({
        title: text.nicknameEmpty,
        icon: 'none'
      })
      return
    }

    const finalMatchGenderPreference = this.data.livingType === 'school_dorm'
      ? 'same'
      : this.data.matchGenderPreference

    this.setData({
      loading: true
    })

    wx.cloud.callFunction({
      name: 'updateUserProfile',
      data: {
        nickname,

        gender: this.data.gender,
        livingType: this.data.livingType,
        matchGenderPreference: finalMatchGenderPreference,

        year: this.data.year,

        campusCode: this.data.campusCode,
        campus: this.data.campus,

        schoolCode: this.data.schoolCode,
        school: this.data.school,

        programmeCode: this.data.programmeCode,
        programme: this.data.programme,

        major: this.data.programme,

        mbti: this.data.mbti,
        bio: this.data.bio
      },
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || text.saveFailed,
            icon: 'none'
          })
          return
        }

        wx.setStorageSync('dh_current_user', result.user)

        if (auth.updateUser) {
          auth.updateUser(result.user)
        } else if (app.setUserProfile) {
          app.setUserProfile(result.user)
        }

        wx.showToast({
          title: text.saveSuccess,
          icon: 'success'
        })

        setTimeout(() => {
          wx.navigateTo({
            url: '/pages/questionnaire/questionnaire'
          })
        }, 500)
      },
      fail: (err) => {
        console.error('updateUserProfile failed:', err)
        wx.showToast({
          title: text.saveFailed,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  skipToQuestionnaire() {
    if (!this.guardLogin()) return

    const user = wx.getStorageSync('dh_current_user') || null

    if (!user || !user.profileCompleted) {
      wx.showToast({
        title: this.data.text.profileRequired,
        icon: 'none'
      })
      return
    }

    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  }
})