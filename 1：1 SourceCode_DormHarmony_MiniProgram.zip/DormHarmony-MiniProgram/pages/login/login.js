const app = getApp()

let i18n = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '微信登录',
    title: '进入 DormHarmony',
    desc: '请先使用微信身份登录。登录后，系统会为你创建独立用户记录，用于资料、匹配、社区、聊天和安全中心。',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '登录只用于识别当前微信用户。昵称、年级、专业、MBTI 等信息仍由你在基础资料页自行填写。',

    loginButton: '微信登录',
    enterApp: '进入 DormHarmony',
    completeProfile: '完善基础资料',
    loginLoading: '登录中...',
    loginSuccess: '登录成功',
    loginFailed: '登录失败，请稍后再试',

    statusLoggedIn: '已登录',
    statusNotLoggedIn: '尚未登录',
    profileCompleted: '资料已完善',
    profileIncomplete: '资料未完善'
  },

  en: {
    eyebrow: 'WeChat Login',
    title: 'Enter DormHarmony',
    desc: 'Please log in with your WeChat identity first. The system will create your user record for profile, matching, community, chat and safety center.',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'Login is only used to identify the current WeChat user. Nickname, year, major and MBTI are still completed by you in the profile page.',

    loginButton: 'Login with WeChat',
    enterApp: 'Enter DormHarmony',
    completeProfile: 'Complete Profile',
    loginLoading: 'Logging in...',
    loginSuccess: 'Login successful',
    loginFailed: 'Login failed. Please try again later.',

    statusLoggedIn: 'Logged in',
    statusNotLoggedIn: 'Not logged in',
    profileCompleted: 'Profile completed',
    profileIncomplete: 'Profile incomplete'
  }
}

function getStatusText(user, text, openid) {
  if (!openid) return text.statusNotLoggedIn

  if (user && user.profileCompleted) {
    return `${text.statusLoggedIn} · ${text.profileCompleted}`
  }

  return `${text.statusLoggedIn} · ${text.profileIncomplete}`
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    loading: false,
    openid: '',
    user: null,
    statusText: ''
  },

  onLoad() {
    this.refreshLanguage()
    this.loadCachedLogin()
  },

  onShow() {
    this.refreshLanguage()
    this.loadCachedLogin()
  },

  refreshLanguage() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    this.setData({
      lang,
      text
    })

    this.refreshStatusText()
  },

  refreshStatusText() {
    this.setData({
      statusText: getStatusText(this.data.user, this.data.text, this.data.openid)
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.setData({
      lang: nextLang,
      text: pageText[nextLang]
    })

    this.refreshStatusText()
  },

  loadCachedLogin() {
    const openid = wx.getStorageSync('dh_openid') || ''
    const user = wx.getStorageSync('dh_current_user') || null

    this.setData({
      openid,
      user
    })

    this.refreshStatusText()
  },

  loginWithWeChat() {
    const text = this.data.text

    this.setData({
      loading: true
    })

    app.ensureLogin((success, result) => {
      this.setData({
        loading: false
      })

      if (!success) {
        wx.showToast({
          title: text.loginFailed,
          icon: 'none'
        })
        return
      }

      const user = result.user || null
      const openid = result.openid || ''

      this.setData({
        openid,
        user
      })

      this.refreshStatusText()

      wx.showToast({
        title: text.loginSuccess,
        icon: 'success'
      })

      setTimeout(() => {
        this.goNext()
      }, 500)
    })
  },

  goNext() {
    const user = this.data.user || wx.getStorageSync('dh_current_user') || null

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return
    }

    wx.switchTab({
      url: '/pages/index/index'
    })
  },

  goProfileSetup() {
    wx.navigateTo({
      url: '/pages/profileSetup/profileSetup'
    })
  }
})