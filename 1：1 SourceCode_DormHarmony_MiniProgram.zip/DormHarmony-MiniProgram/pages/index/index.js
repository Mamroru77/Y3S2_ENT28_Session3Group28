const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: 'DormHarmony',
    title: '更聪明地找到合适舍友',
    subtitle: '用生活习惯，而不是运气，决定合住体验。',
    desc: 'DormHarmony 通过作息、卫生、访客、空调、噪音、MBTI 和边界偏好，帮助学生更理性地筛选潜在舍友。',
    languageButton: 'EN',

    heroBadgeTitle: 'Smart Match',
    heroBadgeDesc: '真实匹配 · 安全沟通 · 合住协议',

    bearName: '哈米熊',
    bearSpeech: '建议先完善基础资料，再填写生活习惯问卷。真实匹配会根据住宿场景、性别规则和生活习惯共同筛选候选人。',

    startMatch: '开始匹配',
    viewMatches: '查看匹配',
    completeProfile: '完善资料',
    profileIdLabel: 'Profile ID',
    noProfileId: '未设置 Profile ID',

    featureTitle: '核心功能',

    feature1Title: '真实用户匹配',
    feature1Subtitle: 'Living habits · Gender rules · Scenario filtering',
    feature1Desc: '根据学校宿舍和校外合租两种场景，结合性别规则、作息、卫生、访客边界和生活方式标签进行匹配。',

    feature2Title: 'DormTalk 社区',
    feature2Subtitle: 'Post · Search · Comment',
    feature2Desc: '围绕宿舍生活、合住边界和校园住宿经验进行发帖、搜索、评论和举报。',

    feature3Title: '安全沟通与协议',
    feature3Subtitle: 'Chat · Report · Block · Agreement',
    feature3Desc: '支持真实云端聊天、举报、拉黑和合住协议生成，让合住前沟通更清楚。'
  },

  en: {
    eyebrow: 'DormHarmony',
    title: 'Find Better Roommates',
    subtitle: 'Use living habits, not luck, to shape shared-living experience.',
    desc: 'DormHarmony helps students compare potential roommates through schedule, cleanliness, visitors, AC preference, noise tolerance, MBTI and boundary expectations.',
    languageButton: '中文',

    heroBadgeTitle: 'Smart Match',
    heroBadgeDesc: 'Real match · Safe chat · Agreement',

    bearName: 'Harmony Bear',
    bearSpeech: 'Complete your basic profile and lifestyle questionnaire first. Real matching considers living scenario, gender rules and daily habits together.',

    startMatch: 'Start Match',
    viewMatches: 'View Matches',
    completeProfile: 'Complete Profile',
    profileIdLabel: 'Profile ID',
    noProfileId: 'Profile ID not set',

    featureTitle: 'Core Features',

    feature1Title: 'Real User Matching',
    feature1Subtitle: 'Living habits · Gender rules · Scenario filtering',
    feature1Desc: 'Matches are generated through school-dorm and off-campus scenarios, gender rules, schedule, cleanliness, visitors and lifestyle tags.',

    feature2Title: 'DormTalk Community',
    feature2Subtitle: 'Post · Search · Comment',
    feature2Desc: 'Users can discuss dorm life, shared-living boundaries and campus accommodation experiences through posts, search, comments and reports.',

    feature3Title: 'Safe Chat & Agreement',
    feature3Subtitle: 'Chat · Report · Block · Agreement',
    feature3Desc: 'Cloud chat, reports, blocks and roommate agreement generation make pre-living communication clearer.'
  }
}

function buildFeatureCards(text) {
  return [
    {
      title: text.feature1Title,
      subtitle: text.feature1Subtitle,
      desc: text.feature1Desc
    },
    {
      title: text.feature2Title,
      subtitle: text.feature2Subtitle,
      desc: text.feature2Desc
    },
    {
      title: text.feature3Title,
      subtitle: text.feature3Subtitle,
      desc: text.feature3Desc
    }
  ]
}

function getProfileId(user) {
  if (!user) return ''

  return (
    user.profileId ||
    user.dormProfileId ||
    user.studentProfileId ||
    user.publicProfileId ||
    ''
  )
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    profileId: '',
    user: null,

    featureCards: []
  },

  onLoad() {
    this.refreshPage()

    if (!this.guardLogin()) {
      return
    }

    this.loadUserInfo()
  },

  onShow() {
    this.refreshPage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }

    if (!this.guardLogin()) {
      return
    }

    this.loadUserInfo()
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  refreshPage() {
    const lang = getCurrentLang()
    const text = pageText[lang]

    this.setData({
      lang,
      text,
      featureCards: buildFeatureCards(text)
    })
  },

  loadUserInfo() {
    const cachedUser = wx.getStorageSync('dh_current_user') || null

    this.setData({
      user: cachedUser,
      profileId: getProfileId(cachedUser)
    })

    if (!wx.cloud || !wx.cloud.callFunction) return

    wx.cloud.callFunction({
      name: 'getCurrentUser',
      success: (res) => {
        const result = res.result || {}
        const user = result.user || null

        if (!user) return

        wx.setStorageSync('dh_current_user', user)

        this.setData({
          user,
          profileId: getProfileId(user)
        })
      },
      fail: (err) => {
        console.warn('index getCurrentUser failed:', err)
      }
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.refreshPage()
  },

  startMatch() {
    if (!this.guardLogin()) return

    const user = wx.getStorageSync('dh_current_user') || this.data.user || null

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return
    }

    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  },

  viewMatches() {
    if (!this.guardLogin()) return

    const user = wx.getStorageSync('dh_current_user') || this.data.user || null

    if (!user || !user.profileCompleted) {
      wx.navigateTo({
        url: '/pages/profileSetup/profileSetup'
      })
      return
    }

    wx.switchTab({
      url: '/pages/matches/matches'
    })
  },

  goProfileSetup() {
    if (!this.guardLogin()) return

    wx.navigateTo({
      url: '/pages/profileSetup/profileSetup'
    })
  }
})