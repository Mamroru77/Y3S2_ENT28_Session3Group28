const app = getApp()

let i18n = {}
let auth = {}

try {
  i18n = require('../../utils/i18n')
} catch (e) {
  i18n = {}
}

try {
  auth = require('../../utils/auth')
} catch (e) {
  auth = {}
}

const getCurrentLang =
  i18n.getCurrentLang ||
  function () {
    return wx.getStorageSync('dh_lang') || 'zh'
  }

const setCurrentLang =
  i18n.setCurrentLang ||
  function (lang) {
    wx.setStorageSync('dh_lang', lang)
  }

const pageText = {
  zh: {
    eyebrow: '安全中心',
    title: '举报与拉黑管理',
    languageButton: 'EN',

    bearName: '哈米熊',
    bearSpeech: '这里可以查看你提交过的举报和当前拉黑记录。解除拉黑后，对应会话可以重新发送消息。',

    tabsReports: '我的举报',
    tabsBlocks: '拉黑记录',

    reportsTitle: '我的举报记录',
    blocksTitle: '我的拉黑记录',

    emptyReports: '暂无举报记录。',
    emptyBlocks: '暂无拉黑记录。',

    targetType: '类型',
    reason: '原因',
    status: '状态',
    description: '说明',
    targetName: '对象',
    unblock: '解除拉黑',
    unblockTitle: '确认解除拉黑？',
    unblockContent: '解除后，该会话可以重新发送消息。',
    unblockSuccess: '已解除拉黑',

    refresh: '刷新',
    loading: '加载中...',
    networkError: '网络或云函数异常'
  },

  en: {
    eyebrow: 'Safety Center',
    title: 'Reports & Blocks',
    languageButton: '中文',

    bearName: 'Harmony Bear',
    bearSpeech: 'Here you can view your reports and active block records. After unblocking, the conversation can send messages again.',

    tabsReports: 'My Reports',
    tabsBlocks: 'Blocked',

    reportsTitle: 'My Reports',
    blocksTitle: 'Blocked Records',

    emptyReports: 'No report records.',
    emptyBlocks: 'No block records.',

    targetType: 'Type',
    reason: 'Reason',
    status: 'Status',
    description: 'Description',
    targetName: 'Target',
    unblock: 'Unblock',
    unblockTitle: 'Confirm unblock?',
    unblockContent: 'After unblocking, this conversation can send messages again.',
    unblockSuccess: 'Unblocked',

    refresh: 'Refresh',
    loading: 'Loading...',
    networkError: 'Network or cloud function error'
  }
}

function formatTime(value) {
  if (!value) return ''

  let date = null

  if (value instanceof Date) {
    date = value
  } else if (typeof value === 'string' || typeof value === 'number') {
    date = new Date(value)
  } else if (value.$date) {
    date = new Date(value.$date)
  }

  if (!date || isNaN(date.getTime())) return ''

  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')

  return `${month}/${day} ${hour}:${minute}`
}

function decorateReports(reports) {
  return (reports || []).map(item => {
    return Object.assign({}, item, {
      displayTime: formatTime(item.createdAt),
      displayDescription: item.description || '-',
      displayReason: item.reason || '-',
      displayStatus: item.status || 'pending'
    })
  })
}

function decorateBlocks(blocks) {
  return (blocks || []).map(item => {
    return Object.assign({}, item, {
      displayTime: formatTime(item.createdAt),
      displayTarget: item.targetName || item.targetId || item.targetOpenid || 'Dorm User',
      displayReason: item.reason || '-'
    })
  })
}

Page({
  data: {
    lang: 'zh',
    text: pageText.zh,

    activeTab: 'reports',
    reports: [],
    blocks: [],

    loading: false,
    unblocking: false
  },

  onLoad() {
    this.refreshLanguage()

    if (!this.guardLogin()) {
      return
    }

    this.loadSafetyCenter()
  },

  onShow() {
    this.refreshLanguage()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }

    if (!this.guardLogin()) {
      return
    }

    this.loadSafetyCenter()
  },

  guardLogin() {
    if (auth.requireLogin) {
      return auth.requireLogin()
    }

    const openid = wx.getStorageSync('dh_openid') || ''

    if (!openid) {
      wx.reLaunch({
        url: '/pages/login/login'
      })
      return false
    }

    return true
  },

  refreshLanguage() {
    const lang = getCurrentLang()

    this.setData({
      lang,
      text: pageText[lang]
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.setData({
      lang: nextLang,
      text: pageText[nextLang]
    })
  },

  switchTab(e) {
    const tab = e.currentTarget.dataset.tab || 'reports'

    this.setData({
      activeTab: tab
    })
  },

  loadSafetyCenter() {
    if (!wx.cloud || !wx.cloud.callFunction) return

    this.setData({
      loading: true
    })

    wx.cloud.callFunction({
      name: 'getSafetyCenter',
      success: (res) => {
        const result = res.result || {}

        if (!result.ok) {
          wx.showToast({
            title: result.message || this.data.text.networkError,
            icon: 'none'
          })
          return
        }

        this.setData({
          reports: decorateReports(result.reports || []),
          blocks: decorateBlocks(result.blocks || [])
        })
      },
      fail: (err) => {
        console.error('getSafetyCenter failed:', err)
        wx.showToast({
          title: this.data.text.networkError,
          icon: 'none'
        })
      },
      complete: () => {
        this.setData({
          loading: false
        })
      }
    })
  },

  unblock(e) {
    if (!this.guardLogin()) return

    const blockId = e.currentTarget.dataset.id
    const text = this.data.text

    if (!blockId) return

    wx.showModal({
      title: text.unblockTitle,
      content: text.unblockContent,
      confirmColor: '#e79a6e',
      success: (modalRes) => {
        if (!modalRes.confirm) return

        this.setData({
          unblocking: true
        })

        wx.cloud.callFunction({
          name: 'unblockUser',
          data: {
            blockId
          },
          success: (res) => {
            const result = res.result || {}

            if (!result.ok) {
              wx.showToast({
                title: result.message || text.networkError,
                icon: 'none'
              })
              return
            }

            wx.showToast({
              title: text.unblockSuccess,
              icon: 'success'
            })

            this.loadSafetyCenter()
          },
          fail: (err) => {
            console.error('unblockUser failed:', err)
            wx.showToast({
              title: text.networkError,
              icon: 'none'
            })
          },
          complete: () => {
            this.setData({
              unblocking: false
            })
          }
        })
      }
    })
  }
})