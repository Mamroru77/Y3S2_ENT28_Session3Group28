const app = getApp()
const {
  getCurrentLang,
  getPageText,
  setCurrentLang
} = require('../../utils/i18n')

const {
  getUser,
  getProfile,
  clearAllDormHarmonyData
} = require('../../utils/storage')

const {
  getReputationSummary
} = require('../../utils/reputation')

Page({
  data: {
    lang: 'zh',
    text: {},
    user: null,
    profile: null,
    reputation: null,
    reputationScore: 85,
    reputationStyle: 'width: 85%;',
    avatarInitial: 'D',
    reputationRecords: []
  },

  onLoad() {
    this.loadPageData()
  },

  onShow() {
    this.loadPageData()

    if (app.applyTabBarLanguage) {
      app.applyTabBarLanguage()
    }
  },

  loadPageData() {
    const lang = getCurrentLang()
    const text = getPageText('profile', lang)
    const user = getUser()
    const profile = getProfile()
    const reputation = getReputationSummary(lang)

    const score = reputation && reputation.score ? reputation.score : 85
    const avatarInitial =
      user && user.nickname ? String(user.nickname).slice(0, 1).toUpperCase() : 'D'

    const reputationRecords = (reputation.records || []).map((item) => {
      return {
        ...item,
        displayChange: item.change >= 0 ? `+${item.change}` : `${item.change}`,
        changeClass: item.change >= 0 ? 'positive' : 'negative',
        displayReason: lang === 'zh' ? item.reasonZh : item.reasonEn
      }
    })

    this.setData({
      lang,
      text,
      user,
      profile,
      reputation,
      reputationScore: score,
      reputationStyle: `width: ${score}%;`,
      avatarInitial,
      reputationRecords
    })
  },

  switchLanguage() {
    const nextLang = this.data.lang === 'zh' ? 'en' : 'zh'

    setCurrentLang(nextLang)

    if (app.setLanguage) {
      app.setLanguage(nextLang)
    }

    this.loadPageData()
  },

  goEditProfile() {
    wx.navigateTo({
      url: '/pages/profileSetup/profileSetup'
    })
  },

  goQuestionnaire() {
    wx.navigateTo({
      url: '/pages/questionnaire/questionnaire'
    })
  },

  resetData() {
    wx.showModal({
      title: this.data.lang === 'zh' ? '确认清除？' : 'Confirm reset?',
      content:
        this.data.lang === 'zh'
          ? '这会清除本地保存的用户、资料、问卷和信誉分。'
          : 'This will clear local user, profile, questionnaire and reputation data.',
      success: (res) => {
        if (res.confirm) {
          clearAllDormHarmonyData()

          wx.showToast({
            title: this.data.lang === 'zh' ? '已清除' : 'Cleared',
            icon: 'success'
          })

          this.loadPageData()
        }
      }
    })
  }
})